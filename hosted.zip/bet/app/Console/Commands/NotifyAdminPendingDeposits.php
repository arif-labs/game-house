<?php

namespace App\Console\Commands;

use App\Http\Controllers\AdminTelegramBotController;
use Illuminate\Console\Command;

class NotifyAdminPendingDeposits extends Command
{
    protected $signature = 'admin-bot:notify-pending';
    protected $description = 'Notify authorized Admin Bot accounts about new pending deposits';

    public function handle(): int
    {
        $sent = app(AdminTelegramBotController::class)->notifyPendingDeposits();
        $this->info("Notified {$sent} pending deposit(s).");
        return self::SUCCESS;
    }
}
