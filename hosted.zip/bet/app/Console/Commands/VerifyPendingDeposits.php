<?php

namespace App\Console\Commands;

use App\Services\DepositVerificationService;
use Illuminate\Console\Command;

class VerifyPendingDeposits extends Command
{
    protected $signature = 'deposits:verify-pending';
    protected $description = 'Re-check pending deposits whose payment could not be verified yet (checker was unreachable or the receipt was not visible yet)';

    public function handle(DepositVerificationService $verifier): int
    {
        $summary = $verifier->processPending(20);
        if ($summary['checked'] > 0) {
            $this->info('Checked ' . $summary['checked'] . ' pending deposit(s); receipt matches awaiting admin approval: ' . $summary['verified'] . '.');
        }
        return self::SUCCESS;
    }
}