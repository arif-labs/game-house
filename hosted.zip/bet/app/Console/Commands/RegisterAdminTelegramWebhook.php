<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Http;

class RegisterAdminTelegramWebhook extends Command
{
    protected $signature = 'admin-bot:register-webhook';
    protected $description = 'Register the private Admin Bot webhook with Telegram';

    public function handle(): int
    {
        $token = (string) config('services.admin_telegram.bot_token', '');
        $secret = (string) config('services.admin_telegram.webhook_secret', '');
        $url = rtrim((string) config('app.url'), '/').'/api/admin-bot/webhook';
        if ($token === '' || $secret === '' || count(config('services.admin_telegram.admin_ids', [])) === 0) {
            $this->error('Set ADMIN_BOT_TOKEN, ADMIN_BOT_WEBHOOK_SECRET and ADMIN_TELEGRAM_ADMIN_IDS in .env first.');
            return self::FAILURE;
        }
        if (!preg_match('/^[A-Za-z0-9_-]{1,256}$/', $secret)) {
            $this->error('ADMIN_BOT_WEBHOOK_SECRET must contain only letters, numbers, _ or - (1-256 chars).');
            return self::FAILURE;
        }
        try {
            $response = Http::timeout(15)->post("https://api.telegram.org/bot{$token}/setWebhook", [
                'url' => $url,
                'secret_token' => $secret,
                'allowed_updates' => ['message', 'callback_query'],
            ]);
            if (!$response->ok() || !$response->json('ok')) {
                $this->error('Telegram rejected webhook registration: '.($response->json('description') ?? 'unknown error'));
                return self::FAILURE;
            }
            $this->info('Admin Bot webhook registered: '.$url);
            return self::SUCCESS;
        } catch (\Throwable $e) {
            $this->error('Webhook registration failed: '.$e->getMessage());
            return self::FAILURE;
        }
    }
}
