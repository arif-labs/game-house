<?php

namespace App\Services;

use Carbon\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * Checks a deposit receipt and records the verification result. A successful receipt check NEVER
 * credits a wallet: every deposit remains pending until an administrator explicitly approves it
 * through the existing WalletService::creditDeposit() workflow.
 *
 * Anything unclear stays pending with a review note; unavailable checks may be retried by the scheduler.
 *
 * Result states: verified (awaiting admin approval) | review | unavailable | rejected.
 */
class DepositVerificationService
{
    public function __construct(
        private WalletService $wallet,
        private PaymentAccountService $accounts,
    ) {
    }

    public function enabled(): bool
    {
        // The unique reference key (migration) is what makes automatic crediting safe against reused receipts.
        return (bool) config('services.deposit_verifier.enabled', true) && WalletService::hasVerificationColumns();
    }

    public static function referenceKey(string $reference): string
    {
        return strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $reference));
    }

    // ------------------------------------------------------------------------------------------
    // Entry points
    // ------------------------------------------------------------------------------------------

    /**
     * Verify one pending deposit and credit it when valid.
     *
     * @return array{state:string,note?:string,amount?:float,message?:string}
     */
    public function attempt(string $depositId, bool $notify = true): array
    {
        if (!$this->enabled()) {
            return ['state' => 'disabled'];
        }

        $lock = null;
        try {
            $lock = Cache::lock('deposit-verify:' . $depositId, 90);
            if (!$lock->get()) {
                return ['state' => 'busy'];
            }
        } catch (\Throwable $e) {
            $lock = null; // cache store without locks: the pending-row lock in creditDeposit still prevents double credit
        }

        try {
            $d = DB::table('deposits')->where('id', $depositId)->first();
            if (!$d || $d->status !== 'pending') {
                return ['state' => 'skipped'];
            }
            $user = DB::table('users')->where('id', $d->user_id)->first();

            $check = $this->check($d, $user);
            $this->recordAttempt($d, $check);

            if ($check['state'] !== 'verified') {
                return $check;
            }

            // Verification is evidence for an administrator, never authorization to move money.
            // Keep the deposit status pending; the existing admin approval action is the only credit path.
            $verifiedAmount = round((float) ($check['amount'] ?? 0), 2);
            if ($verifiedAmount <= 0) {
                return $this->result('review', 'The receipt checker did not return a valid settled amount.');
            }

            DB::table('deposits')->where('id', $d->id)->where('status', 'pending')->update([
                'verification_status' => 'verified',
                'verified_amount' => $verifiedAmount,
                'verified_at' => now(),
                'verification_note' => mb_substr((string) ($check['note'] ?? 'Receipt matched; awaiting administrator approval.'), 0, 1000),
            ]);

            return [
                'state' => 'verified',
                'amount' => $verifiedAmount,
                'message' => 'Receipt details matched. Your deposit is awaiting administrator approval; no wallet balance has been changed.',
                'note' => $check['note'] ?? '',
            ];
        } finally {
            try {
                $lock?->release();
            } catch (\Throwable $e) {
                // ignore
            }
        }
    }

    /** Retry deposits that were waiting for the checker. Called by the scheduler. */
    public function processPending(int $limit = 20): array
    {
        $summary = ['checked' => 0, 'verified' => 0];
        if (!$this->enabled()) {
            return $summary;
        }

        $maxAttempts = (int) config('services.deposit_verifier.max_attempts', 12);
        $rows = DB::table('deposits')
            ->where('status', 'pending')
            ->where(function ($q) {
                $q->whereNull('verification_status')->orWhere('verification_status', 'unavailable');
            })
            ->where('verification_attempts', '<', $maxAttempts)
            ->where(function ($q) {
                $q->whereNull('last_verification_at')->orWhere('last_verification_at', '<', now()->subSeconds(75));
            })
            ->orderBy('created_at')
            ->limit($limit)
            ->pluck('id');

        foreach ($rows as $id) {
            $summary['checked']++;
            $outcome = $this->attempt((string) $id, true);
            if (($outcome['state'] ?? '') === 'verified') {
                $summary['verified']++;
            }
        }
        return $summary;
    }

    // ------------------------------------------------------------------------------------------
    // Checking
    // ------------------------------------------------------------------------------------------

    private function check(object $d, ?object $user): array
    {
        if (!$user) {
            return $this->result('review', 'Player account not found.');
        }

        $provider = $this->providerOf((string) ($d->provider ?? ''));
        if ($provider === null) {
            return $this->result('review', 'Unknown payment provider "' . ($d->provider ?? '') . '".');
        }

        $ref = self::referenceKey((string) $d->reference_no);
        if ($ref === '' || strlen($ref) < 6) {
            return $this->result('review', 'The payment reference is too short to check.');
        }

        try {
            return $provider === 'telebirr'
                ? $this->checkTelebirr($d, $user, $ref)
                : $this->checkCbeBirr($d, $user, $ref);
        } catch (\Throwable $e) {
            Log::warning('Deposit verification error: ' . $e->getMessage(), ['deposit' => $d->id]);
            return $this->result('unavailable', 'Verification service error: ' . $e->getMessage());
        }
    }

    private function providerOf(string $provider): ?string
    {
        $p = strtolower($provider);
        if (str_contains($p, 'telebirr') || str_contains($p, 'tele birr')) {
            return 'telebirr';
        }
        if (str_contains($p, 'cbe')) {
            return 'cbebirr';
        }
        return null;
    }

    // ---- Telebirr ----------------------------------------------------------------------------

    private function checkTelebirr(object $d, object $user, string $ref): array
    {
        $relay = trim((string) config('services.deposit_verifier.telebirr_relay_url', ''));
        $base = trim((string) config('services.deposit_verifier.telebirr_receipt_url', 'https://transactioninfo.ethiotelecom.et/receipt/'));
        $url = $relay !== ''
            ? (str_contains($relay, '{ref}') ? str_replace('{ref}', rawurlencode($ref), $relay) : $relay . rawurlencode($ref))
            : rtrim($base, '/') . '/' . rawurlencode($ref);

        try {
            $response = Http::withOptions(['verify' => $this->sslVerify()])
                ->timeout((int) config('services.deposit_verifier.timeout', 12))
                ->connectTimeout(6)
                ->withHeaders(['User-Agent' => 'Mozilla/5.0 (compatible; EthioBingoDepositCheck/1.0)', 'Accept' => 'text/html,application/json'])
                ->get($url);
        } catch (\Throwable $e) {
            return $this->result('unavailable', 'Could not reach the Telebirr receipt service from this server (it only answers Ethiopian IPs; set TELEBIRR_RELAY_URL if the server is abroad): ' . $e->getMessage());
        }

        if ($response->status() === 404) {
            return $this->notFound($d, 'Telebirr has no receipt with this reference.');
        }
        if (!$response->ok()) {
            return $this->result('unavailable', 'Telebirr receipt service answered HTTP ' . $response->status() . '.');
        }

        $receipt = $this->parseTelebirr($response->body());
        if (!$receipt || ($receipt['amount'] === null && $receipt['status'] === '')) {
            return $this->notFound($d, 'Telebirr returned no receipt details for this reference.');
        }

        return $this->evaluateTelebirr($d, $user, $ref, $receipt);
    }

    /** @return array<string,mixed>|null */
    public function parseTelebirr(string $html): ?array
    {
        if (trim($html) === '') {
            return null;
        }

        $previous = libxml_use_internal_errors(true);
        $dom = new \DOMDocument();
        $loaded = $dom->loadHTML('<?xml encoding="UTF-8">' . $html);
        libxml_clear_errors();
        libxml_use_internal_errors($previous);
        if (!$loaded) {
            return null;
        }

        $xp = new \DOMXPath($dom);
        foreach ($xp->query('//script|//style') as $node) {
            $node->parentNode?->removeChild($node);
        }

        // Label / value rows: "<Amharic label>/<English label>" | value.
        $pairs = [];
        foreach ($xp->query('//tr') as $tr) {
            $cells = [];
            foreach ($tr->childNodes as $child) {
                if ($child->nodeType === XML_ELEMENT_NODE && strtolower($child->nodeName) === 'td') {
                    $cells[] = $this->clean($child->textContent);
                }
            }
            if (count($cells) === 2 && $cells[0] !== '') {
                $parts = explode('/', $cells[0]);
                $pairs[strtolower(trim((string) end($parts)))] = $cells[1];
            }
        }

        // Join every text node with a space so adjacent table cells never run together, whatever the page spacing.
        $pieces = [];
        foreach ($xp->query('//text()') as $node) {
            $piece = $this->clean((string) $node->nodeValue);
            if ($piece !== '') {
                $pieces[] = $piece;
            }
        }
        $text = $this->clean(implode(' ', $pieces));

        $status = '';
        if (preg_match('/transaction status\s*([A-Za-z]+)/iu', $text, $m)) {
            $status = $m[1];
        } elseif (isset($pairs['transaction status'])) {
            $status = $pairs['transaction status'];
        }

        $receiptNo = null;
        $date = null;
        $amount = null;
        if (preg_match('/Settled Amount\s+(\S+)\s+(\d{2}-\d{2}-\d{4}\s+\d{2}:\d{2}:\d{2})\s+([\d,]+(?:\.\d+)?)\s*Birr/iu', $text, $m)) {
            $receiptNo = $m[1];
            $date = $m[2];
            $amount = (float) str_replace(',', '', $m[3]);
        }
        $total = null;
        if (preg_match('/Total Paid Amount\s*([\d,]+(?:\.\d+)?)\s*Birr/iu', $text, $m)) {
            $total = (float) str_replace(',', '', $m[1]);
        }

        return [
            'status' => trim($status),
            'receiptNo' => $receiptNo,
            'date' => $date,
            'amount' => $amount,
            'total' => $total,
            'payerName' => $pairs['payer name'] ?? '',
            'payerAccount' => $pairs['payer telebirr no.'] ?? ($pairs['payer telebirr no'] ?? ''),
            'receiverName' => $pairs['credited party name'] ?? '',
            'receiverAccount' => $pairs['credited party account no'] ?? '',
        ];
    }

    private function evaluateTelebirr(object $d, object $user, string $ref, array $r): array
    {
        if (!in_array(strtolower($r['status']), ['completed', 'complete', 'success', 'successful'], true)) {
            return $this->result('review', 'Telebirr receipt status is "' . ($r['status'] ?: 'unknown') . '", not Completed.');
        }
        if (!empty($r['receiptNo']) && strtoupper((string) $r['receiptNo']) !== $ref) {
            return $this->result('review', 'The receipt number does not match the reference that was entered.');
        }

        // Amount: the player may enter what arrived (settled) or what left their wallet (settled + fee).
        $claimed = round((float) $d->amount, 2);
        $settled = $r['amount'];
        if ($settled === null || $settled <= 0) {
            return $this->result('review', 'Could not read the amount from the Telebirr receipt.');
        }
        $matchesClaim = abs($settled - $claimed) <= 0.01 || ($r['total'] !== null && abs($r['total'] - $claimed) <= 0.01);
        if (!$matchesClaim) {
            return $this->result('review', 'Receipt shows ' . WalletService::money($settled) . ' ETB but the player entered ' . WalletService::money($claimed) . ' ETB.');
        }

        // Receiver: the Telebirr receipt hides most digits of the credited number, so the visible digits are
        // compared and, when an account holder name is configured, the name must match too.
        $expectedNumber = $this->accounts->numberFor('Telebirr');
        $expectedName = trim($this->accounts->nameFor('Telebirr'));
        $receiver = $this->receiverMatches((string) $r['receiverAccount'], (string) $r['receiverName'], $expectedNumber, $expectedName);
        if (!$receiver['ok']) {
            return $this->result('review', 'Receiver check failed: ' . $receiver['reason']);
        }

        // Payer: ties the receipt to THIS player so nobody can claim a stranger's receipt.
        if ((bool) config('services.deposit_verifier.require_payer_match', true)) {
            $payer = $this->phoneMatches((string) $r['payerAccount'], (string) ($user->phone ?? ''));
            if (!$payer['ok']) {
                return $this->result('review', 'Payer check failed: ' . $payer['reason']);
            }
        }

        $age = $this->receiptAge($r['date'] ?? null);
        if ($age !== null) {
            $maxHours = (int) config('services.deposit_verifier.max_age_hours', 72);
            if ($age > $maxHours * 3600) {
                return $this->result('review', 'The receipt is older than ' . $maxHours . ' hours.');
            }
            if ($age < -900) {
                return $this->result('review', 'The receipt date is in the future.');
            }
        }

        $note = 'Telebirr receipt ' . $ref . ' completed: ' . WalletService::money($settled) . ' ETB to ' . ($r['receiverName'] ?: $r['receiverAccount']) . ' (' . $r['receiverAccount'] . ') from ' . ($r['payerAccount'] ?: 'payer') . '.';
        return ['state' => 'verified', 'amount' => $settled, 'note' => $note];
    }

    private function receiptAge(?string $date): ?int
    {
        if (!$date) {
            return null;
        }
        try {
            $at = Carbon::createFromFormat('d-m-Y H:i:s', $date, 'Africa/Addis_Ababa');
            return $at ? now()->timestamp - $at->timestamp : null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    // ---- CBE Birr (Verify.ET free tier) --------------------------------------------------------

    private function checkCbeBirr(object $d, object $user, string $ref): array
    {
        $key = trim((string) config('services.deposit_verifier.verifyet_key', ''));
        if ($key === '') {
            return $this->result('review', 'Automatic CBE Birr checking is not set up (VERIFYET_API_KEY is empty). An admin must approve this deposit.');
        }

        $payerPhone = $this->canonicalPhone((string) ($user->phone ?? ''));
        if ($payerPhone === '') {
            return $this->result('review', 'The player has no verified phone number, which CBE Birr checking needs.');
        }

        $expectedNumber = $this->accounts->numberFor('CBE Birr');
        $expectedName = trim($this->accounts->nameFor('CBE Birr'));
        $expectedCanonical = $this->canonicalPhone($expectedNumber);
        $settlement = $expectedCanonical !== '' ? '0' . substr($expectedCanonical, 3) : $expectedNumber;

        $base = rtrim((string) config('services.deposit_verifier.verifyet_url', 'https://verify.et'), '/');
        try {
            $response = Http::withOptions(['verify' => $this->sslVerify()])
                ->timeout((int) config('services.deposit_verifier.timeout', 12) + 4)
                ->connectTimeout(6)
                ->withHeaders(['x-api-key' => $key, 'Idempotency-Key' => 'dep-' . $d->id, 'Accept' => 'application/json'])
                ->post($base . '/api/verify?waitMs=9000', [
                    'bank' => 'cbebirr',
                    'receiptNumber' => $ref,
                    'phoneNumber' => $payerPhone,
                    'settlementAccount' => $settlement,
                ]);
        } catch (\Throwable $e) {
            return $this->result('unavailable', 'Could not reach Verify.ET: ' . $e->getMessage());
        }

        $status = $response->status();
        if ($status === 202) {
            return $this->result('unavailable', 'Verify.ET is still processing this receipt; it will be checked again shortly.');
        }
        if ($status === 401 || $status === 403) {
            return $this->result('unavailable', 'Verify.ET rejected the API key (HTTP ' . $status . '). Check VERIFYET_API_KEY.');
        }
        if ($status === 402) {
            return $this->result('unavailable', 'Verify.ET free verification credits are used up.');
        }
        if ($status === 429 || $status >= 500) {
            return $this->result('unavailable', 'Verify.ET is busy or down (HTTP ' . $status . ').');
        }

        $json = $response->json();
        $json = is_array($json) ? $json : [];
        $item = is_array($json['data'][0] ?? null) ? $json['data'][0] : null;
        $message = (string) ($json['message'] ?? ($item['error'] ?? ''));

        $verified = $item && ((($item['verified'] ?? false) === true) || strtolower((string) ($item['status'] ?? '')) === 'success');
        if (!$verified) {
            return $this->notFound($d, 'Verify.ET could not confirm this CBE Birr receipt' . ($message !== '' ? ' (' . $message . ')' : '') . '.');
        }

        $amount = round((float) ($item['amount'] ?? 0), 2);
        $claimed = round((float) $d->amount, 2);
        if ($amount <= 0) {
            return $this->result('review', 'Could not read the amount from the CBE Birr receipt.');
        }
        if (abs($amount - $claimed) > 0.01) {
            return $this->result('review', 'Receipt shows ' . WalletService::money($amount) . ' ETB but the player entered ' . WalletService::money($claimed) . ' ETB.');
        }

        // The CBE Birr receipt shows the receiving phone, so it must be the deposit number.
        $match = $item['settlementAccountMatch'] ?? null;
        $settled = is_array($match) && (($match['matched'] ?? false) === true);
        if (!$settled) {
            $receiver = $this->receiverMatches((string) ($item['receiverAccount'] ?? ''), (string) ($item['receiverName'] ?? ''), $expectedNumber, $expectedName);
            if (!$receiver['ok']) {
                return $this->result('review', 'Receiver check failed: ' . $receiver['reason']);
            }
        }

        $stamp = $item['timestamp'] ?? ($item['date'] ?? null);
        if ($stamp) {
            try {
                $age = now()->timestamp - Carbon::parse((string) $stamp)->timestamp;
                $maxHours = (int) config('services.deposit_verifier.max_age_hours', 72);
                if ($age > $maxHours * 3600) {
                    return $this->result('review', 'The receipt is older than ' . $maxHours . ' hours.');
                }
                if ($age < -900) {
                    return $this->result('review', 'The receipt date is in the future.');
                }
            } catch (\Throwable $e) {
                // an unreadable date is not a reason to reject a receipt the bank confirmed
            }
        }

        $note = 'CBE Birr receipt ' . $ref . ' confirmed by Verify.ET: ' . WalletService::money($amount) . ' ETB to ' . ($item['receiverAccount'] ?? $settlement) . ' from payer phone ' . $payerPhone . '.';
        return ['state' => 'verified', 'amount' => $amount, 'note' => $note];
    }

    // ---- Matching helpers ----------------------------------------------------------------------

    /**
     * Does the receipt's receiver match the configured deposit account?
     * Telebirr hides most digits of the receiver, so the visible digits are compared, and the receiver name
     * as well when an account holder name is configured.
     *
     * @return array{ok:bool,reason:string}
     */
    private function receiverMatches(string $shownAccount, string $shownName, string $expectedNumber, string $expectedName): array
    {
        $expected = $this->canonicalPhone($expectedNumber);
        $digits = $expected !== '' ? $this->maskMatches($shownAccount, $expected) : null; // true / false / null (not visible)
        $name = $expectedName !== '' ? $this->nameMatches($shownName, $expectedName) : null;

        if ($digits === false) {
            return ['ok' => false, 'reason' => 'the receipt was paid to ' . ($shownAccount !== '' ? $shownAccount : 'another account') . ', not the deposit number'];
        }
        if ($name === false) {
            return ['ok' => false, 'reason' => 'the receiver name "' . $shownName . '" does not match the account holder "' . $expectedName . '"'];
        }
        if ($digits === true || $name === true) {
            return ['ok' => true, 'reason' => ''];
        }
        return ['ok' => false, 'reason' => 'the receipt does not show enough of the receiver number and no account holder name is set in Payment Accounts to compare'];
    }

    /** @return array{ok:bool,reason:string} */
    private function phoneMatches(string $shown, string $playerPhone): array
    {
        $canonical = $this->canonicalPhone($playerPhone);
        if ($canonical === '') {
            return ['ok' => false, 'reason' => 'the player has no verified phone number to compare with the payer number'];
        }
        $match = $this->maskMatches($shown, $canonical);
        if ($match === null) {
            return ['ok' => false, 'reason' => 'the payer number on the receipt is not visible enough to match the player'];
        }
        return $match
            ? ['ok' => true, 'reason' => '']
            : ['ok' => false, 'reason' => 'the receipt was paid from ' . $shown . ', which is not the registered phone of this player'];
    }

    /**
     * Compare a possibly masked phone ("2519****6680") with a full canonical number (251XXXXXXXXX).
     * Returns true/false, or null when too few digits are visible to decide.
     */
    private function maskMatches(string $shown, string $canonical): ?bool
    {
        if ($canonical === '') {
            return null;
        }
        $s = preg_replace('/[\s\-+]/', '', $shown) ?? '';
        if ($s === '') {
            return null;
        }
        if (!preg_match('/[^0-9]/', $s)) {
            $c = $this->canonicalPhone($s);
            return $c !== '' ? $c === $canonical : null;
        }
        if (str_starts_with($s, '0')) {
            $s = '251' . substr($s, 1);
        }
        if (!preg_match('/^(\d*)[^\d]+(\d*)$/u', $s, $m)) {
            return null;
        }
        [$prefix, $suffix] = [$m[1], $m[2]];
        if (strlen($prefix) + strlen($suffix) < 4) {
            return null;
        }
        return str_starts_with($canonical, $prefix) && str_ends_with($canonical, $suffix);
    }

    private function canonicalPhone(string $value): string
    {
        $d = preg_replace('/\D/', '', $value) ?? '';
        if (strlen($d) === 12 && str_starts_with($d, '251')) {
            return $d;
        }
        if (strlen($d) === 10 && str_starts_with($d, '0')) {
            return '251' . substr($d, 1);
        }
        if (strlen($d) === 9 && in_array($d[0], ['9', '7'], true)) {
            return '251' . $d;
        }
        return '';
    }

    private function nameMatches(string $shown, string $expected): bool
    {
        $tokens = function (string $v): array {
            $v = mb_strtolower($v, 'UTF-8');
            $v = preg_replace('/[^\p{L}\s]/u', ' ', $v) ?? '';
            return array_values(array_filter(preg_split('/\s+/u', $v) ?: []));
        };
        $want = $tokens($expected);
        if (!$want) {
            return true;
        }
        $have = $tokens($shown);
        foreach ($want as $token) {
            if (!in_array($token, $have, true)) {
                return false;
            }
        }
        return true;
    }

    // ---- Small helpers -------------------------------------------------------------------------

    /** A receipt that is not found right after payment may simply not be visible yet: retry for a while first. */
    private function notFound(object $d, string $why): array
    {
        $ageMinutes = $d->created_at ? (now()->timestamp - strtotime((string) $d->created_at)) / 60 : 999;
        if ($ageMinutes < 15) {
            return $this->result('unavailable', $why . ' It may not be visible yet; it will be checked again shortly.');
        }
        return $this->result('review', $why . ' An admin should check the reference with the player.');
    }

    private function result(string $state, string $note): array
    {
        return ['state' => $state, 'note' => $note];
    }

    private function recordAttempt(object $d, array $check): void
    {
        $update = [
            'verification_attempts' => DB::raw('verification_attempts + 1'),
            'last_verification_at' => now(),
            'verification_note' => mb_substr((string) ($check['note'] ?? ''), 0, 1000),
        ];
        if (($check['state'] ?? '') !== 'verified') {
            $update['verification_status'] = $check['state'];
        }
        DB::table('deposits')->where('id', $d->id)->where('status', 'pending')->update($update);
    }

    private function clean(string $value): string
    {
        $value = html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $value = str_replace("\xC2\xA0", ' ', $value);
        return trim((string) preg_replace('/\s+/u', ' ', $value));
    }

    /** @return bool|string TLS verification setting for Guzzle */
    private function sslVerify(): bool|string
    {
        if (!(bool) config('services.deposit_verifier.verify_ssl', true)) {
            return false;
        }
        return config('services.telegram.ca_bundle') ?: true;
    }
}
