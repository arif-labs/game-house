<?php

namespace App\Http\Controllers;

use App\Services\GameService;
use App\Services\HouseWalletService;
use App\Services\TelegramBotRegistry;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use RuntimeException;

class ApiController
{
    public function __construct(private GameService $game, private HouseWalletService $houseWallet)
    {
    }

    public function adminLogin(Request $r)
    {
        $email = (string) $r->input('email');
        $password = (string) $r->input('password');

        $hash = config('services.admin_auth.password_hash');
        $plain = config('services.admin_auth.password');

        $valid = $hash
            ? Hash::check($password, $hash)
            : ($plain !== null && hash_equals((string) $plain, $password));

        if (
            !$valid ||
           !hash_equals(
    strtolower(trim((string) config('services.admin_auth.email', 'admin@example.com'))),
    strtolower(trim($email))
)
        ) {
            return response()->json([
                'ok' => false,
                'error' => 'Invalid administrator credentials',
            ], 401);
        }

        $r->session()->regenerate();

        session([
            'admin' => [
                'email' => $email,
                'name' => config('services.admin_auth.name', 'System Administrator'),
                'role' => config('services.admin_auth.role', 'super_admin'),
                'exp' => now()->addSeconds(
                    (int) config('services.admin_auth.session_ttl', 28800)
                )->timestamp,
            ],
        ]);

        return response()->json([
            'ok' => true,
            'admin' => session('admin'),
        ]);
    }

    public function adminMe(Request $r)
    {
        return response()->json([
            'ok' => true,
            'admin' => $r->attributes->get('admin'),
        ]);
    }

    public function adminLogout(Request $r)
    {
        $r->session()->invalidate();
        $r->session()->regenerateToken();

        return response()->json([
            'ok' => true,
        ]);
    }

    public function adminHealth()
    {
        DB::select('select 1');

        return response()->json([
            'ok' => true,
            'service' => 'ethiobingo-laravel',
            'database' => DB::connection()->getDatabaseName(),
        ]);
    }

    public function playerTelegramAuth(Request $r)
    {
        $init = (string) $r->input('initData');

        if (strlen($init) > 20000) {
            return response()->json([
                'ok' => false,
                'error' => 'Telegram authentication payload is too large',
            ], 413);
        }

        // Preserve the original single-bot path; only requests carrying an explicit bot key use the additional registry.
        $botKey = trim((string) $r->input('botKey', ''));
        if ($botKey !== '') {
            $configuredBot = app(TelegramBotRegistry::class)->find($botKey);
            $token = $configuredBot && !empty($configuredBot['enabled'])
                ? (string) ($configuredBot['botToken'] ?? '')
                : '';
            if ($token === '') {
                return response()->json(['ok' => false, 'error' => 'This Telegram bot is not configured or is disabled.'], 401);
            }
        } else {
            $token = (string) config('services.telegram.bot_token', '');
        }

        if (!$token) {
            return response()->json([
                'ok' => false,
                'error' => 'Telegram bot authentication is not configured',
            ], 503);
        }

        $v = $this->verifyTelegram($init, $token);

        if (!$v['ok']) {
            return response()->json([
                'ok' => false,
                'error' => $v['error'],
            ], 401);
        }

        $u = $v['user'];
        $tid = (string) $u['id'];

        $username = substr(
            (string) ($u['username'] ?? 'tg_' . $tid),
            0,
            64
        );

        $full = substr(
            trim(
                ($u['first_name'] ?? '') . ' ' .
                ($u['last_name'] ?? '')
            ) ?: $username,
            0,
            120
        );

        // Create the account and its one-time ETB 10 Play Wallet welcome bonus
        // atomically. Existing Telegram accounts are never credited again.
        $id = DB::transaction(function () use ($tid, $username, $full) {
            $existing = DB::table('users')
                ->where('telegram_id', $tid)
                ->lockForUpdate()
                ->first();

            if ($existing) {
                DB::table('users')->where('id', $existing->id)->update([
                    'username' => $username,
                    'full_name' => $full,
                    'updated_at' => now(),
                ]);

                return $existing->id;
            }

            $newId = 'usr-tg-' . $tid;
            $now = now();
            $pendingReferral = DB::table('telegram_referrals')->where('telegram_id', $tid)->first();
            $referrer = $pendingReferral
                ? DB::table('users')->where('referral_code', $pendingReferral->referral_code)->where('id', '<>', $newId)->first()
                : null;
            do {
                $referralCode = 'REF' . strtoupper(Str::random(9));
            } while (DB::table('users')->where('referral_code', $referralCode)->exists());

            DB::table('users')->insert([
                'id' => $newId,
                'telegram_id' => $tid,
                'username' => $username,
                'full_name' => $full,
                'referral_code' => $referralCode,
                'referred_by' => $referrer->id ?? null,
                'main_balance' => 0,
                'play_balance' => 10.00,
                'rounds_played' => 0,
                'rounds_won' => 0,
                'total_deposited' => 0,
                'total_withdrawn' => 0,
                'created_at' => $now,
                'updated_at' => $now,
            ]);

            DB::table('ledger')->insert([
                'id' => (string) Str::uuid(),
                'user_id' => $newId,
                'type' => 'NEW_PLAYER_BONUS',
                'wallet_type' => 'PLAY',
                'amount' => 10.00,
                'balance_after' => 10.00,
                'reference_id' => 'NEW-PLAYER-BONUS',
                'description' => 'One-time ETB 10 welcome bonus for a new player',
                'created_at' => $now,
                'updated_at' => $now,
            ]);

            if ($pendingReferral) {
                DB::table('telegram_referrals')->where('telegram_id', $tid)->delete();
            }

            return $newId;
        });

        // If the player shared their contact from the bot before opening the Mini App,
        // attach that verified phone number to the account created above.
        $pendingContact = DB::table('telegram_pending_contacts')
            ->where('telegram_id', $tid)
            ->first();

        if ($pendingContact) {
            DB::table('users')->where('id', $id)->update([
                'phone' => $pendingContact->phone,
                'phone_verified_at' => $pendingContact->received_at,
                'updated_at' => now(),
            ]);
            DB::table('telegram_pending_contacts')->where('telegram_id', $tid)->delete();
        }

        $r->session()->regenerate();

        session([
            'player_id' => $id,
        ]);

        $savedLanguage = DB::table('system_state')->where('key', 'telegram_language_' . $tid)->value('value');
        $playerLanguage = in_array($savedLanguage, ['am', 'en'], true) ? $savedLanguage : 'am';

        return response()->json([
            'ok' => true,
            'player' => $this->game->playerState($id)['player'],
            'language' => $playerLanguage,
        ]);
    }

    private function verifyTelegram(
        string $init,
        string $token
    ): array {
        $p = [];

        parse_str($init, $p);

        $hash = $p['hash'] ?? '';

        unset($p['hash']);

        if (!$hash) {
            return [
                'ok' => false,
                'error' => 'Missing Telegram hash',
            ];
        }

        ksort($p);

        $data = collect($p)
            ->map(fn ($v, $k) => $k . '=' . $v)
            ->implode("\n");

        $secret = hash_hmac(
            'sha256',
            $token,
            'WebAppData',
            true
        );

        $calc = hash_hmac(
            'sha256',
            $data,
            $secret
        );

        if (!hash_equals($calc, $hash)) {
            return [
                'ok' => false,
                'error' => 'Invalid Telegram authentication',
            ];
        }

        if (
            isset($p['auth_date']) &&
            time() - (int) $p['auth_date'] > 86400
        ) {
            return [
                'ok' => false,
                'error' => 'Telegram authentication expired',
            ];
        }

        $user = json_decode(
            $p['user'] ?? '{}',
            true
        );

        return isset($user['id'])
            ? [
                'ok' => true,
                'user' => $user,
            ]
            : [
                'ok' => false,
                'error' => 'Telegram user missing',
            ];
    }

    public function deposit(Request $r)
    {
        $uid = $r->attributes->get('player_id');
        $amount = round((float) $r->input('amount'), 2);
        $ref = preg_replace('/\s+/', '', trim((string) $r->input('referenceNo')));
        $provider = trim((string) $r->input('provider'));

        if (
            $amount <= 0 ||
            $amount > 100000 ||
            !preg_match('/^[A-Za-z0-9_-]{4,64}$/', (string) $ref)
        ) {
            return response()->json([
                'ok' => false,
                'error' => 'Invalid deposit. Enter the amount and the transaction reference exactly as shown in your payment message.',
            ], 400);
        }

        $u = DB::table('users')
            ->where('id', $uid)
            ->first();

        if (!$u) {
            return response()->json([
                'ok' => false,
                'error' => 'Player account not found',
            ], 400);
        }

        if (DB::table('deposits')->where('user_id', $uid)->where('status', 'pending')->count() >= 5) {
            return response()->json([
                'ok' => false,
                'error' => 'You have several deposits awaiting review. Please wait for them to be approved.',
            ], 429);
        }

        $id = (string) Str::uuid();
        $row = [
            'id' => $id,
            'user_id' => $uid,
            'username' => $u->username,
            'amount' => $amount,
            'provider' => $provider !== '' ? $provider : null,
            'reference_no' => $ref,
            'status' => 'pending',
            'created_at' => now(),
        ];

        // A payment reference can only ever be used once.
        if (\App\Services\WalletService::hasVerificationColumns()) {
            $row['reference_key'] = \App\Services\DepositVerificationService::referenceKey((string) $ref);
            $duplicate = DB::table('deposits')->where('reference_key', $row['reference_key'])->exists();
        } else {
            $duplicate = DB::table('deposits')->whereRaw('LOWER(reference_no) = ?', [strtolower((string) $ref)])->exists();
        }
        if ($duplicate) {
            return response()->json([
                'ok' => false,
                'error' => 'This transaction reference was already submitted.',
            ], 409);
        }

        try {
            DB::table('deposits')->insert($row);
        } catch (\Illuminate\Database\QueryException $e) {
            if (str_contains(strtolower($e->getMessage()), 'duplicate') || (string) $e->getCode() === '23000') {
                return response()->json([
                    'ok' => false,
                    'error' => 'This transaction reference was already submitted.',
                ], 409);
            }
            throw $e;
        }

        // Check the receipt right away. A match is recorded for admin approval; no wallet is credited here.
        // Anything unclear stays pending for an admin; an unreachable checker is retried by the scheduler.
        $outcome = app(\App\Services\DepositVerificationService::class)->attempt($id, true);
        $fresh = DB::table('deposits')->where('id', $id)->first();

        return response()->json([
            'ok' => true,
            'autoVerified' => ($outcome['state'] ?? '') === 'verified',
            'deposit' => [
                'id' => $id,
                'userId' => $uid,
                'username' => $u->username,
                'amount' => (float) ($fresh->amount ?? $amount),
                'provider' => $provider,
                'referenceNo' => $ref,
                'status' => $fresh->status ?? 'pending',
                'createdAt' => now()->timestamp * 1000,
            ],
        ]);
    }
    public function withdrawal(Request $r)
    {
        $uid = $r->attributes->get('player_id');
        $amount = (float) $r->input('amount');

        return $this->action(function () use ($uid, $amount, $r) {
            return DB::transaction(function () use ($uid, $amount, $r) {
                $u = DB::table('users')
                    ->where('id', $uid)
                    ->lockForUpdate()
                    ->first();

                if (
                    !$u ||
                    $amount <= 0 ||
                    $amount > 100000 ||
                    $u->main_balance < $amount
                ) {
                    throw new RuntimeException(
                        'Insufficient Main Wallet balance'
                    );
                }

                $after = round(
                    (float) $u->main_balance - $amount,
                    2
                );

                $id = (string) Str::uuid();

                DB::table('users')
                    ->where('id', $uid)
                    ->update([
                        'main_balance' => $after,
                        'total_withdrawn' =>
                            (float) $u->total_withdrawn + $amount,
                        'updated_at' => now(),
                    ]);

                DB::table('withdrawals')->insert([
                    'id' => $id,
                    'user_id' => $uid,
                    'username' => $u->username,
                    'amount' => $amount,
                    'provider' => $r->input('provider'),
                    'account_number' => $r->input('accountNumber'),
                    'account_name' => $r->input('accountName'),
                    'status' => 'pending',
                    'created_at' => now(),
                ]);

                $this->houseWallet->post('WITHDRAWAL_REQUEST', $amount, $id, 'Player withdrawal requested by '.$u->username);

                DB::table('ledger')->insert([
                    'id' => (string) Str::uuid(),
                    'user_id' => $uid,
                    'type' => 'WITHDRAWAL',
                    'wallet_type' => 'MAIN',
                    'amount' => -$amount,
                    'balance_after' => $after,
                    'reference_id' => $id,
                    'description' => 'Withdrawal request',
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);

                return [
                    'ok' => true,
                    'success' => true,
                    'message' => 'Withdrawal request submitted for review',
                ];
            });
        });
    }

    /** Profile actions shared with the Telegram bot menu. */
    public function playerProfileActions(Request $r)
    {
        $uid = (string) $r->attributes->get('player_id');
        $user = DB::table('users')->where('id', $uid)->where('is_bot', false)->first();
        if (!$user) {
            return response()->json(['ok' => false, 'error' => 'Player account not found.'], 404);
        }

        $stored = DB::table('system_state')->where('key', 'telegram_bot_config')->value('value');
        $saved = is_string($stored) ? json_decode($stored, true) : null;
        $config = is_array($saved) ? $saved : [];
        $options = collect($config['options'] ?? [])->keyBy('id');
        $enabled = fn (string $id, bool $default = true): bool => (bool) ($options->get($id)['enabled'] ?? $default);

        $referralCode = (string) ($user->referral_code ?? '');
        if ($referralCode === '') {
            do {
                $referralCode = 'REF' . strtoupper(Str::random(9));
            } while (DB::table('users')->where('referral_code', $referralCode)->exists());
            DB::table('users')->where('id', $uid)->update(['referral_code' => $referralCode, 'updated_at' => now()]);
        }

        $supportUsername = trim((string) ($config['supportUsername'] ?? ''));
        if ($supportUsername === '') {
            $supportUsername = trim((string) config('services.telegram_support.username', ''));
        }
        $supportUsername = ltrim($supportUsername, '@');
        $supportUrl = $supportUsername !== ''
            ? 'https://t.me/' . $supportUsername
            : 'https://t.me/ethiobingobet_bot';

        return response()->json([
            'ok' => true,
            'actions' => [
                'transferEnabled' => $enabled('transfer') && (bool) ($config['transferEnabled'] ?? true),
                'transferMinAmount' => (float) ($config['transferMinAmount'] ?? 1),
                'transferMaxAmount' => (float) ($config['transferMaxAmount'] ?? 10000),
                'supportEnabled' => $enabled('support'),
                'supportUrl' => $supportUrl,
                'inviteEnabled' => $enabled('invite'),
                'referralLink' => 'https://t.me/ethiobingobet_bot?start=ref_' . $referralCode,
                'referralCode' => $referralCode,
                'referralBonusEnabled' => (bool) ($config['referralBonusEnabled'] ?? true),
                'referralBonusAmount' => (float) ($config['referralBonusAmount'] ?? 10),
            ],
        ]);
    }

    /** Player-to-player transfer initiated from the Mini App profile, with server-side limits. */
    public function playerTransferBalance(Request $r)
    {
        $uid = (string) $r->attributes->get('player_id');
        $recipientUsername = ltrim(trim((string) $r->input('recipientUsername')), '@');
        $amount = round((float) $r->input('amount'), 2);
        $sourceWallet = (string) $r->input('sourceWallet', 'main');

        return $this->action(function () use ($uid, $recipientUsername, $amount, $sourceWallet) {
            if (!preg_match('/^[a-zA-Z0-9_]{3,64}$/', $recipientUsername)) {
                throw new RuntimeException('Enter the recipient’s registered Telegram username.');
            }
            if (!in_array($sourceWallet, ['main', 'play'], true)) {
                throw new RuntimeException('Choose Main wallet or Playing wallet.');
            }

            $stored = DB::table('system_state')->where('key', 'telegram_bot_config')->value('value');
            $saved = is_string($stored) ? json_decode($stored, true) : null;
            $config = is_array($saved) ? $saved : [];
            $options = collect($config['options'] ?? [])->keyBy('id');
            $transferOptionEnabled = (bool) ($options->get('transfer')['enabled'] ?? true);
            if (!$transferOptionEnabled || !(bool) ($config['transferEnabled'] ?? true)) {
                throw new RuntimeException('Balance transfers are currently disabled.');
            }

            $min = (float) ($config['transferMinAmount'] ?? 1);
            $max = (float) ($config['transferMaxAmount'] ?? 10000);
            if ($amount < $min || $amount > $max) {
                throw new RuntimeException('Transfer amount must be between ' . number_format($min, 2) . ' and ' . number_format($max, 2) . ' ETB.');
            }

            $sender = DB::table('users')->where('id', $uid)->where('is_bot', false)->first();
            $recipient = DB::table('users')->whereRaw('LOWER(username) = ?', [strtolower($recipientUsername)])->where('is_bot', false)->first();
            if (!$sender || !$recipient) {
                throw new RuntimeException('Recipient not found. Enter the username they use in their registered player account.');
            }
            if ((string) $sender->id === (string) $recipient->id) {
                throw new RuntimeException('You cannot transfer balance to yourself.');
            }

            $result = app(\App\Services\WalletService::class)->transferToPlayer(
                (string) $sender->id,
                (string) $recipient->id,
                $amount,
                $sourceWallet,
                ['notifySender' => true]
            );

            return ['ok' => true, 'success' => true, 'message' => $result['message']];
        });
    }

    /** Main wallet -> Playing wallet. The opposite direction does not exist on purpose. */
    public function moveToPlay(Request $r)
    {
        $uid = (string) $r->attributes->get('player_id');
        $amount = (float) $r->input('amount');

        return $this->action(function () use ($uid, $amount) {
            $res = app(\App\Services\WalletService::class)->moveMainToPlay($uid, $amount);

            return [
                'ok' => true,
                'success' => true,
                'message' => 'Moved to your Playing wallet',
                'mainBalance' => $res['mainBalance'],
                'playBalance' => $res['playBalance'],
            ];
        });
    }
    public function playerLogout(Request $r)
    {
        $r->session()->invalidate();
        $r->session()->regenerateToken();

        return response()->json([
            'ok' => true,
        ]);
    }

    public function playerState(Request $r)
    {
        return response()->json([
            'ok' => true,
            ...$this->game->playerState(
                $r->attributes->get('player_id')
            ),
        ]);
    }

    public function select(Request $r)
    {
        return $this->action(
            fn () => $this->game->select(
                $r->attributes->get('player_id'),
                (string) $r->input('roomId'),
                (int) $r->input('cartelaId')
            )
        );
    }

    public function release(Request $r)
    {
        return $this->action(
            fn () => $this->game->release(
                $r->attributes->get('player_id'),
                (string) $r->input('roomId'),
                (int) $r->input('cartelaId')
            )
        );
    }

    public function claim(Request $r)
    {
        return $this->action(
            fn () => $this->game->claim(
                $r->attributes->get('player_id'),
                (string) $r->input('roomId')
            )
        );
    }

    private function action(\Closure $fn)
    {
        try {
            return response()->json($fn());
        } catch (\Throwable $e) {
            return response()->json([
                'ok' => false,
                'success' => false,
                'error' => $e->getMessage(),
            ], 400);
        }
    }

    
    public function adminBotStatus()
    {
        return response()->json(['ok' => true] + $this->game->botDiagnostics());
    }

    public function updateBotSettings(Request $r, string $id)
    {
        $admin = $r->attributes->get('admin') ?? [];
        if (!in_array($admin['role'] ?? '', ['super_admin', 'game_operator'], true)) {
            return response()->json(['ok' => false, 'error' => 'Insufficient role'], 403);
        }

        $data = $r->validate([
            'automatedPlayersEnabled' => 'sometimes|boolean',
            'automatedPlayerCount' => 'sometimes|integer|min:0|max:200',
            'automatedPlayersTriggerBelow' => 'sometimes|integer|min:1|max:200',
            'automatedPlayersTarget' => 'sometimes|integer|min:1|max:200',
            'automatedPlayersRiskControlEnabled' => 'sometimes|boolean',
            'automatedPlayersMaxStakeBudget' => 'sometimes|numeric|min:0|max:100000000',
            'automatedPlayersMaxHouseExposure' => 'sometimes|numeric|min:0|max:100000000',
            'automatedPlayersStrategy' => 'sometimes|in:conservative,balanced,aggressive',
            'automatedPlayersManualOverrideEnabled' => 'sometimes|boolean',
            'automatedPlayersBotsPerRealCartela' => 'sometimes|integer|min:1|max:20',
        ]);

        return $this->action(function () use ($id, $data, $admin) {
            $room = $this->game->updateBotSettings($id, $data);
            DB::table('admin_audit')->insert([
                'id' => (string) Str::uuid(),
                'timestamp' => now()->timestamp * 1000,
                'admin_email' => (string) ($admin['email'] ?? 'unknown'),
                'action' => 'BOT_SETTINGS_UPDATE',
                'target' => $id,
                'details' => json_encode($data),
                'created_at' => now(),
            ]);
            return ['ok' => true, 'room' => $room];
        });
    }

    public function adminRooms()
    {
        return response()->json([
            'ok' => true,
            'rooms' => $this->game->rooms(),
        ]);
    }

    public function saveRoom(Request $r)
    {
        $data = $r->validate([
            'id' => 'sometimes|string|max:64',
            'name' => 'required|string|max:120',
            'stake' => 'required|numeric|min:1|max:100000',
            'rakePercent' => 'sometimes|numeric|min:0|max:99.99',
            'minPlayers' => 'sometimes|integer|min:1|max:200',
            'maxPlayers' => 'sometimes|integer|min:1|max:200',
'amharicName' => 'sometimes|string|max:120',
            'selectionSeconds' => 'sometimes|integer|min:5|max:600',
            'drawInterval' => 'sometimes|integer|min:1|max:60',
            'maxCartelasPerPlayer' => 'sometimes|integer|min:1|max:200',
            'enabledPatterns' => 'sometimes|array|min:1',
            'isVip' => 'sometimes|boolean',
            'inviteCode' => 'nullable|string|max:64',
            'automatedPlayersEnabled' => 'sometimes|boolean',
            'automatedPlayerCount' => 'sometimes|integer|min:0|max:200',
            'automatedPlayersTriggerBelow' => 'sometimes|integer|min:1|max:200',
            'automatedPlayersTarget' => 'sometimes|integer|min:1|max:200',
            // These were previously not validated, so Laravel silently dropped them and
            // saveRoom() reset them to defaults (budget 50 / exposure 100 / 2 per cartela).
            'automatedPlayersRiskControlEnabled' => 'sometimes|boolean',
            'automatedPlayersMaxStakeBudget' => 'sometimes|numeric|min:0|max:100000000',
            'automatedPlayersMaxHouseExposure' => 'sometimes|numeric|min:0|max:100000000',
            'automatedPlayersStrategy' => 'sometimes|in:conservative,balanced,aggressive',
            'automatedPlayersManualOverrideEnabled' => 'sometimes|boolean',
            'automatedPlayersBotsPerRealCartela' => 'sometimes|integer|min:1|max:20',
        ]);

        return $this->action(fn () => [
            'ok' => true,
            'room' => $this->game->saveRoom($data),
        ]);
    }

    public function updateRoom(Request $r, string $id)
    {
        $data = $r->validate([
            'name' => 'sometimes|required|string|max:120',
            'stake' => 'sometimes|required|numeric|min:1|max:100000',
            'rakePercent' => 'sometimes|numeric|min:0|max:99.99',
            'minPlayers' => 'sometimes|integer|min:1|max:200',
            'maxPlayers' => 'sometimes|integer|min:1|max:200',
            'selectionSeconds' => 'sometimes|integer|min:5|max:600',
            'drawInterval' => 'sometimes|integer|min:1|max:60',
            'maxCartelasPerPlayer' => 'sometimes|integer|min:1|max:200',
            'amharicName' => 'sometimes|string|max:120',
            'enabledPatterns' => 'sometimes|array|min:1',
            'isVip' => 'sometimes|boolean',
            'inviteCode' => 'nullable|string|max:64',
            'automatedPlayersEnabled' => 'sometimes|boolean',
            'automatedPlayerCount' => 'sometimes|integer|min:0|max:200',
            'automatedPlayersTriggerBelow' => 'sometimes|integer|min:1|max:200',
            'automatedPlayersTarget' => 'sometimes|integer|min:1|max:200',
            // These were previously not validated, so Laravel silently dropped them and
            // saveRoom() reset them to defaults (budget 50 / exposure 100 / 2 per cartela).
            'automatedPlayersRiskControlEnabled' => 'sometimes|boolean',
            'automatedPlayersMaxStakeBudget' => 'sometimes|numeric|min:0|max:100000000',
            'automatedPlayersMaxHouseExposure' => 'sometimes|numeric|min:0|max:100000000',
            'automatedPlayersStrategy' => 'sometimes|in:conservative,balanced,aggressive',
            'automatedPlayersManualOverrideEnabled' => 'sometimes|boolean',
            'automatedPlayersBotsPerRealCartela' => 'sometimes|integer|min:1|max:20',
        ]);

        return $this->action(fn () => [
            'ok' => true,
            'room' => $this->game->saveRoom([
                ...$data,
                'id' => $id,
            ]),
        ]);
    }

    public function updateRoomStatus(Request $r, string $id)
    {
        $data = $r->validate([
            'status' => 'required|in:active,paused,maintenance',
        ]);

        return $this->action(fn () => [
            'ok' => true,
            'room' => $this->game->setRoomStatus(
                $id,
                $data['status']
            ),
        ]);
    }

   public function adminState()
{
    return response()->json([
        'ok' => true,
        'settings' => $this->game->settings(),
        'rooms' => $this->game->rooms(),
        'killSwitch' => DB::table('system_state')
            ->where('key', 'killSwitch')
            ->value('value') === '1',
    ]);
}

    
public function adminRoundHistory()
{
    $rows = DB::table('game_rounds')
        ->join('game_rooms', 'game_rooms.id', '=', 'game_rounds.room_id')
        ->orderByDesc('game_rounds.created_at')
        ->limit(500)
        ->get([
            'game_rounds.id',
            'game_rounds.room_id',
            'game_rooms.name as room_name',
            'game_rounds.round_code',
            'game_rounds.phase',
            'game_rounds.config',
            'game_rounds.balls_drawn',
            'game_rounds.winners',
            'game_rounds.seed_hash',
            'game_rounds.started_at',
            'game_rounds.finished_at',
            'game_rounds.created_at',
        ]);

    return response()->json([
        'ok' => true,
        'history' => $rows->map(fn ($row) => [
            'id' => $row->id,
            'roomId' => $row->room_id,
            'roomName' => $row->room_name,
            'roundCode' => $row->round_code,
            'phase' => $row->phase,
            'config' => json_decode($row->config, true) ?: [],
            'ballsDrawn' => json_decode($row->balls_drawn, true) ?: [],
            'winners' => json_decode($row->winners, true) ?: [],
            'seedCommitment' => $row->seed_hash,
            'createdAt' => $row->created_at,
            'startedAt' => $row->started_at,
            'finishedAt' => $row->finished_at,
        ])->all(),
    ]);
}

public function playerLeaderboard()
{
    $startOfWeek = now()->startOfWeek();

    $rows = DB::table('ledger')
        ->join('users', 'users.id', '=', 'ledger.user_id')
        ->where('users.is_bot', false)
        ->where('ledger.type', 'WIN_PAYOUT')
        ->where('ledger.created_at', '>=', $startOfWeek)
        ->where('ledger.amount', '>', 0)
        ->groupBy('users.id', 'users.username')
        ->select(
            'users.id',
            'users.username',
            DB::raw('COUNT(ledger.id) as wins'),
            DB::raw('SUM(ledger.amount) as won')
        )
        ->orderByDesc('won')
        ->limit(20)
        ->get();

    return response()->json([
        'ok' => true,
        'period' => 'week',
        'leaders' => $rows->map(fn ($row) => [
            'id' => $row->id,
            'name' => $row->username,
            'wins' => (int) $row->wins,
            'won' => (float) $row->won,
        ])->all(),
    ]);
}

public function fundHouseWallet(Request $r)
{
    $admin = $r->attributes->get('admin') ?? [];
    if (!in_array($admin['role'] ?? '', ['super_admin', 'finance'], true)) {
        return response()->json(['ok' => false, 'error' => 'Insufficient role'], 403);
    }

    $data = $r->validate([
        'amount' => 'required|numeric|min:1|max:100000000',
        'reason' => 'required|string|min:3|max:200',
    ]);

    return $this->action(function () use ($data, $admin) {
        return DB::transaction(function () use ($data, $admin) {
            $reference = 'FUND-' . Str::uuid();
            $balance = $this->houseWallet->post(
                'FUNDING',
                (float) $data['amount'],
                $reference,
                'House reserve funding by ' . ($admin['email'] ?? 'admin') . ': ' . $data['reason']
            );
            DB::table('admin_audit')->insert([
                'id' => (string) Str::uuid(),
                'timestamp' => now()->timestamp * 1000,
                'admin_email' => (string) ($admin['email'] ?? 'unknown'),
                'action' => 'HOUSE_WALLET_FUNDING',
                'target' => 'house-wallet',
                'details' => json_encode(['amount' => (float) $data['amount'], 'reason' => $data['reason'], 'balanceAfter' => $balance]),
                'created_at' => now(),
            ]);
            return ['ok' => true, 'balance' => $balance];
        });
    });
}

public function adminFinanceSummary()
{
    $ledgerRows = DB::table('ledger')
        ->leftJoin('users', 'users.id', '=', 'ledger.user_id')
        ->orderByDesc('ledger.created_at')
        ->limit(500)
        ->get([
            'ledger.id',
            'ledger.created_at',
            'users.username',
            'ledger.type',
            'ledger.wallet_type',
            'ledger.amount',
            'ledger.balance_after',
            'ledger.reference_id',
            'ledger.description',
        ]);

    $approvedDeposits = (float) DB::table('deposits')->where('status', 'approved')->sum('amount');
    $approvedWithdrawals = (float) DB::table('withdrawals')->where('status', 'approved')->sum('amount');
    $payouts = (float) DB::table('ledger')->where('type', 'WIN_PAYOUT')->sum('amount');
    $bonuses = (float) DB::table('ledger')->whereIn('type', ['NEW_PLAYER_BONUS', 'BONUS_GRANT', 'REFERRAL_BONUS'])->sum('amount');
    $manualAdjustmentEntries = DB::table('ledger')->where('type', 'MANUAL_ADJUSTMENT');
    $manualAdjustmentCount = (clone $manualAdjustmentEntries)->count();
    $manualAdjustmentTotal = (float) (clone $manualAdjustmentEntries)->sum('amount');
    $legacyRakeEntries = DB::table('ledger')->where('type', 'RAKE_FEE');
    $houseRakeEntries = DB::table('house_ledger')->where('type', 'RAKE_FEE');
    $rakeCount = (clone $legacyRakeEntries)->count() + (clone $houseRakeEntries)->count();
    $recordedRake = $rakeCount > 0
        ? (float) (clone $legacyRakeEntries)->sum('amount') + (float) (clone $houseRakeEntries)->sum('amount')
        : null;

    $unledgeredApprovedDeposits = DB::table('deposits')
        ->where('status', 'approved')
        ->whereNotExists(function ($query) {
            $query->select(DB::raw(1))
                ->from('ledger')
                ->whereColumn('ledger.reference_id', 'deposits.id')
                ->where('ledger.type', 'DEPOSIT');
        })
        ->count();

    return response()->json([
        'ok' => true,
        'summary' => [
            'approvedDeposits' => $approvedDeposits,
            'approvedWithdrawals' => $approvedWithdrawals,
            'winnerPayouts' => $payouts,
            'bonusesRecorded' => $bonuses,
            'manualAdjustmentCount' => $manualAdjustmentCount,
            'manualAdjustmentTotal' => $manualAdjustmentTotal,
            'netCashFlow' => $approvedDeposits - $approvedWithdrawals,
            'recordedHouseRake' => $recordedRake,
            'houseRakeEntries' => $rakeCount,
            'unledgeredApprovedDeposits' => $unledgeredApprovedDeposits,
            'houseWalletBalance' => $this->houseWallet->balance(),
            'houseProfitLoss' => $this->houseWallet->profitLoss(),
            'houseLedger' => $this->houseWallet->recentLedger(200),
        ],
        'ledger' => $ledgerRows->map(fn ($row) => [
            'id' => $row->id,
            'timestamp' => $row->created_at ? strtotime($row->created_at) * 1000 : 0,
            'username' => $row->username ?? 'Unknown account',
            'type' => $row->type,
            'walletType' => $row->wallet_type,
            'amount' => (float) $row->amount,
            'balanceAfter' => (float) $row->balance_after,
            'referenceId' => $row->reference_id,
            'description' => $row->description ?? '',
        ])->all(),
        'deposits' => DB::table('deposits')->orderByDesc('created_at')->limit(200)->get()->map(fn ($row) => [
            'id' => $row->id,
            'userId' => $row->user_id,
            'username' => $row->username,
            'amount' => (float) $row->amount,
            'provider' => $row->provider,
            'referenceNo' => $row->reference_no,
            'verificationStatus' => $row->verification_status ?? null,
            'verificationNote' => $row->verification_note ?? null,
            'status' => $row->status,
            'createdAt' => $row->created_at ? strtotime($row->created_at) * 1000 : 0,
            'reviewedBy' => $row->reviewed_by,
        ])->all(),
        'withdrawals' => DB::table('withdrawals')->orderByDesc('created_at')->limit(200)->get()->map(fn ($row) => [
            'id' => $row->id,
            'userId' => $row->user_id,
            'username' => $row->username,
            'amount' => (float) $row->amount,
            'provider' => $row->provider,
            'accountNumber' => $row->account_number,
            'accountName' => $row->account_name,
            'status' => $row->status,
            'createdAt' => $row->created_at ? strtotime($row->created_at) * 1000 : 0,
            'reviewedBy' => $row->reviewed_by,
        ])->all(),
    ]);
}

public function adminReports()
{
    $today = now()->startOfDay();
    $completedPhases = ['FINISHED', 'PAYOUT'];

    $completedRoundsToday = DB::table('game_rounds')
        ->whereIn('phase', $completedPhases)
        ->whereNotNull('finished_at')
        ->where('finished_at', '>=', $today)
        ->count();

    $payoutsToday = (float) DB::table('ledger')
        ->where('type', 'WIN_PAYOUT')
        ->where('created_at', '>=', $today)
        ->sum('amount');

    $depositsToday = (float) DB::table('deposits')
        ->where('status', 'approved')
        ->where('reviewed_at', '>=', $today)
        ->sum('amount');

    $withdrawalsToday = (float) DB::table('withdrawals')
        ->where('status', 'approved')
        ->where('reviewed_at', '>=', $today)
        ->sum('amount');

    $rakeQuery = DB::table('ledger')->where('type', 'RAKE_FEE')->where('created_at', '>=', $today);
    $houseRakeQuery = DB::table('house_ledger')->where('type', 'RAKE_FEE')->where('created_at', '>=', $today);
    $rakeCount = (clone $rakeQuery)->count() + (clone $houseRakeQuery)->count();
    $rakeTotal = (float) (clone $rakeQuery)->sum('amount') + (float) (clone $houseRakeQuery)->sum('amount');

    $rooms = DB::table('game_rooms')->orderBy('name')->get()->map(function ($room) use ($today, $completedPhases) {
        $config = json_decode($room->config, true) ?: [];
        $roundsToday = DB::table('game_rounds')
            ->where('room_id', $room->id)
            ->whereIn('phase', $completedPhases)
            ->whereNotNull('finished_at')
            ->where('finished_at', '>=', $today)
            ->count();

        return [
            'id' => $room->id,
            'name' => $room->name,
            'stake' => (float) ($config['stake'] ?? 0),
            'rakePercent' => array_key_exists('rakePercent', $config) ? (float) $config['rakePercent'] : null,
            'completedRoundsToday' => $roundsToday,
        ];
    })->all();

    return response()->json([
        'ok' => true,
        'asOf' => now()->toIso8601String(),
        'summary' => [
            'registeredPlayers' => DB::table('users')->where('is_bot', false)->count(),
            'completedRoundsToday' => $completedRoundsToday,
            'winnerPayoutsToday' => $payoutsToday,
            'approvedDepositsToday' => $depositsToday,
            'approvedWithdrawalsToday' => $withdrawalsToday,
            'recordedHouseRakeToday' => $rakeCount > 0 ? $rakeTotal : null,
            'houseRakeEntriesToday' => $rakeCount,
        ],
        'rooms' => $rooms,
    ]);
}

public function adminGameState()
{
    $rooms = $this->game->rooms();

    $roundStates = [];
    $cartelaReservations = [];

    foreach ($rooms as $room) {
        $q = $this->game->round($room['id']);

        $reservations = DB::table('cartela_reservations')
            ->leftJoin('users', 'users.id', '=', 'cartela_reservations.user_id')
            ->where('cartela_reservations.round_id', $q->id)
            ->select('cartela_reservations.*', 'users.is_bot')
            ->get();

        $roundConfig = array_merge($room, json_decode($q->config, true) ?: []);
        $confirmedReservations = $reservations->where('status', 'confirmed');
        $cartelaCount = $confirmedReservations->count();
        $playersCount = $confirmedReservations->pluck('user_id')->unique()->count();
        $stake = (float) ($roundConfig['stake'] ?? 0);
        $rakePercent = (float) ($roundConfig['rakePercent'] ?? 0);
        $totalPool = round($cartelaCount * $stake, 2);
        $rakeEarned = round($totalPool * $rakePercent / 100, 2);
        $derashPrize = round($totalPool - $rakeEarned, 2);

        $roundStates[$room['id']] = [
            'id' => $q->id,
            'roundId' => $q->id,
            'roomId' => $q->room_id,
            'roundCode' => $q->round_code,
            'phase' => $q->phase,
            'timerSeconds' => (int) $q->timer_seconds,
            'ballsDrawn' => json_decode($q->balls_drawn, true) ?: [],
            'playersCount' => $playersCount,
            'totalPool' => $totalPool,
            'derashPrize' => $derashPrize,
            'rakeEarned' => $rakeEarned,
            'winners' => json_decode($q->winners, true) ?: [],
            'startedAt' => $q->started_at ? strtotime($q->started_at) * 1000 : null,
            'finishedAt' => $q->finished_at ? strtotime($q->finished_at) * 1000 : null,
            'seedCommitment' => $q->seed_hash,
            'revealedSeed' => in_array($q->phase, ['FINISHED', 'PAYOUT'], true)
                ? $q->seed
                : null,
        ];

        $cartelaReservations[$room['id']] = $reservations
            ->mapWithKeys(fn ($x) => [
                $x->cartela_id => [
                    'userId' => $x->user_id,
                    'username' => $x->username,
                    'isBot' => (bool) ($x->is_bot ?? false),
                    'status' => $x->status,
                    'walletType' => $x->wallet_type,
                ],
            ])
            ->all();
    }

    return response()->json([
        'ok' => true,
        'rooms' => $rooms,
        'roundStates' => $roundStates,
        'users' => DB::table('users')
            ->orderByDesc('updated_at')
            ->limit(1000)
            ->get()
            ->map(fn ($u) => [
                'id' => $u->id,
                'username' => $u->username,
                'fullName' => $u->full_name,
                'phone' => $u->phone,
                'phoneVerifiedAt' => $u->phone_verified_at,
                'isBot' => (bool) ($u->is_bot ?? false),
                'mainWalletBalance' => (float) $u->main_balance,
                'playWalletBalance' => (float) $u->play_balance,
                'totalDeposited' => (float) $u->total_deposited,
                'totalWithdrawn' => (float) $u->total_withdrawn,
                'roundsPlayed' => (int) $u->rounds_played,
                'roundsWon' => (int) $u->rounds_won,
            ])
            ->all(),
        'cartelaReservations' => $cartelaReservations,
        'deposits' => DB::table('deposits')
            ->latest('created_at')
            ->limit(200)
            ->get(),
        'withdrawals' => DB::table('withdrawals')
            ->latest('created_at')
            ->limit(200)
            ->get(),
    ]);
}

    public function settings(Request $r)
    {
        $admin = $r->attributes->get('admin') ?? [];
        if (!in_array($admin['role'] ?? '', ['super_admin', 'game_operator'], true)) {
            return response()->json(['ok' => false, 'error' => 'Insufficient role'], 403);
        }

        $data = $r->validate([
            'settings' => 'required|array',
            'settings.maxCartelasPerPlayer' => 'sometimes|integer|min:1|max:200',
            'settings.rakePercent' => 'sometimes|numeric|min:0|max:99',
            'settings.selectionSeconds' => 'sometimes|integer|min:5|max:600',
            'settings.drawInterval' => 'sometimes|integer|min:1|max:60',
            'settings.enabledPatterns' => 'sometimes|array|min:1',
            'targetRoomId' => 'nullable|string|max:100',
            'reason' => 'nullable|string|max:200',
        ]);

        // No target room means "apply to every room"; otherwise only that room is changed.
        $target = $data['targetRoomId'] ?? null;

        try {
            $s = $this->game->updateSettings($data['settings'], $target);
        } catch (\RuntimeException $e) {
            return response()->json(['ok' => false, 'error' => $e->getMessage()], 422);
        }

        DB::table('admin_audit')->insert([
            'id' => (string) Str::uuid(),
            'timestamp' => now()->timestamp * 1000,
            'admin_email' => (string) ($admin['email'] ?? 'unknown'),
            'action' => 'SETTINGS_UPDATE',
            'target' => $target ?: 'all-rooms',
            'details' => json_encode(['settings' => $data['settings'], 'reason' => $data['reason'] ?? null]),
            'created_at' => now(),
        ]);

        return response()->json([
            'ok' => true,
            'settings' => $s,
            'rooms' => $this->game->rooms(),
            'appliedTo' => $target ?: 'all',
        ]);
    }

    public function killSwitch(Request $r)
    {
        $enabled = (bool) $r->input('enabled');

        DB::table('system_state')->updateOrInsert(
            ['key' => 'killSwitch'],
            [
                'value' => $enabled ? '1' : '0',
                'updated_at' => now(),
            ]
        );

        return response()->json([
            'ok' => true,
            'enabled' => $enabled,
        ]);
    }

    public function audit()
    {
        return response()->json([
            'ok' => true,
            'audit' => DB::table('admin_audit')
                ->latest('timestamp')
                ->limit(200)
                ->get(),
        ]);
    }

    public function gameAction(Request $r)
    {
        $a = (string) $r->input('action');
        $admin = $r->attributes->get('admin');

        $roles = match ($a) {
            'pause',
            'extend',
            'cancel' => [
                'super_admin',
                'game_operator',
            ],

            'adjust',
            'approveDeposit',
            'approveWithdrawal' => [
                'super_admin',
                'finance',
            ],

            default => [],
        };

        if (
            !$roles ||
            !in_array(
                $admin['role'],
                $roles,
                true
            )
        ) {
            return response()->json([
                'ok' => false,
                'error' => 'Insufficient role',
            ], 403);
        }

        try {
            return response()->json(
                match ($a) {
                    'pause' =>
                        $this->pause($r, $admin),

                    'extend' =>
                        $this->extend($r),

                    'adjust' =>
                        $this->adjust($r),

                    'approveDeposit' =>
                        $this->approveDeposit($r, $admin),

                    'approveWithdrawal' =>
                        $this->approveWithdrawal($r, $admin),

                    'cancel' =>
                        $this->cancel($r),

                    default =>
                        throw new RuntimeException(
                            'Unsupported admin game action'
                        ),
                }
            );
        } catch (\Throwable $e) {
            return response()->json([
                'ok' => false,
                'error' => $e->getMessage(),
            ], 400);
        }
    }

    private function pause($r, $a)
    {
        $id = (string) $r->input('roomId');

        $room = $this->game->room($id);

        $status = $room['status'] === 'paused'
            ? 'active'
            : 'paused';

        DB::table('game_rooms')
            ->where('id', $id)
            ->update([
                'status' => $status,
                'updated_at' => now(),
            ]);

        $this->writeAudit(
            $a,
            'ROOM_STATUS',
            $id,
            ['status' => $status]
        );

        return [
            'ok' => true,
            'status' => $status,
        ];
    }

    private function extend($r)
    {
        $q = $this->game->round(
            (string) $r->input('roomId')
        );

        $n = (int) $r->input('extraSeconds');

        if (
            $q->phase !== 'SELECTION' ||
            $n < 1 ||
            $n > 3600
        ) {
            throw new RuntimeException(
                'Invalid timer extension'
            );
        }

        $t = $q->timer_seconds + $n;

        DB::table('game_rounds')
            ->where('id', $q->id)
            ->update([
                'timer_seconds' => $t,
            ]);

        return [
            'ok' => true,
            'timerSeconds' => $t,
        ];
    }

    private function adjust($r)
    {
        $uid = (string) $r->input('userId');

        $wallet = $r->input('walletType') === 'PLAY'
            ? 'play_balance'
            : 'main_balance';

        $amount = (float) $r->input('amount');

        return DB::transaction(
            function () use ($uid, $wallet, $amount, $r) {
                $u = DB::table('users')
                    ->where('id', $uid)
                    ->lockForUpdate()
                    ->first();

                if (!$u) {
                    throw new RuntimeException(
                        'User not found'
                    );
                }

                $after = round(
                    (float) $u->{$wallet} + $amount,
                    2
                );

                if ($after < 0) {
                    throw new RuntimeException(
                        'Balance cannot be negative'
                    );
                }

                DB::table('users')
                    ->where('id', $uid)
                    ->update([
                        $wallet => $after,
                        'updated_at' => now(),
                    ]);

                DB::table('ledger')->insert([
                    'id' => (string) Str::uuid(),
                    'user_id' => $uid,
                    'type' => 'MANUAL_ADJUSTMENT',
                    'wallet_type' =>
                        $wallet === 'main_balance'
                            ? 'MAIN'
                            : 'PLAY',
                    'amount' => $amount,
                    'balance_after' => $after,
                    'reference_id' =>
                        'ADJ-' . Str::uuid(),
                    'description' =>
                        $r->input(
                            'reason',
                            'Admin adjustment'
                        ),
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);

                return [
                    'ok' => true,
                    'balanceAfter' => $after,
                ];
            }
        );
    }

    private function approveDeposit($r, $a)
    {
        // Deposits are always credited to the player's PLAYING wallet (never directly to the Main wallet).
        // When the receipt checker matched a settled amount, credit that amount rather than the payer's
        // total debit (which may include a payment fee). Manual-review deposits retain the submitted amount.
        $depositId = (string) $r->input('depositId');
        $deposit = DB::table('deposits')->where('id', $depositId)->where('status', 'pending')->first();
        if (!$deposit) {
            throw new RuntimeException('Deposit is not pending');
        }

        $options = ['notify' => true];
        if (
            WalletService::hasVerificationColumns()
            && ($deposit->verification_status ?? null) === 'verified'
            && (float) ($deposit->verified_amount ?? 0) > 0
        ) {
            $options['amount'] = (float) $deposit->verified_amount;
            // The receipt match was automatic; the wallet credit is still an explicit manual approval.
            $options['note'] = (string) ($deposit->verification_note ?? 'Receipt matched; approved by administrator.')
                . ' Approved manually by administrator.';
        }

        $result = app(\App\Services\WalletService::class)->creditDeposit(
            $depositId,
            (string) ($a['email'] ?? 'admin'),
            $options
        );

        return [
            'ok' => true,
            'playBalance' => $result['playBalance'],
        ];
    }
    private function approveWithdrawal($r, $a)
    {
        return DB::transaction(function () use ($r, $a) {
            $w = DB::table('withdrawals')->where(['id' => $r->input('withdrawalId'), 'status' => 'pending'])->lockForUpdate()->first();
            if (!$w) throw new RuntimeException('Withdrawal is not pending');

            // Backfill the internal transfer for requests created before house-ledger tracking.
            $requestRecorded = DB::table('house_ledger')->where(['type' => 'WITHDRAWAL_REQUEST', 'reference_id' => $w->id])->exists();
            if (!$requestRecorded) $this->houseWallet->post('WITHDRAWAL_REQUEST', (float) $w->amount, $w->id, 'Legacy player withdrawal request');
            $this->houseWallet->post('WITHDRAWAL_PAID', -(float) $w->amount, $w->id, 'Withdrawal approved/paid for '.$w->username);

            DB::table('withdrawals')->where('id', $w->id)->update([
                'status' => 'approved', 'reviewed_by' => $a['email'], 'reviewed_at' => now(),
            ]);
            return ['ok' => true];
        });
    }

    private function cancel($r)
    {
        return DB::transaction(
            function () use ($r) {
                $room = $this->game->room(
                    (string) $r->input('roomId')
                );

                $q = $this->game->round(
                    $room['id']
                );

                $cfg = array_merge(
                    $room,
                    json_decode(
                        $q->config,
                        true
                    ) ?: []
                );

                $xs = DB::table('cartela_reservations')
                    ->where('round_id', $q->id)
                    ->lockForUpdate()
                    ->get();

                foreach ($xs as $x) {
                    $u = DB::table('users')
                        ->where('id', $x->user_id)
                        ->lockForUpdate()
                        ->first();

                    if ((bool) ($u->is_bot ?? false)) {
                        $this->houseWallet->post('BOT_STAKE_REFUND', (float) $cfg['stake'], 'CANCEL-' . $q->id . ':' . $x->user_id, 'Round cancelled; automated participant stake refunded');
                        continue;
                    }

                    $w = $x->wallet_type === 'PLAY'
                        ? 'play_balance'
                        : 'main_balance';

                    $after = round(
                        (float) $u->{$w} +
                        (float) $cfg['stake'],
                        2
                    );

                    DB::table('users')
                        ->where('id', $u->id)
                        ->update([
                            $w => $after,
                            'updated_at' => now(),
                        ]);

                    DB::table('ledger')->insert([
                        'id' => (string) Str::uuid(),
                        'user_id' => $u->id,
                        'type' => 'STAKE_REFUNDED',
                        'wallet_type' => $x->wallet_type,
                        'amount' => (float) $cfg['stake'],
                        'balance_after' => $after,
                        'reference_id' =>
                            'CANCEL-' .
                            $q->id .
                            ':' .
                            $x->user_id,
                        'description' =>
                            'Round cancelled; stake refunded',
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);
                }

                DB::table('cartela_reservations')
                    ->where('round_id', $q->id)
                    ->delete();

                DB::table('game_rounds')
                    ->where('id', $q->id)
                    ->update([
                        'phase' => 'PAYOUT',
                        'timer_seconds' => 1,
                        'finished_at' => now(),
                    ]);

                return [
                    'ok' => true,
                ];
            }
        );
    }


    private function writeAudit($admin, $action, $target, $details)
    {
        DB::table('admin_audit')->insert([
            'id' => (string) Str::uuid(),
            'timestamp' => now()->timestamp * 1000,
            'admin_email' => $admin['email'],
            'action' => $action,
            'target' => $target,
            'details' => json_encode($details),
            'created_at' => now(),
        ]);
    }
}
