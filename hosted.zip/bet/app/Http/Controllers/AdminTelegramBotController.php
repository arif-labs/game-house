<?php

namespace App\Http\Controllers;

use App\Services\WalletService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Throwable;

class AdminTelegramBotController extends Controller
{
    public function webhook(Request $request)
    {
        $secret = (string) config('services.admin_telegram.webhook_secret', '');
        $provided = (string) $request->header('X-Telegram-Bot-Api-Secret-Token', '');
        if ($secret === '' || !hash_equals($secret, $provided)) {
            return response()->json(['ok' => false], 403);
        }

        $update = $request->all();
        $message = $update['message'] ?? null;
        $callback = $update['callback_query'] ?? null;
        $fromId = (string) ($message['from']['id'] ?? $callback['from']['id'] ?? '');
        $authorized = $this->allowed($fromId);
        Log::info('Admin Telegram webhook received update', [
            'update_id' => $update['update_id'] ?? null,
            'from_id' => $fromId,
            'authorized' => $authorized,
            'has_message' => (bool) $message,
            'has_callback' => (bool) $callback,
        ]);
        if (!$authorized) {
            if ($callback) $this->answerCallback((string) ($callback['id'] ?? ''), 'Access denied.');
            return response()->json(['ok' => true]);
        }

        try {
            if ($callback) {
                $this->handleCallback($callback, $fromId);
            } elseif ($message) {
                $chatId = (string) ($message['chat']['id'] ?? '');
                $command = trim((string) ($message['text'] ?? ''));
                if (in_array($command, ['/start', '/help', '/menu'], true)) {
                    $this->send($chatId, "Ethio Game House Admin Control Centre\n\nChoose an option below. Use Open Admin Dashboard for the full control panel.", $this->menuKeyboard());
                } elseif ($command === '/pending' || $command === '📥 Pending Deposits') {
                    $this->sendPending($chatId);
                } elseif ($command === '💸 Withdrawals') {
                    $this->sendWithdrawals($chatId);
                } elseif ($command === '🔁 Transfers') {
                    $this->sendTransfers($chatId);
                } elseif ($command === '👥 Players') {
                    $this->sendPlayers($chatId);
                } elseif ($command === '🎮 Games') {
                    $this->sendGames($chatId);
                } elseif ($command === '📊 Finance') {
                    $this->sendFinance($chatId);
                } elseif ($command === '🚨 System Alerts') {
                    $this->sendSystemAlerts($chatId);
                } elseif ($command === '🏠 Admin Menu') {
                    $this->send($chatId, 'Admin menu', $this->menuKeyboard());
                } else {
                    $this->send($chatId, 'Choose an option from the Admin Menu or use /pending.', $this->menuKeyboard());
                }
            }
        } catch (Throwable $e) {
            Log::error('Admin Telegram bot update failed: '.$e->getMessage());
            if ($callback) $this->answerCallback((string) ($callback['id'] ?? ''), 'Action failed. Check admin panel.');
        }

        return response()->json(['ok' => true]);
    }

    private function menuKeyboard(): array
    {
        $dashboardUrl = (string) config('services.admin_telegram.dashboard_url', '');
        if ($dashboardUrl === '') {
            $dashboardUrl = rtrim((string) config('app.url'), '/') . '/admin';
        }
        return [
            'keyboard' => [
                [['text' => '📥 Pending Deposits'], ['text' => '💸 Withdrawals']],
                [['text' => '🔁 Transfers'], ['text' => '👥 Players']],
                [['text' => '🎮 Games'], ['text' => '📊 Finance']],
                [['text' => '🚨 System Alerts'], ['text' => '🏠 Admin Menu']],
                [['text' => '🖥️ Open Admin Dashboard', 'web_app' => ['url' => $dashboardUrl]]],
            ],
            'resize_keyboard' => true,
            'is_persistent' => true,
            'input_field_placeholder' => 'Choose an admin action',
        ];
    }
    private function allowed(string $telegramId): bool
    {
        return $telegramId !== '' && in_array($telegramId, config('services.admin_telegram.admin_ids', []), true);
    }

    private function handleCallback(array $callback, string $adminId): void
    {
        $data = (string) ($callback['data'] ?? '');
        $chatId = (string) ($callback['message']['chat']['id'] ?? $adminId);
        if (!preg_match('/^dep:(approve|reject):([0-9a-f-]{36})$/i', $data, $m)) {
            $this->answerCallback((string) ($callback['id'] ?? ''), 'Unknown action.');
            return;
        }

        $depositId = $m[2];
        if ($m[1] === 'approve') {
            $deposit = DB::table('deposits')->where('id', $depositId)->where('status', 'pending')->first();
            if (!$deposit) {
                $this->answerCallback((string) ($callback['id'] ?? ''), 'Already reviewed or not found.');
                return;
            }
            $options = ['notify' => true, 'note' => 'Approved manually through Admin Telegram Bot.'];
            if (WalletService::hasVerificationColumns()
                && ($deposit->verification_status ?? null) === 'verified'
                && (float) ($deposit->verified_amount ?? 0) > 0) {
                $options['amount'] = (float) $deposit->verified_amount;
            }
            $result = app(WalletService::class)->creditDeposit($depositId, 'telegram:'.$adminId, $options);
            $this->audit($adminId, 'DEPOSIT_APPROVED_TELEGRAM', $depositId, ['amount' => $result['amount']]);
            $this->answerCallback((string) ($callback['id'] ?? ''), 'Deposit approved.');
            $this->send($chatId, "✅ Deposit approved\nPlayer: @{$result['username']}\nAmount: ".number_format($result['amount'], 2).' ETB');
            return;
        }

        $changed = DB::transaction(function () use ($depositId, $adminId) {
            $deposit = DB::table('deposits')->where('id', $depositId)->where('status', 'pending')->lockForUpdate()->first();
            if (!$deposit) return null;
            DB::table('deposits')->where('id', $depositId)->update([
                'status' => 'rejected', 'reviewed_by' => 'telegram:'.$adminId, 'reviewed_at' => now(),
            ]);
            if (WalletService::hasVerificationColumns()) {
                DB::table('deposits')->where('id', $depositId)->update([
                    'verification_status' => 'rejected',
                    'verification_note' => 'Rejected manually through Admin Telegram Bot.',
                ]);
            }
            return $deposit;
        });
        if (!$changed) {
            $this->answerCallback((string) ($callback['id'] ?? ''), 'Already reviewed or not found.');
            return;
        }
        $this->audit($adminId, 'DEPOSIT_REJECTED_TELEGRAM', $depositId, ['reference' => $changed->reference_no]);
        $this->answerCallback((string) ($callback['id'] ?? ''), 'Deposit rejected.');
        $this->send($chatId, "❌ Deposit rejected\nReference: {$changed->reference_no}");
    }

    private function sendPending(string $chatId): void
    {
        $items = DB::table('deposits')->where('status', 'pending')->orderBy('created_at')->limit(10)->get();
        if ($items->isEmpty()) {
            $this->send($chatId, 'No pending deposits.');
            return;
        }
        foreach ($items as $d) {
            $text = "⏳ Pending deposit\nPlayer: @{$d->username}\nAmount submitted: ".number_format((float) $d->amount, 2)." ETB\nProvider: ".($d->provider ?: 'Unknown')."\nReference: {$d->reference_no}\nID: {$d->id}";
            if (WalletService::hasVerificationColumns() && ($d->verification_status ?? '') === 'verified') {
                $text .= "\nReceipt match: ".number_format((float) ($d->verified_amount ?? 0), 2).' ETB';
            } else {
                $text .= "\nReceipt status: ".($d->verification_status ?? 'not checked');
            }
            $keyboard = ['inline_keyboard' => [[
                ['text' => 'Approve', 'callback_data' => 'dep:approve:'.$d->id],
                ['text' => 'Reject', 'callback_data' => 'dep:reject:'.$d->id],
            ]]];
            $this->send($chatId, $text, $keyboard);
        }
    }

    private function sendWithdrawals(string $chatId): void
    {
        $pending = DB::table('withdrawals')->where('status', 'pending')->orderBy('created_at')->limit(8)->get();
        $todayPaid = (float) DB::table('withdrawals')->where('status', 'approved')->whereDate('reviewed_at', today())->sum('amount');
        $text = "💸 WITHDRAWAL REQUESTS\n\nPending: ".DB::table('withdrawals')->where('status', 'pending')->count()
            ."\nApproved today: ".number_format($todayPaid, 2)." ETB";
        if ($pending->isEmpty()) {
            $text .= "\n\nNo pending withdrawal requests.";
        } else {
            foreach ($pending as $w) {
                $text .= "\n\n⏳ @{$w->username} — ".number_format((float) $w->amount, 2)." ETB"
                    ."\nProvider: {$w->provider}\nAccount: {$w->account_number}\nName: {$w->account_name}"
                    ."\nRequested: {$w->created_at}";
            }
        }
        $text .= "\n\nFor payout approval or rejection, use the authenticated Admin Dashboard.";
        $this->send($chatId, $text, $this->menuKeyboard());
    }

    private function sendTransfers(string $chatId): void
    {
        $query = DB::table('ledger')->whereIn('type', ['TRANSFER_OUT', 'TRANSFER_IN']);
        $today = (clone $query)->whereDate('created_at', today());
        $countToday = (clone $today)->where('type', 'TRANSFER_OUT')->count();
        $volumeToday = abs((float) (clone $today)->where('type', 'TRANSFER_OUT')->sum('amount'));
        $rows = DB::table('ledger')->leftJoin('users', 'users.id', '=', 'ledger.user_id')
            ->whereIn('ledger.type', ['TRANSFER_OUT', 'TRANSFER_IN'])
            ->orderByDesc('ledger.created_at')->limit(8)
            ->get(['ledger.type', 'ledger.amount', 'ledger.wallet_type', 'ledger.reference_id', 'ledger.created_at', 'users.username']);
        $text = "🔁 PLAYER TRANSFERS\n\nTransfers today: {$countToday}"
            ."\nTransfer volume today: ".number_format($volumeToday, 2)." ETB";
        if ($rows->isEmpty()) {
            $text .= "\n\nNo player transfers recorded yet.";
        } else {
            $text .= "\n\nRecent ledger entries:";
            foreach ($rows as $row) {
                $direction = $row->type === 'TRANSFER_OUT' ? 'Sent' : 'Received';
                $text .= "\n• {$direction}: @".($row->username ?: 'unknown')
                    ." — ".number_format(abs((float) $row->amount), 2)." ETB"
                    ." ({$row->wallet_type})\n  {$row->created_at}";
            }
        }
        $this->send($chatId, $text, $this->menuKeyboard());
    }

    private function sendPlayers(string $chatId): void
    {
        $players = DB::table('users')->where('is_bot', false);
        $total = (clone $players)->count();
        $today = (clone $players)->whereDate('created_at', today())->count();
        $active = DB::table('cartela_reservations')->join('users', 'users.id', '=', 'cartela_reservations.user_id')
            ->join('game_rounds', 'game_rounds.id', '=', 'cartela_reservations.round_id')
            ->where('users.is_bot', false)->where('cartela_reservations.status', 'confirmed')
            ->whereIn('game_rounds.phase', ['REGISTRATION', 'DRAWING'])->distinct('users.id')->count('users.id');
        $recent = DB::table('users')->where('is_bot', false)->orderByDesc('created_at')->limit(6)
            ->get(['username', 'full_name', 'main_balance', 'play_balance', 'created_at']);
        $text = "👥 PLAYER OVERVIEW\n\nRegistered players: {$total}\nJoined today: {$today}\nCurrently in live rounds: {$active}";
        if ($recent->isEmpty()) {
            $text .= "\n\nNo player accounts found.";
        } else {
            $text .= "\n\nRecently registered:";
            foreach ($recent as $u) {
                $text .= "\n• @{$u->username} — Main ".number_format((float) $u->main_balance, 2)
                    ." / Playing ".number_format((float) $u->play_balance, 2)." ETB";
            }
        }
        $this->send($chatId, $text, $this->menuKeyboard());
    }

    private function sendGames(string $chatId): void
    {
        $rooms = DB::table('game_rooms')->orderBy('name')->get();
        $text = "🎮 GAME & ROOM STATUS\n\n";
        foreach ($rooms as $room) {
            $round = DB::table('game_rounds')->where('room_id', $room->id)
                ->whereIn('phase', ['REGISTRATION', 'DRAWING', 'FINISHED', 'PAYOUT'])
                ->orderByDesc('created_at')->first();
            $text .= "🏠 {$room->name} — ".strtoupper((string) $room->status);
            if ($round) {
                $players = DB::table('cartela_reservations')->where('round_id', $round->id)
                    ->where('status', 'confirmed')->count();
                $text .= "\nRound: {$round->round_code} ({$round->phase})\nConfirmed cards: {$players}";
            } else {
                $text .= "\nNo current round record.";
            }
            $text .= "\n\n";
        }
        if ($rooms->isEmpty()) $text .= "No game rooms configured.";
        $text .= "For game controls and room settings, use the Admin Dashboard.";
        $this->send($chatId, $text, $this->menuKeyboard());
    }

    private function sendFinance(string $chatId): void
    {
        $deposits = (float) DB::table('deposits')->where('status', 'approved')->sum('amount');
        $withdrawals = (float) DB::table('withdrawals')->where('status', 'approved')->sum('amount');
        $pendingDeposits = (int) DB::table('deposits')->where('status', 'pending')->count();
        $pendingWithdrawals = (int) DB::table('withdrawals')->where('status', 'pending')->count();
        $payouts = (float) DB::table('ledger')->where('type', 'WIN_PAYOUT')->sum('amount');
        $transfers = abs((float) DB::table('ledger')->where('type', 'TRANSFER_OUT')->sum('amount'));
        $text = "📊 FINANCE SUMMARY\n\nApproved deposits: ".number_format($deposits, 2)." ETB"
            ."\nApproved withdrawals: ".number_format($withdrawals, 2)." ETB"
            ."\nWinner payouts: ".number_format($payouts, 2)." ETB"
            ."\nPlayer transfer volume: ".number_format($transfers, 2)." ETB"
            ."\n\nPending deposits: {$pendingDeposits}\nPending withdrawals: {$pendingWithdrawals}"
            ."\nNet deposits less withdrawals: ".number_format($deposits - $withdrawals, 2)." ETB"
            ."\n\nFigures are database totals, not a bank reconciliation.";
        $this->send($chatId, $text, $this->menuKeyboard());
    }

    private function sendSystemAlerts(string $chatId): void
    {
        $alerts = [];
        $killSwitch = DB::table('system_state')->where('key', 'killSwitch')->value('value');
        if ($killSwitch === '1') $alerts[] = '🛑 Global kill switch is ON.';
        $unverified = DB::table('deposits')->where('status', 'pending')
            ->where(function ($q) {
                if (WalletService::hasVerificationColumns()) {
                    $q->whereNull('verification_status')->orWhereNotIn('verification_status', ['verified', 'rejected']);
                } else {
                    $q->whereRaw('1 = 1');
                }
            })->count();
        if ($unverified > 0) $alerts[] = "⚠️ {$unverified} pending deposit(s) need receipt review.";
        $states = DB::table('system_state')->where('key', 'like', 'bot_status:%')->orderBy('key')->get();
        foreach ($states as $state) {
            $data = json_decode((string) $state->value, true) ?: [];
            if (($data['status'] ?? '') === 'blocked') {
                $messages = array_slice($data['messages'] ?? [], 0, 2);
                $alerts[] = '⚠️ '.substr((string) $state->key, 11).': '.implode(' ', $messages);
            }
        }
        $pendingW = DB::table('withdrawals')->where('status', 'pending')->count();
        if ($pendingW > 0) $alerts[] = "ℹ️ {$pendingW} withdrawal request(s) are awaiting admin review.";
        $text = "🚨 SYSTEM ALERTS\n\n";
        $text .= $alerts ? implode("\n\n", array_slice($alerts, 0, 12)) : "No active alerts recorded in the database.";
        $text .= "\n\nChecked: ".now()->format('Y-m-d H:i:s');
        $this->send($chatId, $text, $this->menuKeyboard());
    }

    public function notifyPendingDeposits(): int
    {
        $token = (string) config('services.admin_telegram.bot_token', '');
        $ids = config('services.admin_telegram.admin_ids', []);
        if ($token === '' || !$ids || !DB::getSchemaBuilder()->hasColumn('deposits', 'admin_notified_at')) return 0;
        $items = DB::table('deposits')->where('status', 'pending')->whereNull('admin_notified_at')->orderBy('created_at')->limit(30)->get();
        $sent = 0;
        foreach ($items as $d) {
            $text = "🔔 New deposit pending\nPlayer: @{$d->username}\nAmount: ".number_format((float) $d->amount, 2)." ETB\nProvider: ".($d->provider ?: 'Unknown')."\nReference: {$d->reference_no}\nUse /pending to review.";
            $allSent = true;
            foreach ($ids as $id) $allSent = $this->send((string) $id, $text) && $allSent;
            if ($allSent) {
                DB::table('deposits')->where('id', $d->id)->whereNull('admin_notified_at')->update(['admin_notified_at' => now()]);
                $sent++;
            }
        }
        return $sent;
    }

    private function audit(string $adminId, string $action, string $target, array $details): void
    {
        DB::table('admin_audit')->insert([
            'id' => (string) Str::uuid(), 'timestamp' => now()->timestamp * 1000,
            'admin_email' => 'telegram:'.$adminId, 'action' => $action, 'target' => $target,
            'details' => json_encode($details, JSON_UNESCAPED_UNICODE), 'created_at' => now(),
        ]);
    }

    private function send(string $chatId, string $text, ?array $keyboard = null): bool
    {
        $token = (string) config('services.admin_telegram.bot_token', '');
        if ($token === '' || $chatId === '') return false;
        $payload = ['chat_id' => $chatId, 'text' => $text];
        if ($keyboard) $payload['reply_markup'] = $keyboard;
        try {
            $response = Http::timeout(8)->connectTimeout(5)->post("https://api.telegram.org/bot{$token}/sendMessage", $payload);
            return $response->ok() && (bool) $response->json('ok');
        } catch (Throwable $e) {
            Log::warning('Admin Telegram send failed: '.$e->getMessage());
            return false;
        }
    }

    private function answerCallback(string $callbackId, string $text): void
    {
        $token = (string) config('services.admin_telegram.bot_token', '');
        if ($token === '' || $callbackId === '') return;
        try {
            Http::timeout(5)->post("https://api.telegram.org/bot{$token}/answerCallbackQuery", [
                'callback_query_id' => $callbackId, 'text' => $text,
            ]);
        } catch (Throwable) {
        }
    }
}
