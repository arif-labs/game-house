<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Resend, Postmark, AWS, and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'postmark' => [
        'key' => env('POSTMARK_API_KEY'),
    ],

    'resend' => [
        'key' => env('RESEND_API_KEY'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],

'telegram' => [
    'bot_token' => env('TELEGRAM_BOT_TOKEN'),
    // Allow a custom trusted CA bundle for Windows/XAMPP installations.
    'ca_bundle' => env('TELEGRAM_CA_BUNDLE') ?: (
        PHP_OS_FAMILY === 'Windows' && file_exists('C:/xampp/apache/bin/curl-ca-bundle.crt')
            ? 'C:/xampp/apache/bin/curl-ca-bundle.crt'
            : null
    ),
],

    'admin_telegram' => [
        'bot_token' => env('ADMIN_BOT_TOKEN'),
        'admin_ids' => array_values(array_filter(array_map('trim', explode(',', (string) env('ADMIN_TELEGRAM_ADMIN_IDS', ''))))),
        'webhook_secret' => env('ADMIN_BOT_WEBHOOK_SECRET'),
        'dashboard_url' => env('ADMIN_DASHBOARD_URL', rtrim((string) env('APP_URL'), '/') . '/admin'),
    ],

    'admin_auth' => [
        'email' => env('ADMIN_EMAIL', 'admin@example.com'),
        'password' => env('ADMIN_PASSWORD'),
        'password_hash' => env('ADMIN_PASSWORD_HASH'),
        'name' => env('ADMIN_NAME', 'System Administrator'),
        'role' => env('ADMIN_ROLE', 'super_admin'),
        'session_ttl' => (int) env('ADMIN_SESSION_TTL', 28800),
    ],

    'telegram_support' => [
        'username' => env('TELEGRAM_SUPPORT_USERNAME', ''),
    ],

    /*
    |--------------------------------------------------------------------------
    | Automatic deposit verification (Telebirr receipt page + Verify.ET for CBE Birr)
    |--------------------------------------------------------------------------
    */
    'deposit_verifier' => [
        'enabled' => env('DEPOSIT_AUTO_VERIFY', true),
        'timeout' => (int) env('DEPOSIT_VERIFY_TIMEOUT', 12),
        'max_attempts' => (int) env('DEPOSIT_VERIFY_MAX_ATTEMPTS', 12),
        'max_age_hours' => (int) env('DEPOSIT_VERIFY_MAX_AGE_HOURS', 72),
        'require_payer_match' => env('DEPOSIT_VERIFY_REQUIRE_PAYER_MATCH', true),
        'verify_ssl' => env('DEPOSIT_VERIFY_SSL', true),
        // Ethio Telecom only answers Ethiopian IPs. From a server abroad, point TELEBIRR_RELAY_URL at a relay
        // inside Ethiopia that returns the same receipt HTML (use {ref} for the reference, or it is appended).
        'telebirr_receipt_url' => env('TELEBIRR_RECEIPT_URL', 'https://transactioninfo.ethiotelecom.et/receipt/'),
        'telebirr_relay_url' => env('TELEBIRR_RELAY_URL'),
        'verifyet_url' => env('VERIFYET_URL', 'https://verify.et'),
        'verifyet_key' => env('VERIFYET_API_KEY'),
    ],
];
