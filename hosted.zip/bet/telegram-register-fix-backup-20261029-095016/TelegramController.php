<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class TelegramController
{
    use \App\Services\TelegramWalletFlows;

    private function botToken(): string
    {
        return trim((string) config('services.telegram.bot_token', ''));
    }

    private function telegram(string $token, string $method, array $data = []): array
    {
        if ($token === '' || strlen($token) > 256) {
            return ['ok' => false, 'description' => 'Telegram bot token is missing or invalid.'];
        }

        try {
            // Force IPv4: this Windows environment cannot reliably resolve/reach Telegram over IPv6.
            $client = Http::connectTimeout(10)->timeout(25)
                ->withOptions(['force_ip_resolve' => 'v4']);
            $caBundle = config('services.telegram.ca_bundle');

            if (is_string($caBundle) && $caBundle !== '') {
                $client = $client->withOptions(['verify' => $caBundle]);
            }

            $response = $client->post("https://api.telegram.org/bot{$token}/{$method}", $data);

            $json = $response->json();

            if (!is_array($json)) {
                return ['ok' => false, 'description' => 'Telegram returned an invalid response.'];
            }

            return $json;
        } catch (\Throwable $e) {
            Log::warning('Telegram API request failed', [
                'method' => $method,
                'error' => $e->getMessage(),
            ]);

            return ['ok' => false, 'description' => 'Could not connect to the Telegram API.'];
        }
    }

    public function publicBotLink()
    {
        $token = $this->botToken();
        if ($token === '') {
            return response()->json(['ok' => false, 'error' => 'Telegram bot is not configured.'], 503);
        }
        $me = $this->telegram($token, 'getMe');
        $username = $me['result']['username'] ?? null;
        if (!($me['ok'] ?? false) || !is_string($username) || $username === '') {
            return response()->json(['ok' => false, 'error' => 'Could not find the Telegram bot username.'], 503);
        }
        return response()->json(['ok' => true, 'url' => 'https://t.me/' . $username . '?start=share_phone']);
    }

    public function status()
    {
        $token = $this->botToken();

        if ($token === '') {
            return response()->json([
                'ok' => true,
                'hasTokenConfigured' => false,
                'maskedToken' => null,
                'bot' => null,
                'webhook' => null,
                'message' => 'Set TELEGRAM_BOT_TOKEN in the server .env file.',
            ]);
        }

        $me = $this->telegram($token, 'getMe');
        $webhook = $this->telegram($token, 'getWebhookInfo');

        return response()->json([
            'ok' => true,
            'hasTokenConfigured' => true,
            'maskedToken' => substr($token, 0, 5) . '••••••',
            'bot' => $me['result'] ?? null,
            'webhook' => $webhook['result'] ?? null,
            'telegramConnected' => (bool) ($me['ok'] ?? false),
            'webhookError' => ($webhook['ok'] ?? false)
                ? null
                : ($webhook['description'] ?? 'Could not read webhook status.'),
        ]);
    }

    public function registerWebhook(Request $request)
    {
        $token = trim((string) $request->input('botToken', ''))
            ?: $this->botToken();

        $appUrl = rtrim(trim((string) $request->input('appUrl', '')), '/');
        $appUrlParts = parse_url($appUrl);

        // The dashboard currently submits window.location.origin, which may be localhost.
        // Fall back to the configured public APP_URL when the submitted URL is not public HTTPS.
        if (
            !$appUrlParts ||
            strtolower($appUrlParts['scheme'] ?? '') !== 'https' ||
            empty($appUrlParts['host']) ||
            isset($appUrlParts['user']) ||
            isset($appUrlParts['pass'])
        ) {
            $appUrl = rtrim(trim((string) config('app.url')), '/');
        }

        if ($token === '') {
            return response()->json([
                'ok' => false,
                'error' => 'Set TELEGRAM_BOT_TOKEN in your .env file first.',
            ], 422);
        }

        if (strlen($token) > 256 || !preg_match('/^\d+:[A-Za-z0-9_-]+$/', $token)) {
            return response()->json([
                'ok' => false,
                'error' => 'The bot token format is invalid.',
            ], 422);
        }

        $parts = parse_url($appUrl);

        if (
            !$parts ||
            strtolower($parts['scheme'] ?? '') !== 'https' ||
            empty($parts['host']) ||
            isset($parts['user']) ||
            isset($parts['pass'])
        ) {
            return response()->json([
                'ok' => false,
                'error' => 'Use the public HTTPS URL of your app. localhost and 127.0.0.1 will not work for Telegram webhooks.',
            ], 422);
        }

        $me = $this->telegram($token, 'getMe');

        if (!($me['ok'] ?? false)) {
            return response()->json([
                'ok' => false,
                'error' => $me['description'] ?? 'Telegram rejected the bot token.',
            ], 422);
        }

        $webhookUrl = $appUrl . '/api/telegram/webhook';

        $webhook = $this->telegram($token, 'setWebhook', [
            'url' => $webhookUrl,
            'allowed_updates' => ['message'],
        ]);

        if (!($webhook['ok'] ?? false)) {
            return response()->json([
                'ok' => false,
                'error' => $webhook['description'] ?? 'Telegram failed to register the webhook.',
                'webhookResponse' => $webhook,
            ], 422);
        }

        // Make Play Game the persistent bot menu button. Telegram launches it as
        // a Mini App and provides signed initData for server-side verification.
        $menu = $this->telegram($token, 'setChatMenuButton', [
            'menu_button' => [
                'type' => 'web_app',
                'text' => 'Play Game',
                'web_app' => ['url' => $appUrl],
            ],
        ]);

        return response()->json([
            'ok' => true,
            'webhookUrl' => $webhookUrl,
            'bot' => $me['result'] ?? null,
            'webhookResponse' => $webhook,
            'menuButtonConfigured' => (bool) ($menu['ok'] ?? false),
            'menuButtonError' => ($menu['ok'] ?? false)
                ? null
                : ($menu['description'] ?? 'Webhook registered, but menu-button setup failed.'),
            'message' => ($menu['ok'] ?? false)
                ? 'Webhook and Mini App menu button configured.'
                : 'Webhook registered; menu-button setup needs attention.',
        ]);
    }

    public function verifyInitData(Request $request)
    {
        $token = $this->botToken();

        if ($token === '') {
            return response()->json([
                'ok' => false,
                'error' => 'Set TELEGRAM_BOT_TOKEN in the server .env file first.',
            ], 503);
        }

        $initData = (string) $request->input('initData', '');

        $result = $this->validateInitData($initData, $token);

        return response()->json([
            'ok' => $result['ok'],
            'valid' => $result['ok'],
            'error' => $result['error'] ?? null,
            'user' => $result['user'] ?? null,
        ], $result['ok'] ? 200 : 422);
    }

    private function validateInitData(string $initData, string $token): array
    {
        if ($initData === '' || strlen($initData) > 20000) {
            return ['ok' => false, 'error' => 'Missing or oversized initData.'];
        }

        parse_str($initData, $fields);

        $hash = (string) ($fields['hash'] ?? '');
        unset($fields['hash']);

        if (!preg_match('/^[a-f0-9]{64}$/i', $hash)) {
            return ['ok' => false, 'error' => 'Missing or invalid hash.'];
        }

        ksort($fields);

        $checkString = collect($fields)
            ->map(fn ($value, $key) => $key . '=' . $value)
            ->implode("\n");

        $secret = hash_hmac('sha256', $token, 'WebAppData', true);
        $expected = hash_hmac('sha256', $checkString, $secret);

        if (!hash_equals($expected, $hash)) {
            return ['ok' => false, 'error' => 'Invalid Telegram initData signature.'];
        }

        $authDate = (int) ($fields['auth_date'] ?? 0);

        if ($authDate <= 0 || $authDate > time() + 30 || time() - $authDate > 86400) {
            return ['ok' => false, 'error' => 'Telegram initData is expired or has an invalid auth_date.'];
        }

        $user = json_decode((string) ($fields['user'] ?? '{}'), true);

        if (!is_array($user) || !isset($user['id'])) {
            return ['ok' => false, 'error' => 'Telegram user data is missing.'];
        }

        return ['ok' => true, 'user' => $user];
    }

    private function supportContact(): string
    {
        $stored = DB::table('system_state')->where('key', 'telegram_bot_config')->value('value');
        $saved = is_string($stored) ? json_decode($stored, true) : null;
        $username = trim((string) (is_array($saved) ? ($saved['supportUsername'] ?? '') : ''));
        if ($username === '') {
            $username = trim((string) env('TELEGRAM_SUPPORT_USERNAME', ''));
        }
        $username = ltrim($username, '@');
        return $username !== '' ? 'https://t.me/' . $username : '';
    }

    private function defaultBotConfig(): array
    {
        return [
            'welcomeMessage' => "🎉 እንኳን ወደ Ethio Bingo · ኢትዮ ቢንጎ በደህና መጡ!\\n\\nከታች ያሉትን አማራጮች ይምረጡ። ጨዋታው የሚከፈተው Play ሲጫኑ ብቻ ነው።",
            'helpMessage' => 'ከታች ካሉት አማራጮች ይምረጡ።',
            'fallbackMessage' => 'ይቅርታ፣ ይህን አልተረዳሁትም። ከታች ካሉት የምናሌ አማራጮች አንዱን ይምረጡ።',
            'referralBonusEnabled' => true,
            'referralBonusAmount' => 10,
            'transferEnabled' => true,
            'transferMinAmount' => 1,
            'transferMaxAmount' => 10000,
            'supportUsername' => '',
            'options' => [
                ['id'=>'balance','label'=>'Check balance','enabled'=>true,'response'=>"💰 የሂሳብዎ ማጠቃለያ\\nPlaying wallet: {play_balance} ETB\\nMain wallet (winnings): {main_balance} ETB"],
                ['id'=>'support','label'=>'Contact support','enabled'=>true,'response'=>"🆘 የድጋፍ መረጃን በPlay Game Mini App ውስጥ ያግኙ። {support_contact}"],
                ['id'=>'transfer','label'=>'Transfer balance','enabled'=>true,'response'=>"🔁 የሂሳብ ማስተላለፍ። ከMain ወይም ከPlaying wallet ይላካል፤ ተቀባዩ በPlaying wallet ይቀበላል።"],
                ['id'=>'invite','label'=>'Invite','enabled'=>true,'response'=>"🎁 ጓደኞችዎን በዚህ ሊንክ ይጋብዙ፦ {referral_link}። ጓደኛዎ ምዝገባ አድርጎ ጨዋታ ሲቀላቀል ሁለታችሁም {referral_bonus} ETB Play Bonus ታገኛላችሁ።"],
                ['id'=>'register','label'=>'Register','enabled'=>true,'response'=>"📝 ለመመዝገብ የስልክ ቁጥርዎን በ«ስልክ ቁጥር አጋራ» ቁልፍ ያጋሩ፣ ከዚያ Play ይጫኑ።"],
                ['id'=>'deposit','label'=>'Deposit','enabled'=>true,'response'=>"💳 ገንዘብ ለማስገባት Play ይጫኑ፣ ከዚያ Deposit ይምረጡ። ክፍያ እስኪረጋገጥ ድረስ ቀሪ ሂሳብዎ አይጨምርም።"],
                ['id'=>'instructions','label'=>'Game instructions','enabled'=>true,'response'=>"📖 የጨዋታ መመሪያ፦\\n1. ይመዝገቡ።\\n2. በቂ ሂሳብ ይኑርዎት።\\n3. Play ይጫኑ፣ ክፍል እና ካርቴላ ይምረጡ።\\n4. ቁጥሮችን ይከታተሉ፤ Bingo ይጫኑ።"],
                ['id'=>'withdraw','label'=>'Withdraw','enabled'=>true,'response'=>"💸 ገንዘብ ለማውጣት Play ይጫኑ፣ Withdraw ይምረጡና የሚፈለገውን መረጃ ያስገቡ።"],
            ],
        ];
    }

    public function botConfig()
    {
        $row = DB::table('system_state')->where('key', 'telegram_bot_config')->first();
        $saved = $row ? json_decode((string) $row->value, true) : null;
        $defaults = $this->defaultBotConfig();
        if (!is_array($saved)) $saved = [];
        $config = array_merge($defaults, array_intersect_key($saved, $defaults));
        $savedOptions = is_array($saved['options'] ?? null) ? $saved['options'] : [];
        $byId = [];
        foreach ($savedOptions as $option) {
            if (is_array($option) && isset($option['id'])) $byId[$option['id']] = $option;
        }
        $config['options'] = array_map(function ($option) use ($byId) {
            $savedOption = $byId[$option['id']] ?? [];
            return [
                'id' => $option['id'],
                'label' => (string) ($savedOption['label'] ?? $option['label']),
                'enabled' => (bool) ($savedOption['enabled'] ?? $option['enabled']),
                'response' => (string) ($savedOption['response'] ?? $option['response']),
            ];
        }, $defaults['options']);
        return response()->json(['ok' => true, 'config' => $config]);
    }

    public function saveBotConfig(Request $request)
    {
        $admin = $request->attributes->get('admin') ?? [];
        if (!in_array($admin['role'] ?? '', ['super_admin', 'game_operator'], true)) {
            return response()->json(['ok' => false, 'error' => 'Insufficient role'], 403);
        }
        $data = $request->validate([
            'welcomeMessage' => 'required|string|max:1500',
            'helpMessage' => 'required|string|max:1000',
            'fallbackMessage' => 'required|string|max:1000',
            'options' => 'required|array|size:8',
            'options.*.id' => 'required|in:balance,support,transfer,invite,register,deposit,instructions,withdraw',
            'options.*.label' => 'required|string|min:2|max:32',
            'options.*.enabled' => 'required|boolean',
            'options.*.response' => 'required|string|max:1500',
            'referralBonusEnabled' => 'required|boolean',
            'referralBonusAmount' => 'required|numeric|min:0|max:10000',
            'transferEnabled' => 'required|boolean',
            'transferMinAmount' => 'required|numeric|min:1|max:100000',
            'transferMaxAmount' => 'required|numeric|min:1|max:100000',
            'supportUsername' => ['nullable', 'string', 'max:32', 'regex:/^@?[A-Za-z0-9_]{5,32}$/'],
        ]);
        $data['supportUsername'] = ltrim(trim((string) ($data['supportUsername'] ?? '')), '@');
        $ids = array_column($data['options'], 'id');
        if (count(array_unique($ids)) !== 8) {
            return response()->json(['ok' => false, 'error' => 'Each bot menu option must appear exactly once.'], 422);
        }
        if ((float) $data['transferMaxAmount'] < (float) $data['transferMinAmount']) {
            return response()->json(['ok' => false, 'error' => 'Transfer maximum must be greater than or equal to the minimum.'], 422);
        }
        DB::table('system_state')->updateOrInsert(
            ['key' => 'telegram_bot_config'],
            ['value' => json_encode($data, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR), 'updated_at' => now()]
        );
        DB::table('admin_audit')->insert([
            'id' => (string) \Illuminate\Support\Str::uuid(),
            'timestamp' => now()->timestamp * 1000,
            'admin_email' => (string) ($admin['email'] ?? 'unknown'),
            'action' => 'TELEGRAM_BOT_CONFIG_UPDATED',
            'target' => 'telegram_bot_config',
            'details' => json_encode(['enabledOptions' => collect($data['options'])->where('enabled', true)->pluck('id')->values()->all()]),
            'created_at' => now(),
        ]);
        return response()->json(['ok' => true, 'config' => $data]);
    }

    public function webhook(Request $request)
    {
        $update = $request->all();
        $message = $update['message'] ?? null;
        $chatId = $message['chat']['id'] ?? null;

        if (!$message || $chatId === null) {
            return response()->json(['ok' => true]);
        }

        // Accept only a contact that Telegram confirms belongs to the sender.
        $contact = $message['contact'] ?? null;
        if (is_array($contact)) {
            $telegramId = (string) ($message['from']['id'] ?? '');
            $contactOwner = (string) ($contact['user_id'] ?? '');
            $phone = trim((string) ($contact['phone_number'] ?? ''));

            if ($telegramId === '' || $contactOwner === '' || $telegramId !== $contactOwner || $phone === '') {
                $reply = $this->commandReply('/start share_phone', (int) $chatId);
                $reply['text'] = 'Please use the button below to share your own phone number.';
                $this->telegram($this->botToken(), 'sendMessage', $reply);
                return response()->json(['ok' => true]);
            }

            $phone = substr($phone, 0, 32);
            $user = DB::table('users')->where('telegram_id', $telegramId)->first();

            if ($user) {
                DB::table('users')->where('id', $user->id)->update([
                    'phone' => $phone,
                    'phone_verified_at' => now(),
                    'updated_at' => now(),
                ]);
            } else {
                DB::table('telegram_pending_contacts')->updateOrInsert(
                    ['telegram_id' => $telegramId],
                    ['phone' => $phone, 'received_at' => now()]
                );
            }

            $reply = $this->commandReply('/start', (int) $chatId);
            $reply['text'] = 'Phone number verified successfully. Return to Ethio Bingo and continue playing.';
            // Give the player a direct, signed Mini App launch after successful sharing.
            $reply['reply_markup'] = [
                'inline_keyboard' => [[
                    [
                        'text' => 'Play Game',
                        'web_app' => ['url' => rtrim((string) config('app.url'), '/')],
                    ],
                ]],
            ];
            $this->telegram($this->botToken(), 'sendMessage', $reply);
            return response()->json(['ok' => true]);
        }

        $text = trim((string) ($message['text'] ?? ''));
        if ($text === '') {
            return response()->json(['ok' => true]);
        }

        // Preserve a valid inviter from Telegram's /start referral deep link until the
        // new Telegram identity creates its first player account.
        if (preg_match('/^\/start\s+ref_([A-Z0-9]{6,24})$/i', $text, $refMatch)) {
            $senderTelegramId = (string) ($message['from']['id'] ?? '');
            $referrer = DB::table('users')->where('referral_code', strtoupper($refMatch[1]))->first();
            $alreadyRegistered = $senderTelegramId !== '' && DB::table('users')->where('telegram_id', $senderTelegramId)->exists();
            if ($senderTelegramId !== '' && !$alreadyRegistered && $referrer && (string) $referrer->telegram_id !== $senderTelegramId) {
                DB::table('telegram_referrals')->updateOrInsert(
                    ['telegram_id' => $senderTelegramId],
                    ['referral_code' => strtoupper($refMatch[1]), 'created_at' => now(), 'updated_at' => now()]
                );
            }
        }

        $reply = $this->commandReply($text, (int) $chatId);

        // Return a preview for the admin simulator's synthetic updates.
        if (
            (int) ($update['update_id'] ?? 0) >= 100000 &&
            (int) ($update['update_id'] ?? 0) <= 999999 &&
            ($message['from']['username'] ?? '') === 'dawit_tg'
        ) {
            return response()->json(['ok' => true, 'simulatedReply' => $reply]);
        }

        $token = $this->botToken();
        if ($token !== '') {
            $sent = $this->telegram($token, 'sendMessage', [
                'chat_id' => $chatId,
                'text' => $reply['text'],
                'reply_markup' => $reply['reply_markup'] ?? null,
            ]);

            if (!($sent['ok'] ?? false)) {
                Log::warning('Telegram sendMessage failed', [
                    'description' => $sent['description'] ?? 'Unknown error',
                ]);
            }

            // Keyboard-button Mini Apps may have empty initData. Use an inline
            // web_app button for launch commands so Telegram includes signed initData.
            $requestedText = mb_strtolower(trim((string) ($message['text'] ?? '')));
            $requestedParts = preg_split('/\s+/', $requestedText);
            $requestedCommand = $requestedParts[0] ?? '';
            $startPayload = $requestedCommand === '/start' ? ($requestedParts[1] ?? '') : '';
            // The share_phone deep link must show the contact-request button first.
            // Do not offer the Mini App until Telegram has returned the contact.
            $isPhoneSharingStart = $requestedCommand === '/start' && $startPayload === 'share_phone';
            $showMiniAppButton = !$isPhoneSharingStart && (in_array($requestedCommand, [
                '/start', '/menu', 'menu', '/play', 'play', '/help',
                'check', 'contact', 'transfer', 'invite', 'register',
                'game',
            ], true) || in_array($requestedText, [
                'check balance', 'contact support', 'transfer balance',
                'game instructions',
            ], true));

            if ($showMiniAppButton) {
                $launch = $this->telegram($token, 'sendMessage', [
                    'chat_id' => $chatId,
                    'text' => '🎮 ለመጫወት ከታች ያለውን Play ቁልፍ ይጫኑ።',
                    'reply_markup' => [
                        'inline_keyboard' => [[
                            [
                                'text' => 'Play',
                                'web_app' => ['url' => rtrim((string) config('app.url'), '/')],
                            ],
                        ]],
                    ],
                ]);

                if (!($launch['ok'] ?? false)) {
                    Log::warning('Telegram Mini App launch button failed', [
                        'description' => $launch['description'] ?? 'Unknown error',
                    ]);
                }
            }
        }

        return response()->json(['ok' => true]);
    }

    private function commandReply(string $command, int $chatId): array
    {
        $raw = trim($command);
        $lower = mb_strtolower($raw);
        $parts = preg_split('/\s+/', $lower);
        $slashCommand = $parts[0] ?? '';
        $storedConfig = DB::table('system_state')->where('key', 'telegram_bot_config')->value('value');
        $savedConfig = is_string($storedConfig) ? json_decode($storedConfig, true) : null;
        $botConfig = array_merge($this->defaultBotConfig(), is_array($savedConfig) ? $savedConfig : []);
        $options = collect($botConfig['options'] ?? [])->keyBy('id');
        $selectedOptionId = null;
        foreach ($options as $option) {
            if (!empty($option['enabled']) && mb_strtolower(trim((string) ($option['label'] ?? ''))) === $lower) {
                $selectedOptionId = $option['id'];
                break;
            }
        }

        $appUrl = rtrim((string) config('app.url'), '/');
        // Keep regular actions on the reply keyboard. The Play launch button is sent
        // separately as an inline web_app button so Telegram supplies signed initData.
        $enabledButtons = collect($botConfig['options'] ?? [])->filter(fn ($option) => !empty($option['enabled']))->map(fn ($option) => ['text' => (string) $option['label']])->values()->all();
        if (!collect($enabledButtons)->contains(fn ($button) => mb_strtolower(trim((string) ($button['text'] ?? ''))) === 'language | ቋንቋ')) {
            $enabledButtons[] = ['text' => 'language | ቋንቋ'];
        }
        $keyboard = array_chunk($enabledButtons, 2);
        if (!$keyboard) $keyboard = [[['text' => 'Play Game']]];

        $menu = [
            'keyboard' => $keyboard,
            'resize_keyboard' => true,
            'one_time_keyboard' => false,
            'is_persistent' => true,
        ];

        $messages = [
            'check balance' => "💰 ቀሪ ሂሳብዎን በደህና ለማየት Play Game ይክፈቱና Wallet ይምረጡ።",
            'contact support' => "🆘 የድጋፍ መረጃን እና የእርዳታ አማራጮችን በPlay Game Mini App ውስጥ ያግኙ።" . ($this->supportContact() !== '' ? " አስፈላጊ ከሆነ " . $this->supportContact() . " ያነጋግሩ።" : ''),
            'transfer balance' => "🔁 የተጫዋቾች መካከል ቀጥታ የሂሳብ ማስተላለፍ አሁን አልነቃም። እባክዎ የድጋፍ ቡድኑን ያነጋግሩ።",
            'invite' => "🎁 ጓደኞችዎን ወደ Ethio Bingo ይጋብዙ፦ https://t.me/ethiobingobet_bot\nየግል የሪፈራል ሽልማት መከታተያ ከነቃ የሚመለከተው የሽልማት መመሪያ ይተገበራል።",
            'register' => "📝 ለመመዝገብ የስልክ ቁጥርዎን በ«ስልክ ቁጥር አጋራ» ቁልፍ ያጋሩ፣ ከዚያ Play ይጫኑና ምዝገባዎን ያጠናቅቁ።",
            'deposit' => "💳 ገንዘብ ለማስገባት Play ይጫኑ፣ ከዚያ Deposit ይምረጡና የክፍያ መመሪያዎቹን ይከተሉ። ክፍያ እስኪረጋገጥ ድረስ ቀሪ ሂሳብዎ አይጨምርም።",
            'game instructions' => "📖 የጨዋታ መመሪያ፦\n1. ስልክ ቁጥርዎን ያረጋግጡና ይመዝገቡ።\n2. በMain Balance ወይም Play Balance በቂ ሂሳብ ይኑርዎት።\n3. Play ይጫኑ፣ ክፍል እና ካርቴላ ይምረጡ።\n4. ቁጥሮችን ይከታተሉ፤ የአሸናፊነት ቅጥ ሲሟላ Bingo ይጫኑ።\n5. የጨዋታ ውጤትና ሽልማት በአፕ ውስጥ ይታያሉ።",
            'withdraw' => "💸 ገንዘብ ለማውጣት Play ይጫኑ፣ ከዚያ Withdraw ይምረጡና የሚፈለገውን የክፍያ መረጃ ያስገቡ። ጥያቄዎ በአስተዳዳሪ እስኪገመገም ይጠብቁ።",
        ];

        foreach ($options as $optionId => $option) {
            if (!empty($option['enabled'])) $messages[$optionId] = (string) ($option['response'] ?? '');
        }

        // Transfer workflow: recipient + amount, then explicit confirmation.
        $telegramId = (string) $chatId;
        $transferSession = DB::table('telegram_transfer_sessions')->where('telegram_id', $telegramId)->first();
        if ($transferSession && strtotime((string) $transferSession->expires_at) < time()) {
            DB::table('telegram_transfer_sessions')->where('telegram_id', $telegramId)->delete();
            $transferSession = null;
        }
        if ($transferSession && in_array($lower, ['cancel', '/cancel'], true)) {
            DB::table('telegram_transfer_sessions')->where('telegram_id', $telegramId)->delete();
            return ['chat_id' => $chatId, 'text' => 'Transfer cancelled. No balance was moved.', 'reply_markup' => $menu];
        }
        if ($transferSession) {
            if (empty($botConfig['transferEnabled'])) {
                DB::table('telegram_transfer_sessions')->where('telegram_id', $telegramId)->delete();
                return ['chat_id' => $chatId, 'text' => 'Balance transfers are currently disabled.', 'reply_markup' => $menu];
            }
            if ($transferSession->state === 'recipient') {
                if (!preg_match('/^@?([a-zA-Z0-9_]{3,64})\s+([0-9]+(?:\.[0-9]{1,2})?)$/', trim($raw), $transferMatch)) {
                    return ['chat_id' => $chatId, 'text' => 'Send the recipient Telegram username and amount, for example: @abebe 50. Type CANCEL to stop.', 'reply_markup' => $menu];
                }
                $sender = DB::table('users')->where('telegram_id', $telegramId)->first();
                $recipient = DB::table('users')->whereRaw('LOWER(username) = ?', [strtolower($transferMatch[1])])->where('is_bot', false)->first();
                $amount = round((float) $transferMatch[2], 2);
                $minAmount = (float) ($botConfig['transferMinAmount'] ?? 1);
                $maxAmount = (float) ($botConfig['transferMaxAmount'] ?? 10000);
                if (!$sender) {
                    DB::table('telegram_transfer_sessions')->where('telegram_id', $telegramId)->delete();
                    return ['chat_id' => $chatId, 'text' => 'Register and open Play Game before transferring balance.', 'reply_markup' => $menu];
                }
                if (!$recipient || $recipient->id === $sender->id) {
                    return ['chat_id' => $chatId, 'text' => 'Recipient not found, or you cannot transfer to yourself. Check their registered username and try again.', 'reply_markup' => $menu];
                }
                if ($amount < $minAmount || $amount > $maxAmount) {
                    return ['chat_id' => $chatId, 'text' => 'Transfer amount must be between '.number_format($minAmount, 2).' and '.number_format($maxAmount, 2).' ETB. Try again or type CANCEL.', 'reply_markup' => $menu];
                }
                DB::table('telegram_transfer_sessions')->where('telegram_id', $telegramId)->update([
                    'state' => 'wallet', 'recipient_user_id' => $recipient->id, 'amount' => $amount,
                    'expires_at' => now()->addMinutes(15), 'updated_at' => now(),
                ]);
                $walletMenu = $menu;
                $walletMenu['keyboard'] = [[['text' => 'Main wallet'], ['text' => 'Playing wallet']], [['text' => 'Cancel']]];
                return ['chat_id' => $chatId, 'text' => 'Send '.number_format($amount, 2).' ETB to @'.$recipient->username.". Which of your wallets should it come from?\nMain wallet: ".number_format((float) $sender->main_balance, 2)." ETB\nPlaying wallet: ".number_format((float) $sender->play_balance, 2)." ETB\n\nThe receiver always gets it in their Playing wallet. Tap a wallet, or CANCEL to stop.", 'reply_markup' => $walletMenu];
            }
            if ($transferSession->state === 'wallet') {
                $choice = in_array($lower, ['main', 'main wallet', 'main balance'], true)
                    ? 'main'
                    : (in_array($lower, ['playing', 'play', 'playing wallet', 'play wallet', 'playing balance', 'play balance'], true) ? 'play' : null);
                $walletMenu = $menu;
                $walletMenu['keyboard'] = [[['text' => 'Main wallet'], ['text' => 'Playing wallet']], [['text' => 'Cancel']]];
                if ($choice === null) {
                    return ['chat_id' => $chatId, 'text' => 'Tap Main wallet or Playing wallet to choose where the money comes from, or type CANCEL to stop.', 'reply_markup' => $walletMenu];
                }
                $sender = DB::table('users')->where('telegram_id', $telegramId)->first();
                $recipient = DB::table('users')->where('id', $transferSession->recipient_user_id)->first();
                $amount = round((float) $transferSession->amount, 2);
                if (!$sender || !$recipient) {
                    DB::table('telegram_transfer_sessions')->where('telegram_id', $telegramId)->delete();
                    return ['chat_id' => $chatId, 'text' => 'Sender or recipient account is unavailable. Start the transfer again.', 'reply_markup' => $menu];
                }
                $available = (float) ($choice === 'play' ? $sender->play_balance : $sender->main_balance);
                if ($available + 0.000001 < $amount) {
                    return ['chat_id' => $chatId, 'text' => 'Your '.($choice === 'play' ? 'Playing' : 'Main').' wallet has '.number_format($available, 2).' ETB, which is not enough for '.number_format($amount, 2).' ETB. Choose the other wallet or type CANCEL.', 'reply_markup' => $walletMenu];
                }
                DB::table('telegram_transfer_sessions')->where('telegram_id', $telegramId)->update([
                    'state' => 'confirm_'.$choice, 'expires_at' => now()->addMinutes(15), 'updated_at' => now(),
                ]);
                $confirmMenu = $menu;
                $confirmMenu['keyboard'] = [[['text' => 'CONFIRM'], ['text' => 'Cancel']]];
                return ['chat_id' => $chatId, 'text' => 'Confirm transfer: '.number_format($amount, 2).' ETB from your '.($choice === 'play' ? 'Playing' : 'Main').' wallet to @'.$recipient->username.'? They receive it in their Playing wallet. Reply CONFIRM to proceed or CANCEL to stop.', 'reply_markup' => $confirmMenu];
            }
            if (in_array($transferSession->state, ['confirm', 'confirm_main', 'confirm_play'], true)) {
                if (!in_array($lower, ['confirm', 'yes'], true)) {
                    return ['chat_id' => $chatId, 'text' => 'No funds have moved yet. Reply CONFIRM to complete this transfer or CANCEL to stop.', 'reply_markup' => $menu];
                }
                $source = $transferSession->state === 'confirm_play' ? 'play' : 'main';
                try {
                    // All wallet rules live in WalletService: the receiver is credited to their Playing wallet and
                    // gets a bot message; the text returned here is the sender's confirmation.
                    $transferResult = DB::transaction(function () use ($telegramId, $source) {
                        $lockedSession = DB::table('telegram_transfer_sessions')->where('telegram_id', $telegramId)->lockForUpdate()->first();
                        if (!$lockedSession || !in_array($lockedSession->state, ['confirm', 'confirm_main', 'confirm_play'], true) || strtotime((string) $lockedSession->expires_at) < time()) {
                            throw new \RuntimeException('Transfer session expired. Start the transfer again.');
                        }
                        $sender = DB::table('users')->where('telegram_id', $telegramId)->first();
                        if (!$sender) throw new \RuntimeException('Sender account is unavailable.');
                        $done = app(\App\Services\WalletService::class)->transferToPlayer(
                            (string) $sender->id,
                            (string) $lockedSession->recipient_user_id,
                            (float) $lockedSession->amount,
                            $source
                        );
                        DB::table('telegram_transfer_sessions')->where('telegram_id', $telegramId)->delete();
                        return $done;
                    });
                    return ['chat_id' => $chatId, 'text' => $transferResult['message'], 'reply_markup' => $menu];
                } catch (\Throwable $e) {
                    DB::table('telegram_transfer_sessions')->where('telegram_id', $telegramId)->delete();
                    return ['chat_id' => $chatId, 'text' => 'Transfer failed: '.$e->getMessage(), 'reply_markup' => $menu];
                }
            }
        }

        $accountRequiredOptions = ['balance', 'transfer', 'withdraw', 'deposit', 'invite'];
        $isAccountAction = in_array($selectedOptionId, $accountRequiredOptions, true)
            || in_array($slashCommand, ['/balance', '/transfer', '/withdraw', '/deposit', '/invite'], true);
        $registeredPlayer = DB::table('users')->where('telegram_id', (string) $chatId)->first();
        if ($isAccountAction && !$registeredPlayer) {
            $text = "Please register first to use this option. Tap Share my phone number, share your own Telegram contact, then open Play Game and complete registration. After registration, select this option again.";
            $menu['keyboard'] = [[[
                'text' => 'Share my phone number',
                'request_contact' => true,
            ]]];
            return ['chat_id' => $chatId, 'text' => $text, 'reply_markup' => $menu];
        }

        // In-chat Deposit / Withdraw conversations (see App\Services\TelegramWalletFlows).
        if ($registeredPlayer) {
            $walletReply = $this->handleWalletFlow($raw, $lower, $registeredPlayer, (int) $chatId, $menu, $selectedOptionId, $slashCommand);
            if ($walletReply !== null) {
                return $walletReply;
            }
        }

        $languageKey = 'telegram_language_' . $chatId;
        $languagePendingKey = 'telegram_language_pending_' . $chatId;
        $languagePending = DB::table('system_state')->where('key', $languagePendingKey)->exists();

        if (in_array($lower, ['language | ቋንቋ', 'language', 'ቋንቋ'], true)) {
            DB::table('system_state')->updateOrInsert(
                ['key' => $languagePendingKey],
                ['value' => '1', 'created_at' => now(), 'updated_at' => now()]
            );
            $languageMenu = [
                'keyboard' => [[['text' => 'English'], ['text' => 'አማርኛ']], [['text' => 'Cancel']]],
                'resize_keyboard' => true,
                'one_time_keyboard' => true,
                'is_persistent' => true,
            ];
            return ['chat_id' => $chatId, 'text' => 'Choose your language / ቋንቋ ይምረጡ፦', 'reply_markup' => $languageMenu];
        }

        if ($languagePending && in_array($lower, ['english', 'en', 'አማርኛ', 'amharic', 'am', 'cancel'], true)) {
            DB::table('system_state')->where('key', $languagePendingKey)->delete();
            if ($lower === 'cancel') {
                return ['chat_id' => $chatId, 'text' => 'Language selection cancelled. / የቋንቋ ምርጫ ተሰርዟል።', 'reply_markup' => $menu];
            }
            $chosenLanguage = in_array($lower, ['english', 'en'], true) ? 'en' : 'am';
            DB::table('system_state')->updateOrInsert(
                ['key' => $languageKey],
                ['value' => $chosenLanguage, 'created_at' => now(), 'updated_at' => now()]
            );
            $confirmation = $chosenLanguage === 'en'
                ? 'Language saved as English. Your Mini App will use English the next time you open it.'
                : 'ቋንቋው ወደ አማርኛ ተቀይሯል። Mini App ን በሚቀጥለው ጊዜ ሲከፍቱ አማርኛን ይጠቀማል።';
            return ['chat_id' => $chatId, 'text' => $confirmation, 'reply_markup' => $menu];
        }

        if ($slashCommand === '/start' && ($parts[1] ?? '') === 'share_phone') {
            // Telegram deep links pass their payload as the second /start argument.
            // Offer the native contact-sharing button immediately for this flow.
            $text = 'To finish registration, tap the button below to share your own Telegram phone number.';
            $menu['keyboard'] = [[[
                'text' => 'Share my phone number',
                'request_contact' => true,
            ]]];
        } elseif ($slashCommand === '/start' || $slashCommand === '/menu' || $lower === 'menu') {
            $text = (string) ($botConfig['welcomeMessage'] ?? $this->defaultBotConfig()['welcomeMessage']);
        } elseif ($slashCommand === '/play' || $lower === 'play') {
            $text = "🎮 ጨዋታውን ለመክፈት ከታች ያለውን Play ቁልፍ ይጫኑ።";
        } elseif ($slashCommand === '/balance' || $selectedOptionId === 'balance') {
            $user = DB::table('users')->where('telegram_id', (string) $chatId)->first();
            if ($user) {
                $text = (string) ($messages['balance'] ?? '');
                $text = str_replace(['{main_balance}', '{play_balance}', '{username}', '{support_contact}', '{app_url}'], [number_format((float) $user->main_balance, 2), number_format((float) $user->play_balance, 2), (string) $user->username, $this->supportContact(), $appUrl], $text);
            } else {
                $text = "💰 የሂሳብ መረጃ አልተገኘም። እባክዎ Register ይምረጡና Play በመጫን ምዝገባዎን ያጠናቅቁ።";
            }
        } elseif ($selectedOptionId === 'invite') {
            $user = DB::table('users')->where('telegram_id', (string) $chatId)->first();
            if (!$user) {
                $text = 'Register through Play Game first. Once your account is ready, choose Invite to get your personal referral link.';
            } else {
                $referralCode = (string) ($user->referral_code ?? '');
                if ($referralCode === '') {
                    do {
                        $referralCode = 'REF' . strtoupper(\Illuminate\Support\Str::random(9));
                    } while (DB::table('users')->where('referral_code', $referralCode)->exists());
                    DB::table('users')->where('id', $user->id)->update(['referral_code' => $referralCode, 'updated_at' => now()]);
                }
                $referralLink = 'https://t.me/ethiobingobet_bot?start=ref_' . $referralCode;
                $bonusEnabled = (bool) ($botConfig['referralBonusEnabled'] ?? true);
                $bonusAmount = (float) ($botConfig['referralBonusAmount'] ?? 10);
                $text = (string) ($messages['invite'] ?? 'Invite friends using your personal referral link: {referral_link}');
                $text = str_replace(['{referral_link}', '{referral_code}', '{referral_bonus}', '{username}', '{app_url}'], [$referralLink, $referralCode, number_format($bonusAmount, 2), $user->username, $appUrl], $text);
                if (!str_contains((string) ($messages['invite'] ?? ''), '{referral_link}')) $text .= "\n\nYour personal referral link: " . $referralLink;
                if (!$bonusEnabled) {
                    $text .= "\nReferral bonuses are currently disabled.";
                } elseif (!str_contains((string) ($messages['invite'] ?? ''), '{referral_bonus}')) {
                    $text .= "\nBoth players receive " . number_format($bonusAmount, 2) . " ETB Play Bonus after the invited player joins their first game.";
                }
            }
        } elseif ($selectedOptionId === 'transfer') {
            $user = DB::table('users')->where('telegram_id', (string) $chatId)->first();
            if (empty($botConfig['transferEnabled'])) {
                $text = 'Balance transfers are currently disabled.';
            } elseif (!$user) {
                $text = 'Register and open Play Game before transferring balance.';
            } else {
                DB::table('telegram_transfer_sessions')->updateOrInsert(
                    ['telegram_id' => (string) $chatId],
                    ['state' => 'recipient', 'recipient_user_id' => null, 'amount' => null, 'expires_at' => now()->addMinutes(15), 'created_at' => now(), 'updated_at' => now()]
                );
                $text = (string) ($messages['transfer'] ?? 'Transfer Main Balance to another registered player.');
                $text .= "\n\nSend the recipient username and amount, for example: @abebe 50. Minimum: " . number_format((float) ($botConfig['transferMinAmount'] ?? 1), 2) . " ETB; maximum: " . number_format((float) ($botConfig['transferMaxAmount'] ?? 10000), 2) . " ETB. You choose whether it comes from your Main or Playing wallet; the receiver always gets it in their Playing wallet. Type CANCEL to stop.";
            }
        } elseif ($selectedOptionId !== null && isset($messages[$selectedOptionId])) {
            $text = (string) $messages[$selectedOptionId];
            $user = DB::table('users')->where('telegram_id', (string) $chatId)->first();
            $text = str_replace(['{main_balance}', '{play_balance}', '{username}', '{support_contact}', '{app_url}'], [
                $user ? number_format((float) $user->main_balance, 2) : 'N/A',
                $user ? number_format((float) $user->play_balance, 2) : 'N/A',
                $user->username ?? '',
                $this->supportContact(),
                $appUrl,
            ], $text);

            // Show phone sharing only after the player explicitly chooses Register.
            if ($selectedOptionId === 'register') {
                $menu['keyboard'][] = [[
                    'text' => 'ስልክ ቁጥር አጋራ',
                    'request_contact' => true,
                ]];
            }
        } elseif ($slashCommand === '/help') {
            $text = (string) ($botConfig['helpMessage'] ?? $this->defaultBotConfig()['helpMessage']);
        } else {
            $text = (string) ($botConfig['fallbackMessage'] ?? $this->defaultBotConfig()['fallbackMessage']);
        }

        return [
            'chat_id' => $chatId,
            'text' => $text,
            'reply_markup' => $menu,
        ];
    }}
