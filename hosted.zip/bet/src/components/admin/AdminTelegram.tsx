import React, { useCallback, useEffect, useState } from 'react';
import { Send, RefreshCw, ExternalLink, Webhook, ShieldCheck, AlertCircle } from 'lucide-react';

type BotOption = { id: string; label: string; enabled: boolean; response: string };
type BotConfig = {
  welcomeMessage: string; helpMessage: string; fallbackMessage: string; options: BotOption[];
  referralBonusEnabled: boolean; referralBonusAmount: number;
  transferEnabled: boolean; transferMinAmount: number; transferMaxAmount: number;
  supportUsername: string; communityUsername: string;
};
type TelegramStatus = {
  ok: boolean;
  hasTokenConfigured?: boolean;
  maskedToken?: string | null;
  bot?: { username?: string; first_name?: string } | null;
  webhook?: { url?: string; pending_update_count?: number; last_error_message?: string } | null;
  telegramConnected?: boolean;
  webhookError?: string | null;
  message?: string;
};
export const AdminTelegram: React.FC = () => {
  const [status, setStatus] = useState<TelegramStatus | null>(null);
  const [loading, setLoading] = useState(false);
  const [registering, setRegistering] = useState(false);
  const [result, setResult] = useState('');
  const [error, setError] = useState('');
  const [botConfig, setBotConfig] = useState<BotConfig | null>(null);
  const [configLoading, setConfigLoading] = useState(true);
  const [configSaving, setConfigSaving] = useState(false);
  const [configError, setConfigError] = useState('');
  const [configSaved, setConfigSaved] = useState(false);
  const appUrl = typeof window !== 'undefined' ? window.location.origin : '';

  const refresh = useCallback(async () => {
    setLoading(true); setError('');
    try {
      const response = await fetch('/api/telegram/status', { credentials: 'include' });
      const data = await response.json();
      if (!response.ok || data?.ok !== true) throw new Error(data?.error || 'Telegram status could not be loaded.');
      setStatus(data);
    } catch (e) {
      setStatus(null);
      setError(e instanceof Error ? e.message : 'Telegram status could not be loaded.');
    } finally { setLoading(false); }
  }, []);
  useEffect(() => { void refresh(); }, [refresh]);

  useEffect(() => {
    let active = true;
    fetch('/api/telegram/bot-config', { credentials: 'include' })
      .then(async (response) => {
        const data = await response.json();
        if (!response.ok || data?.ok !== true) throw new Error(data?.error || 'Bot configuration could not be loaded.');
        if (active) setBotConfig(data.config as BotConfig);
      })
      .catch((e) => { if (active) setConfigError(e instanceof Error ? e.message : 'Bot configuration could not be loaded.'); })
      .finally(() => { if (active) setConfigLoading(false); });
    return () => { active = false; };
  }, []);

  const updateOption = (id: string, patch: Partial<BotOption>) => {
    setBotConfig((current) => current ? ({ ...current, options: current.options.map((option) => option.id === id ? { ...option, ...patch } : option) }) : current);
    setConfigSaved(false);
  };

  const saveBotConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!botConfig || configSaving) return;
    setConfigSaving(true); setConfigError(''); setConfigSaved(false);
    try {
      const response = await fetch('/api/telegram/bot-config', {
        method: 'PUT', credentials: 'include', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(botConfig),
      });
      const data = await response.json();
      if (!response.ok || data?.ok !== true) throw new Error(data?.error || 'Bot configuration could not be saved.');
      setBotConfig(data.config as BotConfig); setConfigSaved(true);
    } catch (e) {
      setConfigError(e instanceof Error ? e.message : 'Bot configuration could not be saved.');
    } finally { setConfigSaving(false); }
  };

  const registerWebhook = async () => {
    setRegistering(true); setResult(''); setError('');
    try {
      const response = await fetch('/api/telegram/register-webhook', {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ appUrl })
      });
      const data = await response.json();
      if (!response.ok || data?.ok !== true) throw new Error(data?.error || 'Webhook registration failed.');
      setResult('Telegram webhook and Play Game menu registration reported success.');
      await refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Webhook registration failed.');
    } finally { setRegistering(false); }
  };

  return <div className="max-w-4xl space-y-6">
    <div className="flex items-center justify-between gap-3">
      <div><h2 className="text-lg font-black text-white">Telegram Bot & Mini App</h2><p className="text-xs text-purple-300">Live status from Telegram. No fabricated sample users or simulated webhook updates.</p></div>
      <button onClick={() => void refresh()} className="rounded-xl border border-purple-700 px-3 py-2 text-xs font-bold text-purple-200 flex items-center gap-1.5"><RefreshCw className="h-4 w-4" /> Refresh</button>
    </div>
    {error && <p role="alert" className="rounded-xl border border-red-500/40 bg-red-500/10 p-3 text-sm text-red-200">{error}</p>}
    {result && <p role="status" className="rounded-xl border border-emerald-500/40 bg-emerald-500/10 p-3 text-sm text-emerald-200">{result}</p>}
    {loading && !status && <p className="text-sm text-purple-300">Checking Telegram status…</p>}

    {status && <>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div className="rounded-2xl border border-purple-900 bg-[#120626] p-4 space-y-2">
          <div className="flex items-center gap-2"><ShieldCheck className="h-5 w-5 text-amber-400" /><h3 className="font-bold text-white">Bot connection</h3></div>
          <p className={status.telegramConnected ? 'text-sm text-emerald-300' : 'text-sm text-amber-200'}>{status.telegramConnected ? 'Connected to Telegram' : status.hasTokenConfigured ? 'Configured, but connection not verified' : 'Bot token not configured'}</p>
          <p className="text-xs text-purple-300">Bot: {status.bot?.username ? '@' + status.bot.username : 'Not available'}</p>
          <p className="text-xs text-purple-300">Token: {status.maskedToken || 'Not configured'}</p>
          {status.message && <p className="text-xs text-purple-400">{status.message}</p>}
        </div>
        <div className="rounded-2xl border border-purple-900 bg-[#120626] p-4 space-y-2">
          <div className="flex items-center gap-2"><Webhook className="h-5 w-5 text-amber-400" /><h3 className="font-bold text-white">Webhook</h3></div>
          <p className="break-all text-xs text-purple-300">{status.webhook?.url || 'No webhook URL returned'}</p>
          <p className="text-xs text-purple-300">Pending updates: {typeof status.webhook?.pending_update_count === 'number' ? status.webhook.pending_update_count : 'Not reported'}</p>
          {(status.webhookError || status.webhook?.last_error_message) && <p className="text-xs text-amber-200">{status.webhookError || status.webhook?.last_error_message}</p>}
        </div>
      </div>

      <div className="rounded-2xl border border-purple-900 bg-[#120626] p-5 space-y-3">
        <h3 className="font-extrabold text-white">Mini App launch</h3>
        <p className="break-all text-xs text-purple-300">Current app origin: {appUrl}</p>
        <p className="text-sm leading-6 text-purple-200">The persistent Telegram menu should read <strong className="text-white">Play Game</strong>. Open the Mini App from that menu or the inline Play button so Telegram supplies signed initData.</p>
        <button disabled={registering || !status.hasTokenConfigured} onClick={() => void registerWebhook()} className="rounded-xl bg-amber-500 px-4 py-3 text-xs font-black text-black disabled:opacity-50">{registering ? 'Registering…' : 'Register webhook & Play Game menu'}</button>
        <a href="https://t.me/ethiobingobet_bot" target="_blank" rel="noreferrer" className="ml-3 inline-flex items-center gap-1 text-xs font-bold text-amber-300">Open bot <ExternalLink className="h-3.5 w-3.5" /></a>
      </div>
      <div className="flex items-start gap-2 rounded-xl border border-amber-500/30 bg-amber-500/10 p-3 text-xs text-amber-100"><AlertCircle className="h-4 w-4 shrink-0" /><span>Sample HMAC payloads and fabricated Telegram command updates were removed so test identities cannot be mistaken for real players.</span></div>
    </>}

    <form onSubmit={saveBotConfig} className="rounded-2xl border border-purple-900 bg-[#120626] p-5 space-y-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div><h3 className="text-base font-extrabold text-white">Bot Menu & Response Configuration</h3><p className="mt-1 text-xs text-purple-300">Edit the Telegram reply-keyboard labels, turn menu actions on/off, and control each response. Changes apply to the next incoming message.</p></div>
        <span className="rounded-lg bg-purple-900/70 px-2.5 py-1 text-[10px] font-bold text-purple-200">Server-saved</span>
      </div>
      {configError && <p role="alert" className="rounded-xl border border-red-500/40 bg-red-500/10 p-3 text-sm text-red-200">{configError}</p>}
      {configSaved && <p role="status" className="rounded-xl border border-emerald-500/40 bg-emerald-500/10 p-3 text-sm text-emerald-200">Bot menu and responses saved successfully.</p>}
      {configLoading && <p className="text-sm text-purple-300">Loading bot configuration…</p>}
      {!configLoading && botConfig && <>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <label className="block text-xs font-bold text-purple-200">Welcome response (/start and /menu)
            <textarea required maxLength={1500} rows={4} value={botConfig.welcomeMessage} onChange={(e) => { setBotConfig({ ...botConfig, welcomeMessage: e.target.value }); setConfigSaved(false); }} className="mt-1 w-full rounded-xl border border-purple-800 bg-[#0d051a] p-3 text-sm font-normal text-white" />
          </label>
          <label className="block text-xs font-bold text-purple-200">Help response (/help)
            <textarea required maxLength={1000} rows={4} value={botConfig.helpMessage} onChange={(e) => { setBotConfig({ ...botConfig, helpMessage: e.target.value }); setConfigSaved(false); }} className="mt-1 w-full rounded-xl border border-purple-800 bg-[#0d051a] p-3 text-sm font-normal text-white" />
          </label>
          <label className="block text-xs font-bold text-purple-200">Unknown-command response
            <textarea required maxLength={1000} rows={4} value={botConfig.fallbackMessage} onChange={(e) => { setBotConfig({ ...botConfig, fallbackMessage: e.target.value }); setConfigSaved(false); }} className="mt-1 w-full rounded-xl border border-purple-800 bg-[#0d051a] p-3 text-sm font-normal text-white" />
          </label>
        </div>
        <div className="rounded-xl border border-purple-900 bg-[#180a32] p-4 space-y-4">
          <h4 className="font-bold text-white">Support account</h4>
          <p className="text-xs text-purple-300">Set the Telegram username players should reach when they press Contact Support in the Mini App profile or use the support menu. Enter the username with or without @.</p>
          <label className="block text-xs font-bold text-purple-300">Support Telegram username
            <input type="text" maxLength={32} pattern="@?[A-Za-z0-9_]{5,32}" value={botConfig.supportUsername || ''} onChange={(e) => { setBotConfig({ ...botConfig, supportUsername: e.target.value.replace(/^@/, '') }); setConfigSaved(false); }} placeholder="e.g. EthioBingoSupport" className="mt-1 w-full rounded-lg border border-purple-800 bg-[#0d051a] px-3 py-2 text-sm text-white" />
          </label>
          <p className="text-[11px] text-purple-400">{botConfig.supportUsername ? `Players will open https://t.me/${botConfig.supportUsername.replace(/^@/, '')}` : 'No support username set. The existing server fallback will be used.'}</p>
        </div>
        <div className="rounded-xl border border-purple-900 bg-[#180a32] p-4 space-y-3">
          <h4 className="font-bold text-white">Community account</h4>
          <p className="text-xs text-purple-300">Set the Telegram username of the official group or channel players should open when they press Join Community. Enter the username with or without @.</p>
          <label className="block text-xs font-bold text-purple-300">Community group/channel Telegram username
            <input type="text" maxLength={32} pattern="@?[A-Za-z0-9_]{5,32}" value={botConfig.communityUsername || ''} onChange={(e) => { setBotConfig({ ...botConfig, communityUsername: e.target.value.replace(/^@/, '') }); setConfigSaved(false); }} placeholder="e.g. EthioGameHouseCommunity" className="mt-1 w-full rounded-lg border border-purple-800 bg-[#0d051a] px-3 py-2 text-sm text-white" />
          </label>
          <p className="text-[11px] text-purple-400">{botConfig.communityUsername ? `Players will open https://t.me/${botConfig.communityUsername.replace(/^@/, '')} from the Join Community bot menu button.` : 'No community username set. Add a public group/channel username to enable the Join Community link.'}</p>
        </div>
        <div className="rounded-xl border border-purple-900 bg-[#180a32] p-4 space-y-4">
          <h4 className="font-bold text-white">Referral rewards & balance transfers</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <label className="flex items-center gap-2 text-sm font-bold text-purple-200">
                <input type="checkbox" checked={botConfig.referralBonusEnabled} onChange={(e) => { setBotConfig({ ...botConfig, referralBonusEnabled: e.target.checked }); setConfigSaved(false); }} className="h-4 w-4 accent-amber-500" />
                Enable referral rewards
              </label>
              <label className="block text-xs font-bold text-purple-300">Bonus for each player (ETB Play Balance)
                <input type="number" min="0" max="10000" step="0.5" required value={botConfig.referralBonusAmount} onChange={(e) => { setBotConfig({ ...botConfig, referralBonusAmount: Number(e.target.value) }); setConfigSaved(false); }} className="mt-1 w-full rounded-lg border border-purple-800 bg-[#0d051a] px-3 py-2 text-sm text-white" />
              </label>
              <p className="text-[11px] text-purple-400">Each side is rewarded once after the invited player confirms their first game cartela.</p>
            </div>
            <div className="space-y-3">
              <label className="flex items-center gap-2 text-sm font-bold text-purple-200">
                <input type="checkbox" checked={botConfig.transferEnabled} onChange={(e) => { setBotConfig({ ...botConfig, transferEnabled: e.target.checked }); setConfigSaved(false); }} className="h-4 w-4 accent-amber-500" />
                Enable player-to-player transfers
              </label>
              <div className="grid grid-cols-2 gap-3">
                <label className="block text-xs font-bold text-purple-300">Minimum (ETB)
                  <input type="number" min="1" max="100000" step="1" required value={botConfig.transferMinAmount} onChange={(e) => { setBotConfig({ ...botConfig, transferMinAmount: Number(e.target.value) }); setConfigSaved(false); }} className="mt-1 w-full rounded-lg border border-purple-800 bg-[#0d051a] px-3 py-2 text-sm text-white" />
                </label>
                <label className="block text-xs font-bold text-purple-300">Maximum (ETB)
                  <input type="number" min="1" max="100000" step="1" required value={botConfig.transferMaxAmount} onChange={(e) => { setBotConfig({ ...botConfig, transferMaxAmount: Number(e.target.value) }); setConfigSaved(false); }} className="mt-1 w-full rounded-lg border border-purple-800 bg-[#0d051a] px-3 py-2 text-sm text-white" />
                </label>
              </div>
              <p className="text-[11px] text-purple-400">Transfers move Main Balance only; Play Bonus balances cannot be transferred.</p>
            </div>
          </div>
        </div>
        <div className="space-y-3">
          <div><h4 className="font-bold text-white">Menu buttons & individual responses</h4><p className="mt-1 text-[11px] text-purple-400">Use placeholders in replies: <code>{'{main_balance}'}</code>, <code>{'{play_balance}'}</code>, <code>{'{username}'}</code>, <code>{'{support_contact}'}</code>, <code>{'{app_url}'}</code>, <code>{'{referral_link}'}</code>, <code>{'{referral_code}'}</code>, <code>{'{referral_bonus}'}</code>.</p></div>
          {botConfig.options.map((option) => (
            <div key={option.id} className="rounded-xl border border-purple-900 bg-[#180a32] p-4 space-y-3">
              <div className="flex flex-wrap items-center gap-3">
                <input type="checkbox" checked={option.enabled} onChange={(e) => updateOption(option.id, { enabled: e.target.checked })} className="h-4 w-4 accent-amber-500" aria-label={'Enable ' + option.label} />
                <span className="w-28 shrink-0 text-xs font-bold text-purple-300">{option.id}</span>
                <input required minLength={2} maxLength={32} value={option.label} onChange={(e) => updateOption(option.id, { label: e.target.value })} className="min-w-0 flex-1 rounded-lg border border-purple-800 bg-[#0d051a] px-3 py-2 text-sm text-white" aria-label={option.id + ' button label'} />
                <span className={'text-[10px] font-bold ' + (option.enabled ? 'text-emerald-300' : 'text-purple-500')}>{option.enabled ? 'VISIBLE' : 'HIDDEN'}</span>
              </div>
              <label className="block text-xs font-bold text-purple-300">Response text
                <textarea required maxLength={1500} rows={3} value={option.response} onChange={(e) => updateOption(option.id, { response: e.target.value })} className="mt-1 w-full rounded-lg border border-purple-800 bg-[#0d051a] p-3 text-sm font-normal text-white" />
              </label>
            </div>
          ))}
        </div>
        <div className="rounded-xl border border-amber-500/30 bg-amber-500/10 p-3 text-xs leading-5 text-amber-100">Balance placeholders are filled from the sender's registered account. If you disable an option, its button disappears from the reply keyboard; core commands such as /start and /help remain available.</div>
        <button type="submit" disabled={configSaving} className="rounded-xl bg-amber-500 px-5 py-3 text-xs font-black text-black disabled:opacity-50">{configSaving ? 'Saving configuration…' : 'Save Bot Menu & Responses'}</button>
      </>}
    </form>
  </div>;
};
