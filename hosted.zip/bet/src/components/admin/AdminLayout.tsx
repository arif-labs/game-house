import React, { useEffect, useState } from 'react';
import {
  LayoutDashboard,
  Radio,
  Sliders,
  Home,
  Grid,
  Users,
  CreditCard,
  Gift,
  ShieldAlert,
  BarChart3,
  MessageSquare,
  Cpu,
  HeartHandshake,
  CheckCircle2,
  AlertOctagon,
  LogOut,
  ChevronRight,
  TestTube,
  Send,
  Bot,
  Menu
} from 'lucide-react';
import { gameStore } from '../../services/gameStore';
import { AdminUser } from '../../types/bingo';

export type AdminTab =
  | 'overview'
  | 'platform'
  | 'telegram'
  | 'live_rounds'
  | 'settings'
  | 'rooms'
  | 'automated_players'
  | 'cartelas'
  | 'users'
  | 'finance'
  | 'bonuses'
  | 'fraud'
  | 'reports'
  | 'content'
  | 'system'
  | 'tests';

interface AdminLayoutProps {
  currentTab: AdminTab;
  onSelectTab: (tab: AdminTab) => void;
  onExitToPlayer: () => void;
  children: React.ReactNode;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({
  currentTab,
  onSelectTab,
  onExitToPlayer,
  children
}) => {
  const [admin, setAdmin] = useState<AdminUser>(gameStore.currentAdmin);
  const [lang, setLang] = useState<'am' | 'en'>(gameStore.language);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const isKillSwitch = gameStore.isKillSwitchActive;

  const toggleLanguage = () => {
    const next = lang === 'am' ? 'en' : 'am';
    gameStore.setLanguage(next);
    setLang(next);
  };

  useEffect(() => {
    fetch('/api/admin/me', { credentials: 'include' }).then(async (response) => {
      if (response.ok) {
        const data = await response.json();
        setAdmin((current) => ({ ...current, name: data.admin.name, email: data.admin.email, role: data.admin.role }));
      }
    }).catch(() => undefined);
  }, []);

  const handleLogout = async () => {
    await fetch('/api/admin/logout', { method: 'POST', credentials: 'include' });
    window.location.href = '/admin';
  };



  const navItems: { id: AdminTab; label: string; icon: any; badge?: string }[] = [
    { id: 'overview', label: lang === 'am' ? 'አጠቃላይ እይታ' : 'Overview & KPIs', icon: LayoutDashboard },
    { id: 'platform', label: lang === 'am' ? 'የመድረክ ቁጥጥር' : 'Platform Control', icon: ShieldAlert },
    { id: 'telegram', label: lang === 'am' ? 'ቴሌግራም ቦት እና ሚኒ አፕ' : 'Telegram Bot & Mini App', icon: Send, badge: 'TG SDK' },
    { id: 'live_rounds', label: lang === 'am' ? 'የቀጥታ ዙሮች' : 'Live Rounds Monitor', icon: Radio, badge: lang === 'am' ? 'ቀጥታ' : 'Live' },
    { id: 'settings', label: lang === 'am' ? 'የጨዋታ ቅንብሮች' : 'Game Settings', icon: Sliders },
    { id: 'rooms', label: lang === 'am' ? 'የክፍሎች አስተዳደር' : 'Room Management', icon: Home },
    { id: 'automated_players', label: lang === 'am' ? 'ራስ-ሰር ተጫዋቾች' : 'Automated Players', icon: Bot },
    { id: 'cartelas', label: lang === 'am' ? 'የካርቴላ ስብስቦች (1-200)' : 'Cartela Sets (1-200)', icon: Grid },
    { id: 'users', label: lang === 'am' ? 'ተጠቃሚዎች እና ቦርሳዎች' : 'Users & Wallets', icon: Users },
    { id: 'finance', label: lang === 'am' ? 'ፋይናንስ እና ጥያቄዎች' : 'Finance & Queues', icon: CreditCard, badge: `${gameStore.deposits.filter(d => d.status === 'pending').length}` },
    { id: 'bonuses', label: lang === 'am' ? 'ቦነሶች እና ማስተዋወቂያዎች' : 'Bonuses & Promos', icon: Gift },
    { id: 'fraud', label: lang === 'am' ? 'ማጭበርበር እና አደጋ ቁጥጥር' : 'Fraud & Risk Engine', icon: ShieldAlert, badge: `${gameStore.fraudAlerts.length}` },
    { id: 'reports', label: lang === 'am' ? 'ሪፖርቶች እና ክፍያዎች' : 'Reports & Payouts', icon: BarChart3 },
    { id: 'content', label: lang === 'am' ? 'መልዕክቶች እና ድምጾች' : 'Comms & Audio Packs', icon: MessageSquare },
    { id: 'system', label: lang === 'am' ? 'ስርዓት እና የክትትል መዝገቦች' : 'System & Audit Logs', icon: Cpu },
    { id: 'tests', label: lang === 'am' ? 'የስርዓት ሙከራዎች' : 'Engine Test Suite', icon: TestTube, badge: lang === 'am' ? '6 ሙከራዎች' : '6 Tests' }
  ];

  return (
    <div className="flex h-[100dvh] min-h-0 bg-[#0b0416] text-[#f8fafc] overflow-hidden">
      {mobileNavOpen && <button type="button" aria-label="Close navigation" onClick={() => setMobileNavOpen(false)} className="fixed inset-0 z-40 bg-black/70 backdrop-blur-sm lg:hidden" />}
      {/* Sidebar: persistent on desktop, slide-in drawer on phones */}
      <aside className={`fixed inset-y-0 left-0 z-50 flex w-[min(18rem,86vw)] shrink-0 flex-col border-r border-[#261248] bg-[#110624] transition-transform duration-200 ease-out lg:static lg:z-auto lg:w-64 lg:translate-x-0 ${mobileNavOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full'}`}>
        {/* Brand */}
        <div className="p-4 border-b border-[#261248] flex items-center justify-between">
          <div>
            <div className="flex items-center space-x-1.5 font-black text-base text-white tracking-tight">
              <span>ኢትዮ ቢንጎ</span>
              <span className="text-amber-400">ADMIN</span>
            </div>
            <span className="text-[10px] text-purple-400 font-bold tracking-wider uppercase">
              {lang === 'am' ? 'የኦፕሬሽን ማዕከል' : 'Operations Center'}
            </span>
          </div>

          <button
            onClick={onExitToPlayer}
            className="px-2 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 rounded-lg text-[10px] font-bold"
            title={lang === 'am' ? 'የተጫዋች አፕን ክፈት' : 'Open Player App'}
          >
            {lang === 'am' ? 'የተጫዋች አፕ ↗' : 'Player App ↗'}
          </button>
        </div>

        {/* Current Admin & RBAC Switcher */}
        <div className="p-3 bg-[#170a30] border-b border-[#261248] space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <span className="font-extrabold text-white truncate max-w-[120px]">
              {admin.name}
            </span>
            <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-500 text-black font-black uppercase">
              {lang === 'am' ? ({ super_admin: 'ዋና አስተዳዳሪ', finance: 'ፋይናንስ', game_operator: 'የጨዋታ ኦፕሬተር', support: 'ድጋፍ', auditor: 'ኦዲተር' } as Record<string, string>)[admin.role] : admin.role.replace('_', ' ')}
            </span>
          </div>

          <div className="text-[10px] text-purple-400">{lang === 'am' ? 'ሚናው በደህንነቱ በተጠበቀ የአስተዳዳሪ መግቢያ ይመደባል።' : 'Role is assigned by the secure admin session.'}</div>
       </div>

        {/* Navigation list */}
        <nav className="flex-1 overflow-y-auto p-2 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => { onSelectTab(item.id); setMobileNavOpen(false); }}
                className={`min-h-11 w-full flex items-center justify-between gap-2 px-3 py-2.5 rounded-xl text-left text-xs font-bold transition-colors ${
                  isActive
                    ? 'bg-gradient-to-r from-amber-500/20 to-purple-800/40 text-amber-300 border border-amber-500/30'
                    : 'text-purple-300 hover:bg-[#1d0b38] hover:text-white'
                }`}
              >
                <div className="flex min-w-0 items-center gap-2.5">
                  <Icon className={`h-4 w-4 shrink-0 ${isActive ? 'text-amber-400' : 'text-purple-400'}`} />
                  <span className="min-w-0 whitespace-normal leading-4">{item.label}</span>
                </div>
                {item.badge && (
                  <span
                    className={`text-[9px] font-black px-1.5 py-0.2 rounded-full ${
                      item.badge === 'Live'
                        ? 'bg-rose-500 text-white animate-pulse'
                        : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Bottom Kill-switch status */}
        <div className="p-3 border-t border-[#261248] bg-[#0e041e]">
          <div className="flex items-center justify-between text-xs">
            <span className="text-[11px] font-bold text-purple-300 flex items-center">
              <span className={`w-2 h-2 rounded-full mr-1.5 ${isKillSwitch ? 'bg-red-500 animate-ping' : 'bg-emerald-400'}`} />
              {isKillSwitch ? 'KILL SWITCH ACTIVE' : 'SYSTEM HEALTHY'}
            </span>
            <span className="text-[10px] text-purple-400 font-mono">v2.4-prod</span>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
        {/* Top bar */}
        <header className="min-h-14 bg-[#110624] border-b border-[#261248] px-3 sm:px-6 py-2 flex items-center justify-between gap-2 shrink-0">
          <div className="flex min-w-0 items-center gap-2 sm:gap-3">
            <button type="button" onClick={() => setMobileNavOpen(true)} aria-label="Open navigation" aria-expanded={mobileNavOpen} className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-purple-800 bg-[#1b0b33] text-amber-300 lg:hidden"><Menu className="h-5 w-5" /></button>
            <h2 className="min-w-0 truncate text-sm sm:text-base font-extrabold text-white capitalize">
              {navItems.find((item) => item.id === currentTab)?.label ?? currentTab}
            </h2>
            <span className="hidden xl:inline text-xs text-purple-400">
              {lang === 'am' ? '• የቀጥታ ግንኙነት ተገናኝቷል' : '• Real-Time WebSocket Connected'}
            </span>
          </div>

          <div className="flex shrink-0 items-center gap-1.5 sm:gap-3">
            <button onClick={toggleLanguage} className="px-2.5 py-1.5 rounded-xl text-xs font-bold text-amber-300 border border-amber-500/40 hover:bg-amber-500/10">{lang === 'am' ? 'EN' : 'አማ'}</button>
            <button onClick={handleLogout} className="px-2 sm:px-3 py-2 rounded-xl text-xs font-bold text-purple-200 border border-purple-700 hover:bg-purple-900/50 flex items-center gap-1.5"><LogOut className="w-3.5 h-3.5"/><span className="hidden sm:inline">{lang === 'am' ? 'ውጣ' : 'Sign out'}</span></button>
            {/* Quick Kill Switch toggle */}
            <button
              title={lang === 'am' ? 'ድንገተኛ መቆጣጠሪያ' : 'Emergency kill switch'}
              aria-label={lang === 'am' ? 'ድንገተኛ መቆጣጠሪያ' : 'Emergency kill switch'}
              onClick={() => {
                if (confirm(lang === 'am' ? 'የስርዓት ጥገና / ድንገተኛ መቆጣጠሪያ ይቀይሩ?' : 'Toggle system maintenance / emergency kill switch?')) {
                  gameStore.adminToggleKillSwitch('Operator emergency toggle');
                }
              }}
              className={`px-2 sm:px-3 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 transition-colors border ${
                isKillSwitch
                  ? 'bg-red-600 text-white border-red-400 animate-pulse'
                  : 'bg-[#220d3e] text-purple-200 border-purple-700 hover:bg-red-950/60 hover:text-red-300'
              }`}
            >
              <AlertOctagon className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{isKillSwitch ? (lang === 'am' ? 'ጥገና በርቷል' : 'MAINTENANCE ON') : (lang === 'am' ? 'ድንገተኛ መቆጣጠሪያ' : 'KILL SWITCH')}</span>
            </button>
          </div>
        </header>

        {/* Content View Body */}
        <main className="min-h-0 min-w-0 flex-1 overflow-auto p-3 sm:p-6 bg-[#0a0316]">
          {children}
        </main>
      </div>
    </div>
  );
};
