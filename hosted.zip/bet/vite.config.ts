import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => ({
  base: '/build/',
  plugins:[react(),tailwindcss()],
  resolve:{alias:{'@':path.resolve(__dirname,'.')}},
  server:{
    port:5173,
    strictPort:true,
    hmr:process.env.DISABLE_HMR!=='true',
    watch:process.env.DISABLE_HMR==='true'?null:{},
    proxy:{
      '/api':{
        target:'http://127.0.0.1:8000',
        changeOrigin:false
      }
    }
  },
  build:{
    outDir:'public/build',
    emptyOutDir:true
  }
}));