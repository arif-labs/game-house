<?php
if($argc<2){fwrite(STDERR,"Usage: php scripts/hash-admin-password.php "your-password"\n");exit(1);}
echo password_hash($argv[1],PASSWORD_BCRYPT,['cost'=>12]).PHP_EOL;