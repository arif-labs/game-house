import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { defineConfig } from 'vite';

const root = fileURLToPath(new URL('.', import.meta.url));

export default defineConfig({
  root,
  publicDir: false,
  base: '/multibot/',
  plugins: [react(), tailwindcss()],
  resolve: { alias: { '@': root } },
  build: {
    outDir: path.resolve(root, 'public/multibot'),
    emptyOutDir: true,
    rollupOptions: {
      input: path.resolve(root, 'admin-bots.html'),
    },
  },
});
