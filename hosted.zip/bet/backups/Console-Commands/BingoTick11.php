<?php
namespace App\Console\Commands;

use App\Services\GameService;
use Illuminate\Console\Command;

class BingoTick extends Command
{
    protected $signature = 'beteseb:tick';
    protected $description = 'Advance active Ethiobingo rounds';

    public function handle(GameService $game): int
    {
        // Advance every active room, not only the default room-1.
        foreach ($game->rooms() as $room) {
            if (($room['status'] ?? 'active') !== 'active') {
                continue;
            }

            $game->advance($room['id']);
        }

        return self::SUCCESS;
    }
}
