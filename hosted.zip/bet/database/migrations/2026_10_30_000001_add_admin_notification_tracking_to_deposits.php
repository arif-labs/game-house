<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasColumn('deposits', 'admin_notified_at')) {
            Schema::table('deposits', function (Blueprint $table) {
                $table->timestamp('admin_notified_at')->nullable()->index();
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('deposits', 'admin_notified_at')) {
            Schema::table('deposits', function (Blueprint $table) {
                $table->dropIndex(['admin_notified_at']);
                $table->dropColumn('admin_notified_at');
            });
        }
    }
};
