<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ApiController;
use App\Http\Controllers\TelegramController;
use App\Http\Controllers\TelegramBotsController;
use App\Http\Controllers\CrashController;
use App\Http\Controllers\KenoController;
use App\Http\Controllers\GameAdminController;
use Illuminate\Session\Middleware\StartSession;

Route::middleware('web')->group(function () {

    Route::prefix('admin')->group(function () {
        Route::post('/login', [ApiController::class, 'adminLogin'])
            ->middleware('throttle:10,1');

        Route::middleware('admin.session')->group(function () {
            Route::get('/me', [ApiController::class, 'adminMe']);
            Route::post('/logout', [ApiController::class, 'adminLogout']);
            Route::get('/health', [ApiController::class, 'adminHealth']);
            Route::get('/state', [ApiController::class, 'adminState']);
            Route::get('/games/control', [GameAdminController::class, 'overview']);
            Route::put('/games/{game}/settings', [GameAdminController::class, 'updateSettings']);
            Route::put('/games/bingo/rooms/{id}/status', [GameAdminController::class, 'setBingoRoomStatus']);
            Route::get('/games/reports', [GameAdminController::class, 'report']);
            Route::put('/settings', [ApiController::class, 'settings']);
            Route::get('/payment-accounts', [\App\Http\Controllers\PaymentAccountController::class, 'adminShow']);
            Route::put('/payment-accounts', [\App\Http\Controllers\PaymentAccountController::class, 'adminSave']);
            Route::get('/finance-alerts', [\App\Http\Controllers\FinanceAlertController::class, 'show']);
            Route::post('/kill-switch', [ApiController::class, 'killSwitch']);
            Route::get('/audit', [ApiController::class, 'audit']);
            Route::get('/game-state', [ApiController::class, 'adminGameState']);
            Route::get('/finance-summary', [ApiController::class, 'adminFinanceSummary']);
            Route::post('/house-wallet/fund', [ApiController::class, 'fundHouseWallet']);
            Route::get('/reports', [ApiController::class, 'adminReports']);
            Route::get('/round-history', [ApiController::class, 'adminRoundHistory']);
            Route::get('/bot-status', [ApiController::class, 'adminBotStatus']);
            Route::put('/rooms/{id}/bot-settings', [ApiController::class, 'updateBotSettings']);

            
Route::get('/rooms', [ApiController::class, 'adminRooms']);
Route::post('/rooms', [ApiController::class, 'saveRoom']);
Route::put('/rooms/{id}', [ApiController::class, 'updateRoom']);
Route::put('/rooms/{id}/status', [ApiController::class, 'updateRoomStatus']);
            Route::post('/game-action', [ApiController::class, 'gameAction']);
        });
    });

    Route::post('/player/telegram-auth', [ApiController::class, 'playerTelegramAuth'])
        ->middleware('throttle:30,1');

    Route::middleware('player.session')->group(function () {
        Route::get('/crash/state', [CrashController::class, 'state']);
        Route::get('/keno/config', [KenoController::class, 'config']);
        Route::post('/keno/play', [KenoController::class, 'play'])->middleware('throttle:30,1');
        Route::get('/keno/history', [KenoController::class, 'history']);
        Route::post('/crash/bet', [CrashController::class, 'bet'])->middleware('throttle:30,1');
        Route::post('/crash/cashout', [CrashController::class, 'cashout'])->middleware('throttle:60,1');
        Route::get('/spin/config', [\App\Http\Controllers\SpinController::class, 'config']);
        Route::post('/spin/play', [\App\Http\Controllers\SpinController::class, 'play'])->middleware('throttle:30,1');
        Route::post('/player/logout', [ApiController::class, 'playerLogout']);
        Route::get('/player/state', [ApiController::class, 'playerState']);
        Route::get('/player/profile-actions', [ApiController::class, 'playerProfileActions']);
        Route::post('/player/transfer-balance', [ApiController::class, 'playerTransferBalance'])->middleware('throttle:10,1');
        Route::get('/player/leaderboard', [ApiController::class, 'playerLeaderboard']);
        Route::post('/player/deposit', [ApiController::class, 'deposit']);
        Route::post('/player/withdrawal', [ApiController::class, 'withdrawal']);
        Route::post('/player/wallet/move-to-play', [ApiController::class, 'moveToPlay'])->middleware('throttle:20,1');
        Route::get('/player/payment-accounts', [\App\Http\Controllers\PaymentAccountController::class, 'playerShow']);
        Route::post('/game/select', [ApiController::class, 'select']);
        Route::post('/game/release', [ApiController::class, 'release']);
        Route::post('/game/claim', [ApiController::class, 'claim']);
    });
    
    // Admin-only Telegram configuration and diagnostic endpoints.
    Route::middleware('admin.session')->group(function () {
        Route::get('/telegram/status', [TelegramController::class, 'status']);
        Route::get('/telegram/bot-config', [TelegramController::class, 'botConfig']);
        Route::put('/telegram/bot-config', [TelegramController::class, 'saveBotConfig']);
        Route::post('/telegram/register-webhook', [TelegramController::class, 'registerWebhook'])
            ->middleware('throttle:5,1');
        Route::post('/telegram/verify-init-data', [TelegramController::class, 'verifyInitData'])
            ->middleware('throttle:10,1');
        Route::get('/telegram/bots', [TelegramBotsController::class, 'index']);
        Route::post('/telegram/bots', [TelegramBotsController::class, 'save']);
        Route::post('/telegram/bots/{botKey}/test', [TelegramBotsController::class, 'test']);
        Route::post('/telegram/bots/{botKey}/register-webhook', [TelegramBotsController::class, 'registerWebhook'])
            ->middleware('throttle:5,1');
        Route::delete('/telegram/bots/{botKey}', [TelegramBotsController::class, 'remove']);
    });

    // Public bot links are used by the Mini App to send players back to the bot that launched it.
    Route::get('/telegram/public-bot-link', [TelegramController::class, 'publicBotLink']);
    Route::get('/telegram/bots/{botKey}/public-link', [TelegramBotsController::class, 'publicPhoneShareLink']);

    // Telegram calls these endpoints directly, without an admin browser session.
    Route::post('/telegram/bots/{botKey}/webhook', [TelegramBotsController::class, 'webhook'])
        ->middleware('throttle:120,1');
    Route::post('/telegram/webhook', [TelegramController::class, 'webhook'])
        ->middleware('throttle:120,1');

    // Missing API paths must return JSON, never the SPA HTML fallback.
    Route::fallback(fn () => response()->json([
        'ok' => false,
        'error' => 'API endpoint not found.',
    ], 404));
});
