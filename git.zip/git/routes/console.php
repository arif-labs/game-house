<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

// Bingo rounds have one-second timers, so the scheduler must stay running
// (php artisan schedule:work) for every active room to progress.
Schedule::command('beteseb:tick')->everySecond()->withoutOverlapping();

// Re-check deposits that could not be verified automatically yet (checker unreachable / receipt not visible yet).
Schedule::command('deposits:verify-pending')->everyMinute()->withoutOverlapping();
