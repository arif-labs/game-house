<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return response()->file(public_path('build/index.html'));
});

Route::fallback(function () {
    return response()->file(public_path('build/index.html'));
});