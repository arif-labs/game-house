export type GamePhase = 'LOBBY' | 'SELECTION' | 'COUNTDOWN_END' | 'DRAWING' | 'FINISHED' | 'PAYOUT';

export type BingoLetter = 'B' | 'I' | 'N' | 'G' | 'O';

export type WinPatternType = 'any_row' | 'any_col' | 'any_diagonal' | 'four_corners' | 'full_house';

export interface DrawnBall {
  letter: BingoLetter;
  number: number;
  seq: number;
  timestamp: number;
}

export interface CartelaCard {
  id: number;
  // 5x5 grid: [row][col] where col 0=B, 1=I, 2=N, 3=G, 4=O
  // cell at [2][2] is 0 (FREE center)
  matrix: number[][];
}

export interface RoomConfig {
  id: string;
  name: string;
  amharicName: string;
  stake: number; // in ETB (Birr)
  minPlayers: number;
  maxPlayers: number;
  rakePercent: number; // e.g. 20 for 20%
  selectionDuration: number; // in seconds (default 45s)
  drawInterval: number; // in seconds (default 3s)
  maxCartelasPerPlayer: number; // admin-configured per-player cartela limit (1-200)
  selectionSeconds?: number;
  automatedPlayersEnabled?: boolean;
  automatedPlayerCount?: number;
  automatedPlayersTriggerBelow?: number;
  automatedPlayersTarget?: number;
  enabledPatterns: WinPatternType[];
  isVip?: boolean;
  inviteCode?: string;
  status: 'active' | 'paused' | 'maintenance';
}

export interface RoundState {
  roundId: string;
  roundCode: string;
  roomId: string;
  phase: GamePhase;
  timerSeconds: number;
  ballsDrawn: DrawnBall[];
  currentBall: DrawnBall | null;
  previousBalls: DrawnBall[];
  playersCount: number;
  totalPool: number;
  derashPrize: number;
  rakeEarned: number;
  seedCommitment: string; // SHA-256 hash committed before round
  revealedSeed: string | null; // revealed after round finishes
  winners: RoundWinner[];
  startedAt: number;
  finishedAt: number | null;
}

export interface RoundWinner {
  userId: string;
  username: string;
  cartelaId: number;
  cartela?: number[][];
  pattern: WinPatternType;
  winningBall: number;
  prizeAmount: number;
  isBot?: boolean;
}

export interface CartelaReservation {
  cartelaId: number;
  userId: string;
  username: string;
  status: 'reserved' | 'confirmed';
  reservedAt: number;
  isBot?: boolean;
  walletType?: 'MAIN' | 'PLAY' | 'HOUSE';
}

export interface PlayerProfile {
  id: string;
  username: string;
  fullName: string;
  telegramId?: string;
  phone: string;
  phoneVerifiedAt?: string | null;
  avatarUrl: string;
  mainWalletBalance: number; // withdrawable
  playWalletBalance: number; // bonus
  totalDeposited: number;
  totalWithdrawn: number;
  roundsPlayed: number;
  roundsWon: number;
  isBanned: boolean | null;
  riskScore: number | null; // null means not tracked
  kycStatus: 'unknown' | 'unverified' | 'pending' | 'verified';
  selfExclusionUntil: number | null;
  dailyDepositLimit: number | null;
}

export type LedgerEntryType =
  | 'DEPOSIT'
  | 'WITHDRAWAL'
  | 'STAKE_RESERVED'
  | 'STAKE_REFUNDED'
  | 'WIN_PAYOUT'
  | 'RAKE_FEE'
  | 'BONUS_GRANT'
  | 'REFERRAL_BONUS'
  | 'TRANSFER_IN'
  | 'TRANSFER_OUT'
  | 'MANUAL_ADJUSTMENT';

export interface LedgerEntry {
  id: string;
  timestamp: number;
  userId: string;
  username: string;
  type: LedgerEntryType;
  walletType: 'MAIN' | 'PLAY';
  amount: number; // positive or negative
  balanceAfter: number;
  referenceId: string;
  description: string;
}

export type AdminRole = 'super_admin' | 'finance' | 'support' | 'game_operator' | 'auditor';

export interface AdminUser {
  id: string;
  name: string;
  email: string;
  role: AdminRole;
  totpEnabled: boolean;
  lastActive: number;
}

export interface AuditLogItem {
  id: string;
  timestamp: number;
  adminName: string;
  adminRole: AdminRole;
  action: string;
  targetType: string;
  targetId: string;
  reason: string;
  details?: Record<string, any>;
}

export interface DepositRequest {
  id: string;
  userId: string;
  username: string;
  amount: number;
  provider: 'Telebirr' | 'CBE Birr' | 'Amole' | 'Telegram Pay';
  referenceNo: string;
  slipUrl?: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: number;
  reviewedBy?: string;
}

export interface WithdrawalRequest {
  id: string;
  userId: string;
  username: string;
  amount: number;
  provider: 'Telebirr' | 'CBE Birr';
  accountNumber: string;
  accountName: string;
  status: 'pending' | 'approved' | 'rejected' | 'paid';
  createdAt: number;
  reviewedBy?: string;
}

export interface FraudAlert {
  id: string;
  userId: string;
  username: string;
  severity: 'low' | 'medium' | 'high';
  type: 'MULTI_ACCOUNT' | 'COLLUSION_PATTERN' | 'ABNORMAL_WIN_RATE' | 'RAPID_DEPOSIT_CASHOUT' | 'CLAIM_SPAM';
  description: string;
  timestamp: number;
  status: 'open' | 'investigating' | 'resolved';
}

export interface SystemAnnouncement {
  id: string;
  title: string;
  titleAmharic: string;
  message: string;
  messageAmharic: string;
  type: 'info' | 'warning' | 'jackpot';
  active: boolean;
  createdAt: number;
}
