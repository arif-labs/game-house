import React from 'react';
import { createRoot } from 'react-dom/client';
import { AdminTelegramBots } from './components/admin/AdminTelegramBots';
import './index.css';

function MultiBotAdmin() {
  return (
    <div className="min-h-screen bg-[#0b0416] text-[#f8fafc]">
      <header className="border-b border-purple-900 bg-[#110624] px-4 py-4">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-3">
          <div>
            <h1 className="text-lg font-black text-white">Ethio Game House · Multiple Bot Controller</h1>
            <p className="mt-1 text-xs text-purple-300">Admin-only Telegram bot connections</p>
          </div>
          <a href="/admin" className="rounded-xl border border-purple-700 px-3 py-2 text-xs font-bold text-purple-200 hover:bg-purple-900/40">← Back to Admin</a>
        </div>
      </header>
      <main className="mx-auto max-w-5xl p-4 sm:p-6">
        <AdminTelegramBots />
      </main>
    </div>
  );
}

createRoot(document.getElementById('root')!).render(<MultiBotAdmin />);
