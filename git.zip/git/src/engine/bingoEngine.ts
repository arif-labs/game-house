import { CartelaCard, BingoLetter, DrawnBall, WinPatternType, RoundWinner } from '../types/bingo';

export const B_RANGE = [1, 15] as const;
export const I_RANGE = [16, 30] as const;
export const N_RANGE = [31, 45] as const;
export const G_RANGE = [46, 60] as const;
export const O_RANGE = [61, 75] as const;

export function getLetterForNumber(num: number): BingoLetter {
  if (num >= 1 && num <= 15) return 'B';
  if (num >= 16 && num <= 30) return 'I';
  if (num >= 31 && num <= 45) return 'N';
  if (num >= 46 && num <= 60) return 'G';
  if (num >= 61 && num <= 75) return 'O';
  throw new Error(`Invalid 75-ball bingo number: ${num}`);
}

export function getLetterColorClass(letter: BingoLetter): {
  bg: string;
  text: string;
  border: string;
  glow: string;
  name: string;
} {
  switch (letter) {
    case 'B':
      return { bg: 'bg-blue-600', text: 'text-blue-400', border: 'border-blue-500', glow: 'shadow-blue-500/50', name: 'Blue' };
    case 'I':
      return { bg: 'bg-indigo-600', text: 'text-indigo-400', border: 'border-indigo-500', glow: 'shadow-indigo-500/50', name: 'Indigo' };
    case 'N':
      return { bg: 'bg-purple-600', text: 'text-purple-400', border: 'border-purple-500', glow: 'shadow-purple-500/50', name: 'Purple' };
    case 'G':
      return { bg: 'bg-emerald-600', text: 'text-emerald-400', border: 'border-emerald-500', glow: 'shadow-emerald-500/50', name: 'Green' };
    case 'O':
      return { bg: 'bg-amber-600', text: 'text-amber-400', border: 'border-amber-500', glow: 'shadow-amber-500/50', name: 'Orange' };
  }
}

// Simple deterministic PRNG (Mulberry32) for deterministic cartelas & seed hashing
function mulberry32(seed: number) {
  return function () {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Generates 5 unique random numbers in range [min, max] using a PRNG
function pickFiveUnique(min: number, max: number, randomFn: () => number): number[] {
  const pool: number[] = [];
  for (let i = min; i <= max; i++) pool.push(i);
  // Fisher-Yates shuffle
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(randomFn() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  return pool.slice(0, 5);
}

/**
 * Generate a single deterministic Cartela Card by ID (1 to 200)
 */
export function generateCartela(id: number): CartelaCard {
  // Use id as seed base for reproducible cartela set
  const prng = mulberry32(id * 1847 + 9327);

  const bCol = pickFiveUnique(B_RANGE[0], B_RANGE[1], prng);
  const iCol = pickFiveUnique(I_RANGE[0], I_RANGE[1], prng);
  const nCol = pickFiveUnique(N_RANGE[0], N_RANGE[1], prng);
  const gCol = pickFiveUnique(G_RANGE[0], G_RANGE[1], prng);
  const oCol = pickFiveUnique(O_RANGE[0], O_RANGE[1], prng);

  // Center cell [2][2] is FREE (represented as 0)
  nCol[2] = 0;

  // Build 5x5 matrix where row index is first, col index is second
  const matrix: number[][] = [];
  for (let row = 0; row < 5; row++) {
    matrix.push([bCol[row], iCol[row], nCol[row], gCol[row], oCol[row]]);
  }

  return { id, matrix };
}

/**
 * Cache of all 200 standard Cartelas
 */
export const STANDARD_CARTELAS: CartelaCard[] = (() => {
  const list: CartelaCard[] = [];
  for (let i = 1; i <= 200; i++) {
    list.push(generateCartela(i));
  }
  return list;
})();

export function getCartelaById(id: number): CartelaCard {
  return STANDARD_CARTELAS[id - 1] || generateCartela(id);
}

/**
 * SHA-256 Hex Digest for Provably Fair seeds
 */
export async function sha256Hex(message: string): Promise<string> {
  const msgUint8 = new TextEncoder().encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgUint8);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

/**
 * Generates a full 75-ball shuffled draw sequence from a given seed string
 */
export async function generateDrawSequence(seedString: string): Promise<number[]> {
  // Derive each shuffle decision from the full SHA-256 seed rather than
  // collapsing the seed into a 32-bit integer. This preserves the full
  // entropy of the committed seed while remaining deterministic.
  const balls = Array.from({ length: 75 }, (_, i) => i + 1);
  const digest = new Uint8Array(await crypto.subtle.digest(
    'SHA-256',
    new TextEncoder().encode(seedString)
  ));

  let counter = 0;
  const nextRandom = async (): Promise<number> => {
    const counterBytes = new Uint8Array(4);
    new DataView(counterBytes.buffer).setUint32(0, counter++, false);
    const input = new Uint8Array(digest.length + counterBytes.length);
    input.set(digest);
    input.set(counterBytes, digest.length);
    const block = new Uint8Array(await crypto.subtle.digest('SHA-256', input));
    return new DataView(block.buffer).getUint32(0, false) / 0x100000000;
  };

  for (let i = balls.length - 1; i > 0; i--) {
    const j = Math.floor((await nextRandom()) * (i + 1));
    [balls[i], balls[j]] = [balls[j], balls[i]];
  }
  return balls;
}

/**
 * Checks if a specific cell in the 5x5 matrix is marked
 * 0 (Free center) is always considered marked!
 */
export function isCellMarked(number: number, calledSet: Set<number>): boolean {
  if (number === 0) return true; // FREE center
  return calledSet.has(number);
}

/**
 * Validates whether a card has achieved any of the allowed winning patterns
 */
export function checkCardWinningPatterns(
  matrix: number[][],
  calledNumbers: number[],
  enabledPatterns: WinPatternType[] = ['any_row', 'any_col', 'any_diagonal', 'four_corners', 'full_house']
): { hasWon: boolean; winningPatterns: WinPatternType[] } {
  const calledSet = new Set(calledNumbers);
  const winningPatterns: WinPatternType[] = [];

  // 1. Any Row
  if (enabledPatterns.includes('any_row')) {
    for (let r = 0; r < 5; r++) {
      let rowComplete = true;
      for (let c = 0; c < 5; c++) {
        if (!isCellMarked(matrix[r][c], calledSet)) {
          rowComplete = false;
          break;
        }
      }
      if (rowComplete) {
        winningPatterns.push('any_row');
        break;
      }
    }
  }

  // 2. Any Column
  if (enabledPatterns.includes('any_col')) {
    for (let c = 0; c < 5; c++) {
      let colComplete = true;
      for (let r = 0; r < 5; r++) {
        if (!isCellMarked(matrix[r][c], calledSet)) {
          colComplete = false;
          break;
        }
      }
      if (colComplete) {
        winningPatterns.push('any_col');
        break;
      }
    }
  }

  // 3. Any Diagonal
  if (enabledPatterns.includes('any_diagonal')) {
    let diag1 = true;
    let diag2 = true;
    for (let i = 0; i < 5; i++) {
      if (!isCellMarked(matrix[i][i], calledSet)) diag1 = false;
      if (!isCellMarked(matrix[i][4 - i], calledSet)) diag2 = false;
    }
    if (diag1 || diag2) {
      winningPatterns.push('any_diagonal');
    }
  }

  // 4. Four Corners: (0,0), (0,4), (4,0), (4,4)
  if (enabledPatterns.includes('four_corners')) {
    if (
      isCellMarked(matrix[0][0], calledSet) &&
      isCellMarked(matrix[0][4], calledSet) &&
      isCellMarked(matrix[4][0], calledSet) &&
      isCellMarked(matrix[4][4], calledSet)
    ) {
      winningPatterns.push('four_corners');
    }
  }

  // 5. Full House (Coverall)
  if (enabledPatterns.includes('full_house')) {
    let full = true;
    for (let r = 0; r < 5; r++) {
      for (let c = 0; c < 5; c++) {
        if (!isCellMarked(matrix[r][c], calledSet)) {
          full = false;
          break;
        }
      }
      if (!full) break;
    }
    if (full) {
      winningPatterns.push('full_house');
    }
  }

  return {
    hasWon: winningPatterns.length > 0,
    winningPatterns,
  };
}

/**
 * Calculates numbers to go (how many marks needed for the closest winning pattern)
 */
export function calculateNumbersToGo(
  matrix: number[][],
  calledNumbers: number[],
  enabledPatterns: WinPatternType[] = ['any_row', 'any_col', 'any_diagonal', 'four_corners', 'full_house']
): number {
  const calledSet = new Set(calledNumbers);
  let minToGo = 25;

  // Rows
  if (enabledPatterns.includes('any_row')) {
    for (let r = 0; r < 5; r++) {
      let needed = 0;
      for (let c = 0; c < 5; c++) {
        if (!isCellMarked(matrix[r][c], calledSet)) needed++;
      }
      if (needed < minToGo) minToGo = needed;
    }
  }

  // Columns
  if (enabledPatterns.includes('any_col')) {
    for (let c = 0; c < 5; c++) {
      let needed = 0;
      for (let r = 0; r < 5; r++) {
        if (!isCellMarked(matrix[r][c], calledSet)) needed++;
      }
      if (needed < minToGo) minToGo = needed;
    }
  }

  // Diagonals
  if (enabledPatterns.includes('any_diagonal')) {
    let d1 = 0;
    let d2 = 0;
    for (let i = 0; i < 5; i++) {
      if (!isCellMarked(matrix[i][i], calledSet)) d1++;
      if (!isCellMarked(matrix[i][4 - i], calledSet)) d2++;
    }
    if (d1 < minToGo) minToGo = d1;
    if (d2 < minToGo) minToGo = d2;
  }

  // Four Corners
  if (enabledPatterns.includes('four_corners')) {
    let cornersNeeded = 0;
    if (!isCellMarked(matrix[0][0], calledSet)) cornersNeeded++;
    if (!isCellMarked(matrix[0][4], calledSet)) cornersNeeded++;
    if (!isCellMarked(matrix[4][0], calledSet)) cornersNeeded++;
    if (!isCellMarked(matrix[4][4], calledSet)) cornersNeeded++;
    if (cornersNeeded < minToGo) minToGo = cornersNeeded;
  }

  return minToGo;
}

/**
 * Prize Pool & Rake Math:
 * Derash = (players * stake) * (1 - rakePercent / 100)
 */
export function calculatePrizePool(playersCount: number, stake: number, rakePercent: number): {
  totalPool: number;
  rakeEarned: number;
  derashPrize: number;
} {
  const totalPool = Math.round(playersCount * stake * 100) / 100;
  const rakeEarned = Math.round((totalPool * (rakePercent / 100)) * 100) / 100;
  const derashPrize = Math.round((totalPool - rakeEarned) * 100) / 100;
  return { totalPool, rakeEarned, derashPrize };
}
