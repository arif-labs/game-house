import React, { useState } from 'react';
import { Sliders, Save, CheckCircle2, ShieldAlert, Award, Clock } from 'lucide-react';
import { gameStore } from '../../services/gameStore';
import { WinPatternType } from '../../types/bingo';

export const AdminSettings: React.FC = () => {
  const [globalRake, setGlobalRake] = useState(20);
  const [selectionDuration, setSelectionDuration] = useState(40);
  const [drawInterval, setDrawInterval] = useState(3);
  const [claimPenaltySeconds, setClaimPenaltySeconds] = useState(10);
  const [maxCartelas, setMaxCartelas] = useState(1);
  const [enabledPatterns, setEnabledPatterns] = useState<WinPatternType[]>([
    'any_row',
    'any_col',
    'any_diagonal',
    'four_corners',
    'full_house'
  ]);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const togglePattern = (pattern: WinPatternType) => {
    setEnabledPatterns((prev) =>
      prev.includes(pattern) ? prev.filter((p) => p !== pattern) : [...prev, pattern]
    );
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    gameStore.adminUpdateSettings({
      rakePercent: globalRake,
      selectionDuration,
      drawInterval,
      maxCartelasPerPlayer: maxCartelas,
      enabledPatterns
    }, undefined, 'Admin updated global game version rules');

    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-black text-white">Versioned Game Settings</h2>
          <p className="text-xs text-purple-300">
            Configure house rake %, draw intervals, pattern recognition, and penalty cooldowns
          </p>
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* House Rake & Economics */}
        <div className="bg-[#120626] border border-purple-900/80 rounded-2xl p-5 shadow-xl space-y-4">
          <h3 className="text-sm font-extrabold text-amber-400 uppercase tracking-wider flex items-center">
            <Sliders className="w-4 h-4 mr-1.5" />
            House Rake & Prize Pool Parameters
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="text-purple-300 font-bold block mb-1">
                Global House Rake (%)
              </label>
              <div className="flex items-center space-x-2">
                <input
                  type="number"
                  min={5}
                  max={40}
                  value={globalRake}
                  onChange={(e) => setGlobalRake(Number(e.target.value))}
                  className="w-full bg-[#1b0c34] border border-purple-800 rounded-xl px-3 py-2 text-white font-bold"
                />
                <span className="text-purple-400 font-bold">%</span>
              </div>
              <span className="text-[10px] text-purple-400 mt-1 block">
                Derash = Total pool × (100 - {globalRake})%
              </span>
            </div>

            <div>
              <label className="text-purple-300 font-bold block mb-1">
                Max Cartelas Per Player
              </label>
              <input
                type="number"
                min={1}
                max={200}
                value={maxCartelas}
                onChange={(e) => setMaxCartelas(Number(e.target.value))}
                className="w-full bg-[#1b0c34] border border-purple-800 rounded-xl px-3 py-2 text-white font-bold"
              />
              <span className="text-[10px] text-purple-400 mt-1 block">
                Admin-controlled limit per player (up to 200 cartelas)
              </span>
            </div>
          </div>
        </div>

        {/* Timers & Draw Speeds */}
        <div className="bg-[#120626] border border-purple-900/80 rounded-2xl p-5 shadow-xl space-y-4">
          <h3 className="text-sm font-extrabold text-amber-400 uppercase tracking-wider flex items-center">
            <Clock className="w-4 h-4 mr-1.5" />
            Timers & Ball Calling Intervals
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="text-purple-300 font-bold block mb-1">
                Selection Phase Duration (Seconds)
              </label>
              <input
                type="number"
                min={15}
                max={90}
                value={selectionDuration}
                onChange={(e) => setSelectionDuration(Number(e.target.value))}
                className="w-full bg-[#1b0c34] border border-purple-800 rounded-xl px-3 py-2 text-white font-bold"
              />
              <span className="text-[10px] text-purple-400 mt-1 block">
                Standard: 40s (15s minimum for rapid testing)
              </span>
            </div>

            <div>
              <label className="text-purple-300 font-bold block mb-1">
                Ball Draw Interval (Seconds)
              </label>
              <input
                type="number"
                min={1}
                max={10}
                value={drawInterval}
                onChange={(e) => setDrawInterval(Number(e.target.value))}
                className="w-full bg-[#1b0c34] border border-purple-800 rounded-xl px-3 py-2 text-white font-bold"
              />
              <span className="text-[10px] text-purple-400 mt-1 block">
                Default: 3s per ball for caller speech synthesis
              </span>
            </div>
          </div>
        </div>

        {/* Winning Patterns Allowed */}
        <div className="bg-[#120626] border border-purple-900/80 rounded-2xl p-5 shadow-xl space-y-4">
          <h3 className="text-sm font-extrabold text-amber-400 uppercase tracking-wider flex items-center">
            <Award className="w-4 h-4 mr-1.5" />
            Active Winning Patterns
          </h3>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
            {[
              { id: 'any_row', label: 'Any Horizontal Row' },
              { id: 'any_col', label: 'Any Vertical Column' },
              { id: 'any_diagonal', label: 'Both Diagonals' },
              { id: 'four_corners', label: 'Four Outer Corners' },
              { id: 'full_house', label: 'Full House (Coverall)' }
            ].map((p) => {
              const checked = enabledPatterns.includes(p.id as WinPatternType);
              return (
                <label
                  key={p.id}
                  className={`p-3 rounded-xl border flex items-center space-x-2.5 cursor-pointer transition-colors ${
                    checked
                      ? 'bg-amber-500/15 border-amber-400/60 text-amber-200'
                      : 'bg-[#180a32] border-purple-900 text-purple-400'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={checked}
                    onChange={() => togglePattern(p.id as WinPatternType)}
                    className="w-4 h-4 accent-amber-500"
                  />
                  <span className="font-bold">{p.label}</span>
                </label>
              );
            })}
          </div>
        </div>

        {/* Claim Penalties */}
        <div className="bg-[#120626] border border-purple-900/80 rounded-2xl p-5 shadow-xl space-y-4">
          <h3 className="text-sm font-extrabold text-amber-400 uppercase tracking-wider flex items-center">
            <ShieldAlert className="w-4 h-4 mr-1.5" />
            False Claim Prevention & Penalties
          </h3>

          <div className="text-xs space-y-2">
            <label className="text-purple-300 font-bold block mb-1">
              Temporary Claim Lock on False Claim (Seconds)
            </label>
            <input
              type="number"
              min={5}
              max={60}
              value={claimPenaltySeconds}
              onChange={(e) => setClaimPenaltySeconds(Number(e.target.value))}
              className="w-full max-w-xs bg-[#1b0c34] border border-purple-800 rounded-xl px-3 py-2 text-white font-bold"
            />
            <span className="text-[10px] text-purple-400 block">
              Repeated false claims also automatically trigger a Fraud & Risk flag.
            </span>
          </div>
        </div>

        {saveSuccess && (
          <div className="p-3 bg-emerald-500/20 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs font-bold flex items-center justify-center space-x-2">
            <CheckCircle2 className="w-4 h-4" />
            <span>Settings version updated! New rules will apply to next round.</span>
          </div>
        )}

        <button
          type="submit"
          className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-extrabold text-xs shadow-xl flex items-center space-x-2 active:scale-95 transition-all"
        >
          <Save className="w-4 h-4" />
          <span>Save & Apply To Next Rounds</span>
        </button>
      </form>
    </div>
  );
};
