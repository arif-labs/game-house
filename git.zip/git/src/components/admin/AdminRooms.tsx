import React, { useState } from 'react';
import { Plus, Power, Edit2, X, Bot } from 'lucide-react';
import { gameStore } from '../../services/gameStore';
import { RoomConfig } from '../../types/bingo';

type RoomForm = {
  name: string;
  amharicName: string;
  stake: number;
  rakePercent: number;
  minPlayers: number;
  maxPlayers: number;
  selectionSeconds: number;
  drawInterval: number;
  maxCartelasPerPlayer: number;
  automatedPlayersEnabled: boolean;
  automatedPlayerCount: number;
  automatedPlayersTriggerBelow: number;
  automatedPlayersTarget: number;
  isVip: boolean;
  inviteCode: string;
};

const emptyForm = (): RoomForm => ({
  name: '', amharicName: '', stake: 5, rakePercent: 20,
  minPlayers: 2, maxPlayers: 200, selectionSeconds: 40, drawInterval: 3, maxCartelasPerPlayer: 5,
  automatedPlayersEnabled: false, automatedPlayerCount: 0,
  automatedPlayersTriggerBelow: 10, automatedPlayersTarget: 10,
  isVip: false, inviteCode: '',
});

export const AdminRooms: React.FC = () => {
  const rooms = gameStore.rooms;
  const [showModal, setShowModal] = useState(false);
  const [editingRoom, setEditingRoom] = useState<RoomConfig | null>(null);
  const [form, setForm] = useState<RoomForm>(emptyForm());
  const [saving, setSaving] = useState(false);
  const [roomError, setRoomError] = useState('');

  const openCreate = () => {
    setEditingRoom(null);
    setForm(emptyForm());
    setRoomError('');
    setShowModal(true);
  };

  const openEdit = (room: RoomConfig) => {
    setEditingRoom(room);
    setForm({
      name: room.name,
      amharicName: room.amharicName || room.name,
      stake: room.stake,
      rakePercent: room.rakePercent,
      minPlayers: room.minPlayers,
      maxPlayers: room.maxPlayers || 200,
      selectionSeconds: room.selectionSeconds || room.selectionDuration || 40,
      drawInterval: room.drawInterval,
      maxCartelasPerPlayer: room.maxCartelasPerPlayer || 5,
      automatedPlayersEnabled: Boolean(room.automatedPlayersEnabled),
      automatedPlayerCount: room.automatedPlayerCount || 0,
      automatedPlayersTriggerBelow: room.automatedPlayersTriggerBelow || 10,
      automatedPlayersTarget: room.automatedPlayersTarget || 10,
      isVip: Boolean(room.isVip),
      inviteCode: room.inviteCode || '',
    });
    setRoomError('');
    setShowModal(true);
  };

  const setField = <K extends keyof RoomForm>(key: K, value: RoomForm[K]) => {
    setForm((current) => ({ ...current, [key]: value }));
  };

  const handleSaveRoom = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || saving) return;
    if (form.minPlayers > form.maxPlayers) {
      setRoomError('Maximum players must be at least the minimum players.');
      return;
    }
    if (form.automatedPlayersEnabled && form.automatedPlayersTarget > form.maxPlayers) {
      setRoomError('Automated-player target cannot exceed the room maximum.');
      return;
    }

    setSaving(true);
    setRoomError('');
    try {
      const payload = {
        ...form,
        name: form.name.trim(),
        amharicName: form.amharicName.trim() || form.name.trim(),
        inviteCode: form.isVip ? (form.inviteCode.trim() || null) : null,
        enabledPatterns: editingRoom?.enabledPatterns || ['any_row', 'any_col', 'any_diagonal', 'four_corners', 'full_house'],
      };
      const response = await fetch(
        editingRoom ? `/api/admin/rooms/${encodeURIComponent(editingRoom.id)}` : '/api/admin/rooms',
        {
          method: editingRoom ? 'PUT' : 'POST',
          credentials: 'include',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        }
      );
      const data = await response.json();
      if (!response.ok || !data.room) {
        throw new Error(data.message || data.error || 'Could not save room settings.');
      }
      await gameStore.refreshAdminState();
      setShowModal(false);
      setEditingRoom(null);
      setForm(emptyForm());
    } catch (error) {
      setRoomError(error instanceof Error ? error.message : 'Could not save room settings.');
    } finally {
      setSaving(false);
    }
  };

  const handleToggleStatus = async (room: RoomConfig) => {
    if (saving) return;
    setSaving(true);
    setRoomError('');
    try {
      const response = await fetch(`/api/admin/rooms/${encodeURIComponent(room.id)}/status`, {
        method: 'PUT',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: room.status === 'active' ? 'paused' : 'active' }),
      });
      const data = await response.json();
      if (!response.ok || !data.room) throw new Error(data.message || data.error || 'Could not update room.');
      await gameStore.refreshAdminState();
    } catch (error) {
      setRoomError(error instanceof Error ? error.message : 'Could not update room.');
    } finally {
      setSaving(false);
    }
  };

  const fieldClass = 'w-full bg-[#120624] border border-purple-800 rounded-xl px-3 py-2 text-white';
  const labelClass = 'text-purple-300 font-bold block mb-1';

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-black text-white">Room Management</h2>
          <p className="text-xs text-purple-300">Configure stakes, timers, player limits, VIP access, and disclosed house-controlled automated participants.</p>
        </div>
        <button onClick={openCreate} className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-black font-extrabold text-xs flex items-center gap-1.5">
          <Plus className="w-4 h-4" /> Create New Room
        </button>
      </div>

      {roomError && <p role="alert" className="text-sm text-red-300">{roomError}</p>}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {rooms.map((room) => {
          const round = gameStore.roundStates[room.id];
          return (
            <div key={room.id} className="bg-[#120626] border border-purple-900/80 rounded-2xl p-4 shadow-xl space-y-3 relative overflow-hidden">
              {room.isVip && <div className="absolute top-0 right-0 bg-amber-500 text-black text-[9px] font-black uppercase px-2 py-0.5 rounded-bl-lg">VIP • Code: {room.inviteCode}</div>}
              <div className="flex items-center justify-between gap-2">
                <div>
                  <h3 className="font-extrabold text-base text-white">{room.name}</h3>
                  <span className="text-[11px] text-purple-300">{room.amharicName}</span>
                </div>
                <div className="flex gap-1.5">
                  <button onClick={() => openEdit(room)} className="p-1.5 rounded-lg border border-purple-700 text-purple-200" title="Edit room settings"><Edit2 className="w-4 h-4" /></button>
                  <button onClick={() => void handleToggleStatus(room)} disabled={saving} className={`p-1.5 rounded-lg border text-xs font-bold ${room.status === 'active' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' : 'bg-red-500/20 text-red-300 border-red-500/40'}`} title={room.status === 'active' ? 'Pause room' : 'Activate room'}><Power className="w-4 h-4" /></button>
                </div>
              </div>
              <div className="p-2.5 rounded-xl bg-[#1b0c34] border border-purple-800 text-xs space-y-1.5">
                <div className="flex justify-between"><span className="text-purple-400">Stake:</span><strong className="text-amber-300">{room.stake} ETB</strong></div>
                <div className="flex justify-between"><span className="text-purple-400">House rake:</span><strong className="text-white">{room.rakePercent}%</strong></div>
                <div className="flex justify-between"><span className="text-purple-400">Draw speed:</span><strong className="text-white">{room.drawInterval}s per ball</strong></div>
                <div className="flex justify-between"><span className="text-purple-400">Selection timer:</span><strong className="text-white">{room.selectionSeconds || room.selectionDuration}s</strong></div>
                <div className="flex justify-between"><span className="text-purple-400">Current phase:</span><span className="font-bold text-amber-400 uppercase">{round?.phase || 'SELECTION'}</span></div>
              </div>
              <div className="text-[10px] text-purple-400 flex items-center justify-between"><span>Min: {room.minPlayers} • Max: {room.maxPlayers} players</span><span className="font-mono">{room.id}</span></div>
              <div className="rounded-xl border border-purple-800 bg-[#1b0c34] p-3 text-xs">
                <div className="flex items-center gap-1.5 text-purple-200 font-bold"><Bot className="w-4 h-4 text-amber-400" /> Automated participants</div>
                <p className="mt-1 text-purple-300">{room.automatedPlayersEnabled ? `Enabled • up to ${room.automatedPlayerCount} • trigger below ${room.automatedPlayersTriggerBelow} real players • target ${room.automatedPlayersTarget} total` : 'Disabled for this room'}</p>
                {room.automatedPlayersEnabled && <p className="mt-1 text-amber-200/90">Bots are disclosed in the player interface and require a funded house wallet.</p>}
              </div>
            </div>
          );
        })}
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 overflow-y-auto">
          <form onSubmit={handleSaveRoom} className="bg-[#1b0c34] border border-purple-700 rounded-2xl p-5 max-w-2xl w-full my-4 shadow-2xl space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-purple-800">
              <h3 className="font-extrabold text-white text-sm">{editingRoom ? 'Edit Room Settings' : 'Create New Room'}</h3>
              <button type="button" onClick={() => setShowModal(false)} className="text-purple-400 hover:text-white"><X className="w-4 h-4" /></button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div><label className={labelClass}>Room Name</label><input className={fieldClass} value={form.name} onChange={(e) => setField('name', e.target.value)} required maxLength={120} placeholder="e.g. Kazanchis Pro" /></div>
              <div><label className={labelClass}>Amharic Name</label><input className={fieldClass} value={form.amharicName} onChange={(e) => setField('amharicName', e.target.value)} maxLength={120} placeholder="ካዛንቺስ ፕሮ" /></div>
              <div><label className={labelClass}>Stake (ETB)</label><input className={fieldClass} type="number" min={1} max={100000} step="0.01" value={form.stake} onChange={(e) => setField('stake', Number(e.target.value))} required /></div>
              <div><label className={labelClass}>Rake (%)</label><input className={fieldClass} type="number" min={0} max={99.99} step="0.01" value={form.rakePercent} onChange={(e) => setField('rakePercent', Number(e.target.value))} required /></div>
              <div><label className={labelClass}>Minimum participants to start</label><input className={fieldClass} type="number" min={1} max={200} value={form.minPlayers} onChange={(e) => setField('minPlayers', Number(e.target.value))} required /></div>
              <div><label className={labelClass}>Maximum participants</label><input className={fieldClass} type="number" min={1} max={200} value={form.maxPlayers} onChange={(e) => setField('maxPlayers', Number(e.target.value))} required /></div>
              <div><label className={labelClass}>Selection timer (seconds)</label><input className={fieldClass} type="number" min={5} max={600} value={form.selectionSeconds} onChange={(e) => setField('selectionSeconds', Number(e.target.value))} required /></div>
              <div><label className={labelClass}>Draw interval (seconds)</label><input className={fieldClass} type="number" min={1} max={60} value={form.drawInterval} onChange={(e) => setField('drawInterval', Number(e.target.value))} required /></div>
              <div><label className={labelClass}>Maximum cartelas per player</label><input className={fieldClass} type="number" min={1} max={200} value={form.maxCartelasPerPlayer} onChange={(e) => setField('maxCartelasPerPlayer', Number(e.target.value))} required /><p className="mt-1 text-[10px] text-purple-400">Set the per-player limit for this room (1–200).</p></div>
            </div>

            <div className="rounded-xl border border-purple-700 p-3 space-y-3">
              <label className="flex items-center gap-2 text-sm text-white font-bold">
                <input type="checkbox" checked={form.automatedPlayersEnabled} onChange={(e) => setField('automatedPlayersEnabled', e.target.checked)} className="accent-amber-500" />
                Enable disclosed house-controlled automated participants
              </label>
              <p className="text-[11px] text-purple-300">Bots join at the end of selection only when real-player count is below the configured threshold. They are identified as automated participants to players.</p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div><label className={labelClass}>Maximum bots to add</label><input className={fieldClass} type="number" min={0} max={200} value={form.automatedPlayerCount} onChange={(e) => setField('automatedPlayerCount', Number(e.target.value))} disabled={!form.automatedPlayersEnabled} /></div>
                <div><label className={labelClass}>Activate below (real players)</label><input className={fieldClass} type="number" min={1} max={200} value={form.automatedPlayersTriggerBelow} onChange={(e) => setField('automatedPlayersTriggerBelow', Number(e.target.value))} disabled={!form.automatedPlayersEnabled} /></div>
                <div><label className={labelClass}>Target total participants</label><input className={fieldClass} type="number" min={1} max={form.maxPlayers} value={form.automatedPlayersTarget} onChange={(e) => setField('automatedPlayersTarget', Number(e.target.value))} disabled={!form.automatedPlayersEnabled} /></div>
              </div>
            </div>

            <div className="flex items-center gap-2 text-xs">
              <input type="checkbox" id="vip_chk" checked={form.isVip} onChange={(e) => setField('isVip', e.target.checked)} className="accent-amber-500" />
              <label htmlFor="vip_chk" className="text-purple-200 font-bold">Make Private VIP Room</label>
            </div>
            {form.isVip && <div><label className={labelClass}>Invite Code</label><input className={fieldClass} value={form.inviteCode} onChange={(e) => setField('inviteCode', e.target.value)} maxLength={64} placeholder="VIP-CODE-77" /></div>}

            {roomError && <p role="alert" className="text-sm text-red-300">{roomError}</p>}
            <div className="pt-2 flex justify-end gap-2">
              <button type="button" onClick={() => setShowModal(false)} className="px-3 py-2 rounded-xl bg-purple-900/60 text-purple-300 text-xs">Cancel</button>
              <button type="submit" disabled={saving} className="px-4 py-2 rounded-xl bg-amber-500 text-black font-extrabold text-xs disabled:opacity-50">{saving ? 'Saving...' : editingRoom ? 'Save Changes' : 'Create Room'}</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
