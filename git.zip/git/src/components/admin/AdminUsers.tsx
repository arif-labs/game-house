import React, { useEffect, useMemo, useState } from 'react';
import { Search, Wallet, RefreshCw, X } from 'lucide-react';
import { gameStore, AdminPlayerRecord } from '../../services/gameStore';

const money = (amount: number) => `${amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ETB`;

export const AdminUsers: React.FC = () => {
  const [, setTick] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUserId, setSelectedUserId] = useState('');
  const [showAdjustModal, setShowAdjustModal] = useState(false);
  const [adjustWallet, setAdjustWallet] = useState<'MAIN' | 'PLAY'>('MAIN');
  const [adjustAmount, setAdjustAmount] = useState('');
  const [adjustReason, setAdjustReason] = useState('');
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    const unsubscribe = gameStore.subscribe(() => setTick((n) => n + 1));
    void gameStore.refreshAdminState();
    return unsubscribe;
  }, []);

  const users = gameStore.users;
  const filteredUsers = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    if (!query) return users;
    return users.filter((user) =>
      [user.username, user.fullName ?? '', user.phone ?? '', user.id]
        .some((value) => value.toLowerCase().includes(query))
    );
  }, [users, searchQuery]);
  const selectedUser = users.find((user) => user.id === selectedUserId) ?? null;

  const handleAdjustSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    const amount = Number(adjustAmount);
    if (!selectedUser || !Number.isFinite(amount) || amount === 0 || !adjustReason.trim()) {
      setError('Select a real account, enter a non-zero amount, and provide a reason.');
      return;
    }
    setSaving(true); setError(''); setMessage('');
    try {
      const response = await fetch('/api/admin/game-action', {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'adjust', userId: selectedUser.id, walletType: adjustWallet, amount, reason: adjustReason.trim() })
      });
      const result = await response.json();
      if (!response.ok || result?.ok !== true) throw new Error(result?.error || 'Balance adjustment failed.');
      await gameStore.refreshAdminState();
      setShowAdjustModal(false); setAdjustAmount(''); setAdjustReason('');
      setMessage('Adjustment recorded in the server ledger.');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Balance adjustment failed.');
    } finally { setSaving(false); }
  };

  return <div className="space-y-6">
    <div className="flex items-center justify-between gap-3">
      <div><h2 className="text-lg font-black text-white">Users & Wallet Accounts</h2><p className="text-xs text-purple-300">Accounts and balances loaded from the database. Unsupported risk/KYC flags are not inferred.</p></div>
      <button onClick={() => void gameStore.refreshAdminState()} className="px-3 py-2 rounded-xl border border-purple-700 text-purple-200 text-xs font-bold flex items-center gap-1.5"><RefreshCw className="w-4 h-4" /> Refresh</button>
    </div>
    {message && <p role="status" className="rounded-xl border border-emerald-500/40 bg-emerald-500/10 p-3 text-sm text-emerald-200">{message}</p>}
    {error && !showAdjustModal && <p role="alert" className="rounded-xl border border-red-500/40 bg-red-500/10 p-3 text-sm text-red-200">{error}</p>}

    <div className="relative max-w-md">
      <Search className="w-4 h-4 absolute left-3 top-2.5 text-purple-400" />
      <input type="text" placeholder="Search username, phone, or account ID" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="w-full bg-[#120626] border border-purple-800 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400" />
    </div>

    <div className="overflow-x-auto rounded-2xl border border-purple-900 bg-[#120626]">
      <table className="w-full text-left text-xs text-purple-200">
        <thead className="bg-[#1a0a34] text-purple-300"><tr>{['Player', 'Main wallet', 'Play wallet', 'Deposited', 'Withdrawn', 'Rounds', 'Wins', 'Action'].map((h) => <th key={h} className="p-3">{h}</th>)}</tr></thead>
        <tbody className="divide-y divide-purple-900/60">
          {filteredUsers.map((user) => <tr key={user.id} onClick={() => setSelectedUserId(user.id)} className={`cursor-pointer hover:bg-[#180b32] ${selectedUserId === user.id ? 'bg-purple-900/20' : ''}`}>
            <td className="p-3"><strong className="block text-white">{user.username}</strong><span className="block text-[10px] text-purple-400">{user.phone || 'Phone not provided'}</span><span className="block font-mono text-[9px] text-purple-500">{user.id}</span></td>
            <td className="p-3">{money(user.mainWalletBalance)}</td><td className="p-3">{money(user.playWalletBalance)}</td>
            <td className="p-3">{money(user.totalDeposited)}</td><td className="p-3">{money(user.totalWithdrawn)}</td>
            <td className="p-3">{user.roundsPlayed}</td><td className="p-3">{user.roundsWon}</td>
            <td className="p-3"><button onClick={(event) => { event.stopPropagation(); setSelectedUserId(user.id); setShowAdjustModal(true); setError(''); }} className="rounded-lg border border-purple-700 px-3 py-1.5 font-bold text-amber-300">Adjust</button></td>
          </tr>)}
          {filteredUsers.length === 0 && <tr><td colSpan={8} className="p-6 text-center text-purple-400">{users.length === 0 ? 'No player accounts returned by the server.' : 'No accounts match this search.'}</td></tr>}
        </tbody>
      </table>
    </div>

    {selectedUser && <div className="rounded-2xl border border-purple-900 bg-[#120626] p-4 space-y-2">
      <h3 className="font-bold text-white">Selected account: {selectedUser.username}</h3>
      <p className="text-xs text-purple-300">Full name: {selectedUser.fullName || 'Not provided'} · Phone verification: {selectedUser.phoneVerifiedAt ? 'Verified' : 'Not verified'}</p>
      <button onClick={() => { setShowAdjustModal(true); setError(''); }} className="inline-flex items-center gap-2 rounded-xl bg-amber-500 px-4 py-2 text-xs font-black text-black"><Wallet className="w-4 h-4" /> Adjust wallet balance</button>
    </div>}

    {showAdjustModal && <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
      <form onSubmit={handleAdjustSubmit} className="w-full max-w-md space-y-4 rounded-2xl border border-purple-700 bg-[#180b30] p-5">
        <div className="flex items-center justify-between"><h3 className="font-extrabold text-white">Record wallet adjustment</h3><button type="button" onClick={() => setShowAdjustModal(false)}><X className="h-5 w-5 text-purple-300" /></button></div>
        <p className="text-xs text-purple-300">Account: {selectedUser?.username || 'Select an account'}</p>
        <label className="block text-xs text-purple-300">Wallet<select value={adjustWallet} onChange={(e) => setAdjustWallet(e.target.value as 'MAIN' | 'PLAY')} className="mt-1 w-full rounded-xl border border-purple-800 bg-[#120626] p-2 text-white"><option value="MAIN">Main wallet</option><option value="PLAY">Play wallet</option></select></label>
        <label className="block text-xs text-purple-300">Amount in ETB (negative values deduct)<input required type="number" step="0.01" value={adjustAmount} onChange={(e) => setAdjustAmount(e.target.value)} className="mt-1 w-full rounded-xl border border-purple-800 bg-[#120626] p-2 text-white" /></label>
        <label className="block text-xs text-purple-300">Reason<input required minLength={4} value={adjustReason} onChange={(e) => setAdjustReason(e.target.value)} className="mt-1 w-full rounded-xl border border-purple-800 bg-[#120626] p-2 text-white" /></label>
        {error && <p role="alert" className="text-xs text-red-200">{error}</p>}
        <button disabled={saving || !selectedUser} className="w-full rounded-xl bg-amber-500 p-3 text-sm font-black text-black disabled:opacity-50">{saving ? 'Saving…' : 'Submit adjustment'}</button>
      </form>
    </div>}
  </div>;
};
