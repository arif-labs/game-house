import React, { useEffect, useState } from 'react';
import { AlertOctagon, RefreshCw, Database } from 'lucide-react';
import { gameStore } from '../../services/gameStore';

type AuditRow = { id: string; timestamp: number; adminName: string; adminRole: string; action: string; targetType: string; targetId: string; reason: string };

export const AdminSystem: React.FC = () => {
  const [, setTick] = useState(0);
  const [health, setHealth] = useState<{ service?: string; database?: string } | null>(null);
  const [auditLogs, setAuditLogs] = useState<AuditRow[]>([]);
  const [healthError, setHealthError] = useState('');
  const [auditError, setAuditError] = useState('');
  const [filterAction, setFilterAction] = useState('');

  const reload = async () => {
    setHealthError(''); setAuditError('');
    const [healthResult, auditResult] = await Promise.allSettled([
      fetch('/api/admin/health', { credentials: 'include' }).then(async (r) => { const d = await r.json(); if (!r.ok || d?.ok !== true) throw new Error(d?.error || 'Health check failed'); return d; }),
      fetch('/api/admin/audit', { credentials: 'include' }).then(async (r) => { const d = await r.json(); if (!r.ok || d?.ok !== true) throw new Error(d?.error || 'Audit log could not be loaded'); return d; })
    ]);
    if (healthResult.status === 'fulfilled') setHealth(healthResult.value);
    else { setHealth(null); setHealthError(healthResult.reason instanceof Error ? healthResult.reason.message : 'Health check failed'); }
    if (auditResult.status === 'fulfilled') {
      setAuditLogs((auditResult.value.audit ?? []).map((row: any) => ({
        id: String(row.id ?? ''),
        timestamp: typeof row.timestamp === 'number' ? row.timestamp : Date.parse(row.timestamp ?? row.created_at ?? '') || 0,
        adminName: String(row.admin_name ?? row.adminName ?? row.admin_email ?? 'Unknown admin'),
        adminRole: String(row.admin_role ?? row.adminRole ?? 'Not recorded'),
        action: String(row.action ?? 'Unknown action'),
        targetType: String(row.target_type ?? row.targetType ?? ''),
        targetId: String(row.target_id ?? row.targetId ?? ''),
        reason: String(row.reason ?? '')
      })));
    } else { setAuditLogs([]); setAuditError(auditResult.reason instanceof Error ? auditResult.reason.message : 'Audit log could not be loaded'); }
    await gameStore.refreshAdminState();
  };

  useEffect(() => {
    const unsubscribe = gameStore.subscribe(() => setTick((n) => n + 1));
    void reload();
    return unsubscribe;
  }, []);

  const filteredLogs = auditLogs.filter((log) => !filterAction || [log.action, log.adminName, log.reason].some((v) => v.toLowerCase().includes(filterAction.toLowerCase())));

  return <div className="space-y-6">
    <div className="flex items-center justify-between gap-3">
      <div><h2 className="text-lg font-black text-white">System Diagnostics & Audit Logs</h2><p className="text-xs text-purple-300">Only checks reported by the backend are shown.</p></div>
      <button onClick={() => void reload()} className="rounded-xl border border-purple-700 px-3 py-2 text-xs font-bold text-purple-200 flex items-center gap-1.5"><RefreshCw className="h-4 w-4" /> Refresh</button>
    </div>

    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
      <div className="rounded-xl border border-purple-900 bg-[#120626] p-4 space-y-2">
        <div className="flex items-center gap-2"><Database className="h-5 w-5 text-amber-400" /><strong className="text-white">Database connectivity</strong></div>
        {healthError ? <p className="text-xs text-red-200">{healthError}</p> : health ? <><p className="text-sm text-emerald-300">Connected · {health.service || 'Application service'}</p><p className="text-xs text-purple-300">Driver/database: {health.database || 'Connected (name not returned)'}</p></> : <p className="text-xs text-purple-300">Checking…</p>}
      </div>
      <div className="rounded-xl border border-purple-900 bg-[#120626] p-4 space-y-2">
        <div className="flex items-center gap-2"><AlertOctagon className="h-5 w-5 text-amber-400" /><strong className="text-white">Global maintenance switch</strong></div>
        <p className="text-sm text-purple-200">Status: <strong className={gameStore.isKillSwitchActive ? 'text-red-300' : 'text-emerald-300'}>{gameStore.isKillSwitchActive ? 'Active' : 'Inactive'}</strong></p>
        <button onClick={() => { if (confirm('Toggle global maintenance switch?')) void gameStore.adminToggleKillSwitch('Manual change from system diagnostics'); }} className="rounded-xl border border-purple-700 px-3 py-2 text-xs font-bold text-purple-200">{gameStore.isKillSwitchActive ? 'Deactivate switch' : 'Activate switch'}</button>
      </div>
    </div>

    <div className="rounded-2xl border border-purple-900 bg-[#120626] overflow-hidden">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-purple-900 p-4">
        <div><h3 className="font-extrabold text-white text-sm">Database audit trail ({filteredLogs.length} records)</h3><p className="text-[10px] text-purple-400">Only persisted admin_audit records appear here.</p></div>
        <input value={filterAction} onChange={(e) => setFilterAction(e.target.value)} placeholder="Filter action, admin, reason" className="rounded-lg border border-purple-800 bg-[#110524] px-3 py-2 text-xs text-white" />
      </div>
      {auditError && <p role="alert" className="p-3 text-xs text-red-200">{auditError}</p>}
      <div className="overflow-x-auto"><table className="w-full text-left text-xs text-purple-200">
        <thead className="bg-[#1a0a34] text-purple-300"><tr>{['Time', 'Admin', 'Role', 'Action', 'Target', 'Reason'].map((h) => <th key={h} className="p-3">{h}</th>)}</tr></thead>
        <tbody className="divide-y divide-purple-900/60">
          {filteredLogs.map((log) => <tr key={log.id}><td className="p-3">{log.timestamp ? new Date(log.timestamp).toLocaleString() : '—'}</td><td className="p-3">{log.adminName}</td><td className="p-3">{log.adminRole}</td><td className="p-3 font-mono">{log.action}</td><td className="p-3">{log.targetType} {log.targetId}</td><td className="p-3">{log.reason || '—'}</td></tr>)}
          {!auditError && filteredLogs.length === 0 && <tr><td colSpan={6} className="p-6 text-center text-purple-400">No persisted audit records found.</td></tr>}
        </tbody>
      </table></div>
    </div>
    <p className="text-[11px] text-purple-400">Redis, WebSocket connection counts, process memory, and RNG verification metrics are not exposed by this backend and are not estimated here.</p>
  </div>;
};
