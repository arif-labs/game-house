import React, { useState } from 'react';
import { MessageSquare, Send, Volume2, Globe, Sparkles, CheckCircle2 } from 'lucide-react';
import { audioCaller } from '../../engine/audioCaller';

export const AdminContent: React.FC = () => {
  const [broadcastTitle, setBroadcastTitle] = useState('');
  const [broadcastText, setBroadcastText] = useState('');
  const [testNumber, setTestNumber] = useState(12);
  const [sentNotice, setSentNotice] = useState<string | null>(null);

  const handleTestAudio = (lang: 'am' | 'en') => {
    audioCaller.setLanguage(lang);
    audioCaller.setEnabled(true);
    const letter = testNumber <= 15 ? 'B' : testNumber <= 30 ? 'I' : testNumber <= 45 ? 'N' : testNumber <= 60 ? 'G' : 'O';
    audioCaller.announceBall(letter as any, testNumber);
  };

  const handleSendAnnouncement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastTitle) return;

    setSentNotice('Draft preview saved in this screen only. No announcement was sent to players.');
    setBroadcastTitle('');
    setBroadcastText('');
    setTimeout(() => setSentNotice(null), 3000);
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h2 className="text-lg font-black text-white">Content, Comms & Audio Voice Packs</h2>
        <p className="text-xs text-purple-300">
          Preview announcement copy and test spoken Amharic & English caller audio. Broadcasting is not connected.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Broadcast Announcement */}
        <form
          onSubmit={handleSendAnnouncement}
          className="bg-[#120626] border border-purple-900/80 rounded-2xl p-5 shadow-xl space-y-3.5"
        >
          <h3 className="font-extrabold text-white text-sm flex items-center text-amber-400">
            <Send className="w-4 h-4 mr-1.5" />
            Draft In-App Announcement (Preview Only)
          </h3>

          <div className="space-y-2 text-xs">
            <div>
              <label className="text-purple-300 font-bold block mb-1">Title</label>
              <input
                type="text"
                placeholder="e.g. Weekend Super Derash Event!"
                value={broadcastTitle}
                onChange={(e) => setBroadcastTitle(e.target.value)}
                className="w-full bg-[#1b0c34] border border-purple-800 rounded-xl px-3 py-1.5 text-white"
                required
              />
            </div>

            <div>
              <label className="text-purple-300 font-bold block mb-1">Message Body</label>
              <textarea
                placeholder="Details of the announcement..."
                rows={3}
                value={broadcastText}
                onChange={(e) => setBroadcastText(e.target.value)}
                className="w-full bg-[#1b0c34] border border-purple-800 rounded-xl px-3 py-1.5 text-white"
              />
            </div>

            {sentNotice && (
              <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-center font-bold">
                {sentNotice}
              </div>
            )}

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-black font-extrabold text-xs shadow-md active:scale-95 transition-all"
            >
              Preview Draft
            </button>
          </div>
        </form>

        {/* Audio Voice Pack Synthesizer Test */}
        <div className="bg-[#120626] border border-purple-900/80 rounded-2xl p-5 shadow-xl space-y-4">
          <h3 className="font-extrabold text-white text-sm flex items-center text-purple-300">
            <Volume2 className="w-4 h-4 mr-1.5 text-amber-400" />
            Bingo Caller Speech Test
          </h3>

          <div className="space-y-3 text-xs">
            <div>
              <label className="text-purple-300 font-bold block mb-1">
                Select Ball Number (1–75)
              </label>
              <input
                type="number"
                min={1}
                max={75}
                value={testNumber}
                onChange={(e) => setTestNumber(Number(e.target.value))}
                className="w-full bg-[#1b0c34] border border-purple-800 rounded-xl px-3 py-1.5 text-white font-bold"
              />
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                type="button"
                onClick={() => handleTestAudio('am')}
                className="py-2.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 font-bold flex items-center justify-center space-x-1"
              >
                <Volume2 className="w-4 h-4" />
                <span>አማርኛ (Amharic)</span>
              </button>

              <button
                type="button"
                onClick={() => handleTestAudio('en')}
                className="py-2.5 rounded-xl bg-purple-900/40 hover:bg-purple-800 text-purple-200 border border-purple-700 font-bold flex items-center justify-center space-x-1"
              >
                <Volume2 className="w-4 h-4" />
                <span>English (EN)</span>
              </button>
            </div>

            <p className="text-[10px] text-purple-400 leading-relaxed">
              Synthesizes acoustic casino chime bell pings via Web Audio API + natural spoken language utterances.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
