import React, { useState } from 'react';
import { Grid, Eye, Star, Ban, CheckCircle2, RotateCw, X } from 'lucide-react';
import { STANDARD_CARTELAS, getCartelaById } from '../../engine/bingoEngine';
import { CartelaCard } from '../../types/bingo';

export const AdminCartelas: React.FC = () => {
  const [previewCardId, setPreviewCardId] = useState<number | null>(1);
  const [disabledCards, setDisabledCards] = useState<Set<number>>(new Set());
  const [filterQuery, setFilterQuery] = useState('');

  const toggleDisableCard = (id: number) => {
    setDisabledCards((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const previewCard: CartelaCard | null = previewCardId ? getCartelaById(previewCardId) : null;

  const filteredCartelas = STANDARD_CARTELAS.filter((c) => {
    if (!filterQuery) return true;
    return c.id.toString().includes(filterQuery);
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-black text-white">Cartela Sets Manager (1–200)</h2>
          <p className="text-xs text-purple-300">
            Preview any 5x5 card matrix, verify B-I-N-G-O column invariants, and disable suspected cards
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <input
            type="text"
            placeholder="Search Cartela #..."
            value={filterQuery}
            onChange={(e) => setFilterQuery(e.target.value)}
            className="bg-[#1b0c34] border border-purple-800 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: 200 Cards Grid */}
        <div className="lg:col-span-2 bg-[#120626] border border-purple-900/80 rounded-2xl p-4 shadow-xl">
          <div className="flex items-center justify-between pb-3 mb-3 border-b border-purple-900/80 text-xs">
            <span className="text-purple-300 font-bold">
              Showing {filteredCartelas.length} Cards
            </span>
            <span className="text-amber-400 font-medium">
              Click any card to inspect 5x5 layout
            </span>
          </div>

          <div className="grid grid-cols-6 sm:grid-cols-10 gap-1.5 max-h-[560px] overflow-y-auto pr-1">
            {filteredCartelas.map((c) => {
              const isSelected = previewCardId === c.id;
              const isDisabled = disabledCards.has(c.id);

              return (
                <button
                  key={c.id}
                  onClick={() => setPreviewCardId(c.id)}
                  className={`h-11 rounded-lg text-xs font-black transition-all border flex flex-col items-center justify-center ${
                    isDisabled
                      ? 'bg-red-950/60 text-red-300 border-red-800 line-through'
                      : isSelected
                      ? 'bg-amber-500 text-black border-amber-300 scale-105 shadow-md shadow-amber-500/20'
                      : 'bg-[#1b0d33] hover:bg-[#28134d] text-purple-200 border-purple-900'
                  }`}
                >
                  <span>#{c.id}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Card Preview Inspector */}
        <div className="bg-[#120626] border border-purple-900/80 rounded-2xl p-4 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-purple-900">
            <div>
              <h3 className="font-extrabold text-white text-base">
                Cartela #{previewCard?.id || 1}
              </h3>
              <span className="text-[11px] text-purple-400">
                Deterministic Seed Generation Verified
              </span>
            </div>

            {previewCard && (
              <button
                onClick={() => toggleDisableCard(previewCard.id)}
                className={`px-2.5 py-1 rounded-xl text-xs font-bold border transition-colors ${
                  disabledCards.has(previewCard.id)
                    ? 'bg-emerald-600/30 text-emerald-300 border-emerald-500'
                    : 'bg-red-600/30 text-red-300 border-red-500'
                }`}
              >
                {disabledCards.has(previewCard.id) ? 'Enable Card' : 'Disable Card'}
              </button>
            )}
          </div>

          {previewCard && (
            <div className="bg-[#1b0c34] p-3 rounded-2xl border border-purple-800 space-y-2">
              <div className="grid grid-cols-5 gap-1 text-center font-black text-xs text-white">
                <span className="bg-blue-600 py-1 rounded">B</span>
                <span className="bg-indigo-600 py-1 rounded">I</span>
                <span className="bg-purple-600 py-1 rounded">N</span>
                <span className="bg-emerald-600 py-1 rounded">G</span>
                <span className="bg-amber-600 py-1 rounded">O</span>
              </div>

              <div className="space-y-1">
                {previewCard.matrix.map((row, rIdx) => (
                  <div key={rIdx} className="grid grid-cols-5 gap-1">
                    {row.map((val, cIdx) => {
                      const isCenter = rIdx === 2 && cIdx === 2;
                      return (
                        <div
                          key={cIdx}
                          className={`h-10 rounded-lg flex items-center justify-center font-black text-xs border ${
                            isCenter
                              ? 'bg-amber-500/20 text-amber-300 border-amber-400/60'
                              : 'bg-[#120624] text-white border-purple-900'
                          }`}
                        >
                          {isCenter ? <Star className="w-4 h-4 text-amber-400 fill-amber-400" /> : val}
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="p-3 bg-[#170a2c] rounded-xl text-xs text-purple-300 space-y-1">
            <div className="font-bold text-white">Column Ranges Specification:</div>
            <div>B: 1-15 • I: 16-30 • N: 31-45 (Free Star) • G: 46-60 • O: 61-75</div>
            <div className="text-[10px] text-emerald-400 pt-1">
              ✓ Uniqueness verified across rows and columns
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
