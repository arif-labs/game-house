import React, { useCallback, useEffect, useState } from 'react';
import { Bot, CheckCircle2, ExternalLink, LoaderCircle, Plus, RefreshCw, Save, Trash2, Webhook, Wrench } from 'lucide-react';

type ManagedBot = {
  id: string;
  name: string;
  username: string;
  appUrl: string;
  maskedToken: string;
  enabled: boolean;
  webhookUrl?: string;
  webhookRegisteredAt?: string | null;
};

type BotForm = {
  id: string;
  name: string;
  botToken: string;
  appUrl: string;
  enabled: boolean;
};

const emptyForm = (): BotForm => ({
  id: '',
  name: '',
  botToken: '',
  appUrl: typeof window !== 'undefined' ? window.location.origin : '',
  enabled: true,
});

export const AdminTelegramBots: React.FC = () => {
  const [bots, setBots] = useState<ManagedBot[]>([]);
  const [form, setForm] = useState<BotForm>(emptyForm);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [actionId, setActionId] = useState('');
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  const loadBots = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const response = await fetch('/api/telegram/bots', { credentials: 'include' });
      const data = await response.json();
      if (!response.ok || data?.ok !== true) throw new Error(data?.error || 'Could not load bot connections.');
      setBots(Array.isArray(data.bots) ? data.bots : []);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not load bot connections.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void loadBots(); }, [loadBots]);

  const resetForm = () => {
    setForm(emptyForm());
    setNotice('');
    setError('');
  };

  const saveBot = async (event: React.FormEvent) => {
    event.preventDefault();
    if (saving) return;
    setSaving(true);
    setNotice('');
    setError('');
    try {
      const response = await fetch('/api/telegram/bots', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...(form.id ? { id: form.id } : {}),
          name: form.name,
          botToken: form.botToken,
          appUrl: form.appUrl,
          enabled: form.enabled,
        }),
      });
      const data = await response.json();
      if (!response.ok || data?.ok !== true) throw new Error(data?.error || 'Could not save this bot.');
      setBots(Array.isArray(data.bots) ? data.bots : []);
      setForm({ ...emptyForm(), appUrl: form.appUrl });
      setNotice('Bot connection saved and its token verified with Telegram.');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not save this bot.');
    } finally {
      setSaving(false);
    }
  };

  const testBot = async (bot: ManagedBot) => {
    setActionId(bot.id); setNotice(''); setError('');
    try {
      const response = await fetch('/api/telegram/bots/' + encodeURIComponent(bot.id) + '/test', {
        method: 'POST', credentials: 'include',
      });
      const data = await response.json();
      if (!response.ok || data?.ok !== true) throw new Error(data?.error || 'Telegram token test failed.');
      const username = data.bot?.username ? '@' + data.bot.username : '@' + bot.username;
      const webhook = data.webhook?.url ? ' Webhook: ' + data.webhook.url : ' No webhook is registered yet.';
      setNotice('Connected to ' + username + '.' + webhook);
      await loadBots();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Telegram token test failed.');
    } finally { setActionId(''); }
  };

  const registerBotWebhook = async (bot: ManagedBot) => {
    const appUrl = bot.appUrl || form.appUrl;
    if (!window.confirm('Register a separate webhook and Play Game menu for @' + bot.username + ' using this public URL?\n\n' + appUrl)) return;
    setActionId(bot.id); setNotice(''); setError('');
    try {
      const response = await fetch('/api/telegram/bots/' + encodeURIComponent(bot.id) + '/register-webhook', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ appUrl }),
      });
      const data = await response.json();
      if (!response.ok || data?.ok !== true) throw new Error(data?.error || 'Webhook registration failed.');
      setNotice('Separate webhook registered for @' + bot.username + ': ' + data.webhookUrl + (data.menuButtonConfigured ? ' · Play Game menu configured.' : ' · Menu button needs attention: ' + (data.menuButtonError || 'unknown error')));
      await loadBots();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Webhook registration failed.');
    } finally { setActionId(''); }
  };

  const removeBot = async (bot: ManagedBot) => {
    if (!window.confirm('Remove @' + bot.username + ' from this dashboard and ask Telegram to delete its webhook?')) return;
    setActionId(bot.id); setNotice(''); setError('');
    try {
      const response = await fetch('/api/telegram/bots/' + encodeURIComponent(bot.id), {
        method: 'DELETE', credentials: 'include',
      });
      const data = await response.json();
      if (!response.ok || data?.ok !== true) throw new Error(data?.error || 'Could not remove this bot.');
      setBots(Array.isArray(data.bots) ? data.bots : []);
      if (form.id === bot.id) resetForm();
      setNotice('@' + bot.username + ' was removed from the multi-bot list.');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not remove this bot.');
    } finally { setActionId(''); }
  };

  const editBot = (bot: ManagedBot) => {
    setForm({ id: bot.id, name: bot.name, botToken: '', appUrl: bot.appUrl, enabled: bot.enabled });
    setNotice('Leave the token field blank to keep the currently saved token.');
    setError('');
  };

  return <section className="rounded-2xl border border-amber-500/40 bg-[#10051f] p-5 space-y-5">
    <div className="flex flex-wrap items-start justify-between gap-3">
      <div>
        <div className="flex items-center gap-2"><Bot className="h-5 w-5 text-amber-400" /><h3 className="text-base font-extrabold text-white">Multiple Bot Controller</h3></div>
        <p className="mt-1 max-w-2xl text-xs leading-5 text-purple-300">Manage each Telegram bot separately, test its BotFather token, and register a unique webhook route. Tokens are encrypted at rest and never shown in full.</p>
      </div>
      <button type="button" onClick={() => void loadBots()} className="inline-flex items-center gap-1.5 rounded-xl border border-purple-700 px-3 py-2 text-xs font-bold text-purple-200"><RefreshCw className="h-4 w-4" /> Refresh</button>
    </div>

    <div className="rounded-xl border border-amber-500/30 bg-amber-500/10 p-3 text-xs leading-5 text-amber-100">
      This is an additive multi-bot controller. Keep your current primary bot as-is. Each extra bot needs its own BotFather token and public HTTPS app URL. The existing new-player account and welcome-bonus logic is reused after the selected bot’s signed Telegram authentication is verified; a live end-to-end first-time registration still needs to be tested with a real second bot.
    </div>

    {error && <p role="alert" className="rounded-xl border border-red-500/40 bg-red-500/10 p-3 text-sm text-red-200">{error}</p>}
    {notice && <p role="status" className="rounded-xl border border-emerald-500/40 bg-emerald-500/10 p-3 text-sm text-emerald-200">{notice}</p>}

    <div className="space-y-3">
      <div className="flex items-center justify-between"><h4 className="font-bold text-white">Configured bots</h4><span className="text-[11px] text-purple-400">{bots.length} saved</span></div>
      {loading ? <p className="text-sm text-purple-300">Loading bot connections…</p> : bots.length === 0 ? <p className="rounded-xl border border-dashed border-purple-800 p-4 text-sm text-purple-300">No extra bot connections yet. Add one below; your current primary bot remains unchanged.</p> : bots.map((bot) => (
        <div key={bot.id} className="rounded-xl border border-purple-900 bg-[#180a32] p-4 space-y-3">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2"><strong className="text-sm text-white">{bot.name}</strong><span className="rounded-md bg-purple-900 px-2 py-0.5 text-[10px] text-purple-200">@{bot.username}</span><span className={'rounded-md px-2 py-0.5 text-[10px] font-bold ' + (bot.enabled ? 'bg-emerald-900/70 text-emerald-300' : 'bg-red-900/70 text-red-300')}>{bot.enabled ? 'ENABLED' : 'DISABLED'}</span></div>
              <p className="mt-1 break-all text-[11px] text-purple-400">{bot.maskedToken}</p>
              <p className="mt-1 break-all text-[11px] text-purple-300">{bot.appUrl}</p>
              {bot.webhookUrl && <p className="mt-1 break-all text-[10px] text-emerald-300">Webhook: {bot.webhookUrl}</p>}
            </div>
            <div className="flex flex-wrap gap-2">
              <button type="button" disabled={!!actionId} onClick={() => void testBot(bot)} className="rounded-lg border border-purple-700 px-2.5 py-2 text-[11px] font-bold text-purple-100 disabled:opacity-50"><Wrench className="mr-1 inline h-3.5 w-3.5" />Test</button>
              <button type="button" disabled={!!actionId || !bot.enabled} onClick={() => void registerBotWebhook(bot)} className="rounded-lg border border-amber-500/50 px-2.5 py-2 text-[11px] font-bold text-amber-200 disabled:opacity-50"><Webhook className="mr-1 inline h-3.5 w-3.5" />Register</button>
              <button type="button" disabled={!!actionId} onClick={() => editBot(bot)} className="rounded-lg border border-purple-700 px-2.5 py-2 text-[11px] font-bold text-purple-100">Edit</button>
              <button type="button" disabled={!!actionId} onClick={() => void removeBot(bot)} className="rounded-lg border border-red-500/40 px-2.5 py-2 text-[11px] font-bold text-red-200 disabled:opacity-50"><Trash2 className="mr-1 inline h-3.5 w-3.5" />Remove</button>
            </div>
          </div>
          {actionId === bot.id && <p className="text-xs text-amber-200"><LoaderCircle className="mr-1 inline h-3.5 w-3.5 animate-spin" />Working with Telegram…</p>}
        </div>
      ))}
    </div>

    <form onSubmit={saveBot} className="border-t border-purple-900 pt-5 space-y-4">
      <div className="flex items-center justify-between gap-2"><h4 className="font-bold text-white">{form.id ? 'Edit bot connection' : 'Add a bot connection'}</h4><button type="button" onClick={resetForm} className="text-xs font-bold text-purple-300"><Plus className="mr-1 inline h-3.5 w-3.5" />New entry</button></div>
      <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
        <label className="text-xs font-bold text-purple-200">Display name
          <input required minLength={2} maxLength={80} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Yenegame test bot" className="mt-1 w-full rounded-lg border border-purple-800 bg-[#0d051a] px-3 py-2.5 text-sm font-normal text-white" />
        </label>
        <label className="text-xs font-bold text-purple-200">BotFather token {form.id ? '(blank keeps current)' : ''}
          <input required={!form.id} autoComplete="off" type="password" maxLength={256} value={form.botToken} onChange={(e) => setForm({ ...form, botToken: e.target.value.trim() })} placeholder={form.id ? 'Leave blank to keep current token' : 'Paste bot token'} className="mt-1 w-full rounded-lg border border-purple-800 bg-[#0d051a] px-3 py-2.5 text-sm font-normal text-white" />
        </label>
        <label className="text-xs font-bold text-purple-200 md:col-span-2">Public HTTPS Mini App URL
          <input required type="url" value={form.appUrl} onChange={(e) => setForm({ ...form, appUrl: e.target.value })} placeholder="https://your-public-tunnel.trycloudflare.com" className="mt-1 w-full rounded-lg border border-purple-800 bg-[#0d051a] px-3 py-2.5 text-sm font-normal text-white" />
        </label>
      </div>
      <label className="flex items-center gap-2 text-xs font-bold text-purple-200"><input type="checkbox" checked={form.enabled} onChange={(e) => setForm({ ...form, enabled: e.target.checked })} className="h-4 w-4 accent-amber-500" /> Enable this bot’s webhook and Mini App authentication</label>
      <div className="flex flex-wrap gap-2">
        <button type="submit" disabled={saving} className="rounded-xl bg-amber-500 px-4 py-3 text-xs font-black text-black disabled:opacity-50"><Save className="mr-1.5 inline h-4 w-4" />{saving ? 'Verifying and saving…' : 'Verify & Save Bot'}</button>
        {form.id && <button type="button" onClick={() => { setForm({ ...form, botToken: '' }); setNotice('Token remains unchanged unless you enter a new one and save.'); }} className="rounded-xl border border-purple-700 px-4 py-3 text-xs font-bold text-purple-200">Keep current token</button>}
      </div>
    </form>
    <p className="text-[10px] leading-4 text-purple-500">Token values are never returned to the browser. Registering an extra bot changes that bot’s webhook and chat menu only; it does not replace the existing primary bot’s webhook.</p>
  </section>;
};
