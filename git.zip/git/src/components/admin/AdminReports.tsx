import React, { useCallback, useEffect, useState } from 'react';
import { RefreshCw } from 'lucide-react';

type ReportData = {
  asOf: string;
  summary: {
    registeredPlayers: number;
    completedRoundsToday: number;
    winnerPayoutsToday: number;
    approvedDepositsToday: number;
    approvedWithdrawalsToday: number;
    recordedHouseRakeToday: number | null;
    houseRakeEntriesToday: number;
  };
  rooms: Array<{ id: string; name: string; stake: number; rakePercent: number | null; completedRoundsToday: number }>;
};
const money = (value: number) => `${value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ETB`;

export const AdminReports: React.FC = () => {
  const [data, setData] = useState<ReportData | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const reload = useCallback(async () => {
    setLoading(true); setError('');
    try {
      const response = await fetch('/api/admin/reports', { credentials: 'include' });
      const result = await response.json();
      if (!response.ok || result?.ok !== true) throw new Error(result?.error || 'Reports could not be loaded.');
      setData(result as ReportData);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Reports could not be loaded.');
    } finally { setLoading(false); }
  }, []);
  useEffect(() => { void reload(); }, [reload]);

  return <div className="space-y-6">
    <div className="flex items-center justify-between gap-3">
      <div><h2 className="text-lg font-black text-white">Reports & Financial Analytics</h2><p className="text-xs text-purple-300">Live database records for today; no simulated analytics.</p></div>
      <button onClick={() => void reload()} className="px-3 py-2 rounded-xl border border-purple-700 text-purple-200 text-xs font-bold flex items-center gap-1.5"><RefreshCw className="w-4 h-4" /> Refresh</button>
    </div>
    {loading && !data && <p className="text-sm text-purple-300">Loading reports…</p>}
    {error && <p role="alert" className="rounded-xl border border-red-500/40 bg-red-500/10 p-3 text-sm text-red-200">{error}</p>}
    {data && <>
      <p className="text-[11px] text-purple-400">Data as of {new Date(data.asOf).toLocaleString()}</p>
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3">
        {[
          ['Registered players', String(data.summary.registeredPlayers)],
          ['Completed rounds today', String(data.summary.completedRoundsToday)],
          ['Winner payouts recorded today', money(data.summary.winnerPayoutsToday)],
          ['Approved deposits today', money(data.summary.approvedDepositsToday)],
          ['Approved withdrawals today', money(data.summary.approvedWithdrawalsToday)],
          ['House rake recorded today', data.summary.recordedHouseRakeToday === null ? 'Not recorded' : money(data.summary.recordedHouseRakeToday)]
        ].map(([label, value]) => <div key={label} className="rounded-2xl border border-purple-900 bg-[#120626] p-4"><span className="block text-xs text-purple-300">{label}</span><strong className="mt-2 block text-xl text-white">{value}</strong></div>)}
      </div>
      {data.summary.recordedHouseRakeToday === null && <p className="text-xs text-amber-200">House rake has no dedicated ledger entries, so no revenue figure is estimated from configured percentages.</p>}
      <div className="overflow-x-auto rounded-2xl border border-purple-900 bg-[#120626]">
        <div className="p-4 font-bold text-white">Room activity today</div>
        <table className="w-full text-left text-xs text-purple-200">
          <thead className="bg-[#1a0a34] text-purple-300"><tr>{['Room', 'Configured stake', 'Configured rake', 'Completed rounds today'].map((h) => <th key={h} className="p-3">{h}</th>)}</tr></thead>
          <tbody className="divide-y divide-purple-900/60">
            {data.rooms.map((room) => <tr key={room.id}><td className="p-3 font-bold text-white">{room.name}</td><td className="p-3">{money(room.stake)}</td><td className="p-3">{room.rakePercent === null ? 'Not configured' : `${room.rakePercent}%`}</td><td className="p-3">{room.completedRoundsToday}</td></tr>)}
            {data.rooms.length === 0 && <tr><td colSpan={4} className="p-6 text-center text-purple-400">No rooms are configured.</td></tr>}
          </tbody>
        </table>
      </div>
    </>}
  </div>;
};
