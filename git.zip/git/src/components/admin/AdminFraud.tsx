import React from 'react';
import { ShieldAlert, AlertTriangle } from 'lucide-react';

export const AdminFraud: React.FC = () => (
  <div className="max-w-4xl space-y-6">
    <div>
      <h2 className="text-lg font-black text-white">Fraud & Risk Monitoring</h2>
      <p className="text-xs text-purple-300">
        This screen reports implementation status; it does not invent alerts or risk scores.
      </p>
    </div>

    <div className="rounded-2xl border border-amber-500/40 bg-amber-500/10 p-5 space-y-3">
      <div className="flex items-center gap-2">
        <AlertTriangle className="h-5 w-5 text-amber-300" />
        <h3 className="font-extrabold text-white">Server-backed risk monitoring is not connected</h3>
      </div>
      <p className="text-sm leading-6 text-amber-100">
        The current backend does not expose a persisted fraud-alert feed or enforce the advertised
        IP/device matching, collusion detection, win-rate anomaly rules, or automatic withdrawal holds.
        Those rules must not be treated as enabled.
      </p>
    </div>

    <div className="rounded-2xl border border-purple-900 bg-[#120626] p-5 space-y-2">
      <div className="flex items-center gap-2">
        <ShieldAlert className="h-5 w-5 text-purple-300" />
        <h3 className="font-bold text-white">Risk alert queue</h3>
      </div>
      <p className="text-sm text-purple-300">
        No verified alert records are available because alert generation and persistence are not implemented.
        This is not a claim that the platform has no risk.
      </p>
    </div>
  </div>
);
