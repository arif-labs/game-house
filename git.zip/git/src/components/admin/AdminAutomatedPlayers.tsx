import React, { useCallback, useEffect, useState } from 'react';
import { Bot, RefreshCw, Save, AlertTriangle, Wallet, Activity } from 'lucide-react';

type BotSettings = {
  automatedPlayersEnabled: boolean;
  automatedPlayerCount: number;
  automatedPlayersTriggerBelow: number;
  automatedPlayersTarget: number;
  automatedPlayersRiskControlEnabled: boolean;
  automatedPlayersMaxStakeBudget: number;
  automatedPlayersMaxHouseExposure: number;
  automatedPlayersStrategy: 'conservative' | 'balanced' | 'aggressive';
  automatedPlayersManualOverrideEnabled: boolean;
  automatedPlayersBotsPerRealCartela: number;
};

type BotRoom = {
  id: string;
  name: string;
  status: string;
  stake: number;
  settings: Partial<BotSettings>;
  ready: boolean;
  blockers: string[];
  walletBotsAffordable: number;
  round: {
    phase: string | null;
    timerSeconds: number;
    realPlayers: number;
    realCartelas: number;
    bots: number;
    botSeats: string[];
    wantedBots: number;
  };
};

type Diagnostics = {
  wallet?: { balance: number; profitLoss: number };
  schedulerLastTick?: number | null;
  serverTime?: number;
  killSwitch?: boolean;
  rooms?: BotRoom[];
  ledger?: Array<{ type?: string; amount?: number; balanceAfter?: number; createdAt?: string }>;
};

const defaults: BotSettings = {
  automatedPlayersEnabled: false,
  automatedPlayerCount: 0,
  automatedPlayersTriggerBelow: 10,
  automatedPlayersTarget: 10,
  automatedPlayersRiskControlEnabled: true,
  automatedPlayersMaxStakeBudget: 50,
  automatedPlayersMaxHouseExposure: 100,
  automatedPlayersStrategy: 'balanced',
  automatedPlayersManualOverrideEnabled: false,
  automatedPlayersBotsPerRealCartela: 1,
};

const inputClass = 'w-full rounded-lg border border-purple-800 bg-[#100622] px-3 py-2 text-sm text-white outline-none focus:border-amber-400';
const labelClass = 'mb-1 block text-xs font-semibold text-purple-200';

export const AdminAutomatedPlayers: React.FC = () => {
  const [data, setData] = useState<Diagnostics>({});
  const [selectedId, setSelectedId] = useState('');
  const [form, setForm] = useState<BotSettings>(defaults);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const load = useCallback(async (keepNotice = false) => {
    setLoading(true);
    setError('');
    if (!keepNotice) setNotice('');
    try {
      const response = await fetch('/api/admin/bot-status', {
        credentials: 'include',
        headers: { Accept: 'application/json' },
      });
      const result = await response.json();
      if (!response.ok || result.ok === false) {
        throw new Error(result.error || `Unable to load bot status (${response.status})`);
      }
      const rooms: BotRoom[] = result.rooms || [];
      setData(result);
      setSelectedId((current) => rooms.some((room) => room.id === current) ? current : rooms[0]?.id || '');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Unable to load automated-player status.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  const room = (data.rooms || []).find((item) => item.id === selectedId);

  useEffect(() => {
    if (!room) return;
    setForm({ ...defaults, ...room.settings });
  }, [selectedId, data.rooms]);

  const setField = <K extends keyof BotSettings>(key: K, value: BotSettings[K]) => {
    setForm((current) => ({ ...current, [key]: value }));
  };

  const save = async () => {
    if (!room) return;
    setSaving(true);
    setError('');
    setNotice('');
    try {
      const response = await fetch(`/api/admin/rooms/${encodeURIComponent(room.id)}/bot-settings`, {
        method: 'PUT',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify(form),
      });
      const result = await response.json();
      if (!response.ok || result.ok === false) {
        throw new Error(result.error || (response.status === 403
          ? 'Your admin role cannot change automated-player settings.'
          : `Save failed (${response.status})`));
      }
      setNotice(`Settings saved for ${room.name}.`);
      await load(true);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not save bot settings.');
    } finally {
      setSaving(false);
    }
  };

  const money = (value?: number) => `${Number(value || 0).toLocaleString(undefined, { maximumFractionDigits: 2 })} ETB`;
  const tickAge = data.schedulerLastTick
    ? Math.max(0, Math.floor(Date.now() / 1000) - data.schedulerLastTick)
    : null;

  return (
    <div className="h-full overflow-y-auto space-y-5 p-4 sm:p-6 text-slate-100">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="flex items-center gap-2 text-xl font-black text-white">
            <Bot className="h-6 w-6 text-amber-400" /> Automated Players
          </h1>
          <p className="mt-1 text-sm text-purple-300">Room-level bot controls, readiness checks, and scheduler diagnostics.</p>
        </div>
        <button onClick={() => void load()} disabled={loading} className="inline-flex items-center gap-2 rounded-xl border border-purple-700 px-3 py-2 text-sm font-bold hover:bg-purple-900/50 disabled:opacity-50">
          <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} /> Refresh status
        </button>
      </div>

      {error && <div role="alert" className="rounded-xl border border-red-500/40 bg-red-950/40 p-3 text-sm text-red-200">{error}</div>}
      {notice && <div role="status" className="rounded-xl border border-emerald-500/40 bg-emerald-950/30 p-3 text-sm text-emerald-200">{notice}</div>}

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <div className="rounded-2xl border border-purple-800 bg-[#16092a] p-4">
          <div className="flex items-center gap-2 text-xs font-bold text-purple-300"><Wallet className="h-4 w-4" /> House wallet</div>
          <div className="mt-2 text-2xl font-black text-white">{money(data.wallet?.balance)}</div>
          <div className="mt-1 text-xs text-purple-300">Profit/loss: {money(data.wallet?.profitLoss)}</div>
        </div>
        <div className="rounded-2xl border border-purple-800 bg-[#16092a] p-4">
          <div className="flex items-center gap-2 text-xs font-bold text-purple-300"><Activity className="h-4 w-4" /> Scheduler</div>
          <div className={`mt-2 text-xl font-black ${tickAge !== null && tickAge <= 15 ? 'text-emerald-300' : 'text-amber-300'}`}>
            {tickAge === null ? 'No tick recorded' : tickAge <= 15 ? 'Recently active' : 'Tick is stale'}
          </div>
          <div className="mt-1 text-xs text-purple-300">{tickAge === null ? 'Waiting for first recorded tick' : `Last tick ${tickAge}s ago`}</div>
        </div>
        <div className="rounded-2xl border border-purple-800 bg-[#16092a] p-4">
          <div className="text-xs font-bold text-purple-300">Kill switch</div>
          <div className={`mt-2 text-xl font-black ${data.killSwitch ? 'text-red-300' : 'text-emerald-300'}`}>{data.killSwitch ? 'ACTIVE' : 'Inactive'}</div>
          <div className="mt-1 text-xs text-purple-300">Reported by the game service</div>
        </div>
        <div className="rounded-2xl border border-purple-800 bg-[#16092a] p-4">
          <div className="text-xs font-bold text-purple-300">Room readiness</div>
          <div className="mt-2 text-2xl font-black text-white">{(data.rooms || []).filter((r) => r.ready).length} / {(data.rooms || []).length}</div>
          <div className="mt-1 text-xs text-purple-300">Rooms without reported blockers</div>
        </div>
      </div>

      {loading && !data.rooms ? <p className="text-sm text-purple-300">Loading bot diagnostics…</p> : (
        <>
          <section className="rounded-2xl border border-purple-800 bg-[#130723] p-4">
            <h2 className="mb-3 text-sm font-black uppercase tracking-wide text-purple-200">Room status</h2>
            <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
              {(data.rooms || []).map((item) => (
                <button key={item.id} onClick={() => setSelectedId(item.id)} className={`rounded-xl border p-3 text-left transition ${selectedId === item.id ? 'border-amber-400 bg-amber-500/10' : 'border-purple-800 bg-[#0e051a] hover:border-purple-600'}`}>
                  <div className="flex items-start justify-between gap-2">
                    <div className="font-bold text-white">{item.name}</div>
                    <span className={`rounded-full px-2 py-1 text-[10px] font-black ${item.ready ? 'bg-emerald-500/15 text-emerald-300' : 'bg-amber-500/15 text-amber-200'}`}>{item.ready ? 'READY' : 'BLOCKED'}</span>
                  </div>
                  <div className="mt-2 grid grid-cols-2 gap-2 text-xs text-purple-200 sm:grid-cols-4">
                    <div>Stake<strong className="mt-1 block text-white">{money(item.stake)}</strong></div>
                    <div>Real players<strong className="mt-1 block text-white">{item.round.realPlayers}</strong></div>
                    <div>Real cartelas<strong className="mt-1 block text-white">{item.round.realCartelas}</strong></div>
                    <div>Bot cartelas<strong className="mt-1 block text-white">{item.round.bots}</strong></div>
                  </div>
                  {item.blockers.length > 0 && <div className="mt-3 flex items-start gap-2 text-xs text-amber-200"><AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" /><span>{item.blockers.join(' ')}</span></div>}
                </button>
              ))}
              {(data.rooms || []).length === 0 && <p className="text-sm text-purple-300">No rooms were returned by the API.</p>}
            </div>
          </section>

          {room && (
            <section className="rounded-2xl border border-purple-800 bg-[#130723] p-4 sm:p-5">
              <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="text-lg font-black text-white">Bot settings · {room.name}</h2>
                  <p className="mt-1 text-xs text-purple-300">Changes apply only to this room and are recorded in the admin audit log.</p>
                </div>
                <button onClick={() => void save()} disabled={saving || loading} className="inline-flex items-center gap-2 rounded-xl bg-amber-400 px-4 py-2 text-sm font-black text-black hover:bg-amber-300 disabled:opacity-50">
                  <Save className="h-4 w-4" /> {saving ? 'Saving…' : 'Save settings'}
                </button>
              </div>

              <div className="mb-4 flex flex-wrap gap-3">
                <label className="flex items-center gap-2 rounded-xl border border-purple-800 bg-[#0e051a] px-3 py-3 text-sm font-bold">
                  <input type="checkbox" checked={form.automatedPlayersEnabled} onChange={(e) => setField('automatedPlayersEnabled', e.target.checked)} className="accent-amber-400" />
                  Enable automated players
                </label>
                <label className="flex items-center gap-2 rounded-xl border border-purple-800 bg-[#0e051a] px-3 py-3 text-sm font-bold">
                  <input type="checkbox" checked={form.automatedPlayersRiskControlEnabled} onChange={(e) => setField('automatedPlayersRiskControlEnabled', e.target.checked)} className="accent-amber-400" />
                  Risk controls enabled
                </label>
                <label className="flex items-center gap-2 rounded-xl border border-purple-800 bg-[#0e051a] px-3 py-3 text-sm font-bold">
                  <input type="checkbox" checked={form.automatedPlayersManualOverrideEnabled} onChange={(e) => setField('automatedPlayersManualOverrideEnabled', e.target.checked)} className="accent-amber-400" />
                  Allow manual override
                </label>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
                <label><span className={labelClass}>Maximum bot cartelas</span><input className={inputClass} type="number" min="0" max="200" value={form.automatedPlayerCount} onChange={(e) => setField('automatedPlayerCount', Number(e.target.value))} /></label>
                <label><span className={labelClass}>Activate below (real players)</span><input className={inputClass} type="number" min="1" max="200" value={form.automatedPlayersTriggerBelow} onChange={(e) => setField('automatedPlayersTriggerBelow', Number(e.target.value))} /></label>
                <label><span className={labelClass}>Target total participants</span><input className={inputClass} type="number" min="1" max="200" maxLength={3} value={form.automatedPlayersTarget} onChange={(e) => setField('automatedPlayersTarget', Number(e.target.value))} /></label>
                <label><span className={labelClass}>Max stake budget (ETB)</span><input className={inputClass} type="number" min="0" step="0.01" value={form.automatedPlayersMaxStakeBudget} onChange={(e) => setField('automatedPlayersMaxStakeBudget', Number(e.target.value))} /></label>
                <label><span className={labelClass}>Max house exposure (ETB)</span><input className={inputClass} type="number" min="0" step="0.01" value={form.automatedPlayersMaxHouseExposure} onChange={(e) => setField('automatedPlayersMaxHouseExposure', Number(e.target.value))} /></label>
                <label><span className={labelClass}>Bots per real cartela</span><input className={inputClass} type="number" min="1" max="20" value={form.automatedPlayersBotsPerRealCartela} onChange={(e) => setField('automatedPlayersBotsPerRealCartela', Number(e.target.value))} /></label>
                <label><span className={labelClass}>Bot strategy</span><select className={inputClass} value={form.automatedPlayersStrategy} onChange={(e) => setField('automatedPlayersStrategy', e.target.value as BotSettings['automatedPlayersStrategy'])}><option value="conservative">Conservative</option><option value="balanced">Balanced</option><option value="aggressive">Aggressive</option></select></label>
              </div>

              <div className="mt-4 rounded-xl border border-purple-800 bg-[#0e051a] p-3 text-xs leading-relaxed text-purple-200">
                <strong className="text-amber-200">Funding and safety:</strong> settings do not fund the house wallet. Actual bot joins still depend on the live game rules, room stake, wallet balance, budget/exposure limits, and scheduler execution. Bot participants should remain clearly disclosed to players.
              </div>

              <div className="mt-4">
                <h3 className="mb-2 text-sm font-black text-white">Current round diagnostics</h3>
                <div className="grid grid-cols-2 gap-2 text-xs sm:grid-cols-4">
                  <div className="rounded-lg bg-[#0e051a] p-3"><span className="text-purple-300">Phase</span><strong className="mt-1 block text-white">{room.round.phase || 'No round'}</strong></div>
                  <div className="rounded-lg bg-[#0e051a] p-3"><span className="text-purple-300">Timer</span><strong className="mt-1 block text-white">{room.round.timerSeconds}s</strong></div>
                  <div className="rounded-lg bg-[#0e051a] p-3"><span className="text-purple-300">Affordable at current stake</span><strong className="mt-1 block text-white">{room.walletBotsAffordable}</strong></div>
                  <div className="rounded-lg bg-[#0e051a] p-3"><span className="text-purple-300">Desired bots this round</span><strong className="mt-1 block text-white">{room.round.wantedBots}</strong></div>
                </div>
                {room.blockers.length > 0 && <ul className="mt-3 list-disc space-y-1 pl-5 text-sm text-amber-200">{room.blockers.map((blocker, index) => <li key={`${index}-${blocker}`}>{blocker}</li>)}</ul>}
                {room.round.botSeats.length > 0 && <p className="mt-3 break-words text-xs text-purple-300">Bot seats: {room.round.botSeats.join(', ')}</p>}
              </div>
            </section>
          )}
        </>
      )}
    </div>
  );
};
