import React, { useState } from 'react';
import { LockKeyhole, ShieldCheck, Eye, EyeOff } from 'lucide-react';

interface AdminLoginProps { onAuthenticated: () => void; }

export const AdminLogin: React.FC<AdminLoginProps> = ({ onAuthenticated }) => {
  const [email,setEmail]=useState('');
  const [password,setPassword]=useState('');
  const [showPassword,setShowPassword]=useState(false);
  const [error,setError]=useState('');
  const [loading,setLoading]=useState(false);

  const submit=async(e:React.FormEvent)=>{
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const response=await fetch('/api/admin/login',{
        method:'POST',
        credentials:'include',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({email,password})
      });
      const data=await response.json().catch(()=>({}));
      if(!response.ok) throw new Error(data.error || 'Login failed');
      onAuthenticated();
    } catch(err:any) {
      setError(err.message || 'Unable to sign in');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#07020f] text-white flex items-center justify-center p-5">
      <div className="w-full max-w-md">
        <div className="text-center mb-7">
          <div className="mx-auto w-14 h-14 rounded-2xl bg-gradient-to-br from-purple-600 to-indigo-700 border border-purple-400/30 flex items-center justify-center shadow-2xl shadow-purple-950/60">
            <ShieldCheck className="w-7 h-7 text-amber-300" />
          </div>
          <h1 className="mt-4 text-2xl font-black">Ethio Bingo · ኢትዮ ቢንጎ</h1>
          <p className="mt-1 text-sm text-purple-300">የአስተዳደር ማዕከል · Secure Operations Center</p>
        </div>

        <form onSubmit={submit} className="bg-[#120626] border border-purple-800/80 rounded-3xl p-6 shadow-2xl space-y-4">
          <div>
            <label className="block text-xs font-bold text-purple-300 mb-1.5">የአስተዳዳሪ ኢሜይል · Administrator Email</label>
            <input value={email} onChange={e=>setEmail(e.target.value)} type="email" autoComplete="username" required
              className="w-full bg-[#090313] border border-purple-800 rounded-xl px-3.5 py-3 text-sm outline-none focus:border-amber-500" />
          </div>
          <div>
            <label className="block text-xs font-bold text-purple-300 mb-1.5">የይለፍ ቃል · Password</label>
            <div className="relative">
              <input value={password} onChange={e=>setPassword(e.target.value)} type={showPassword?'text':'password'} autoComplete="current-password" required
                className="w-full bg-[#090313] border border-purple-800 rounded-xl px-3.5 py-3 pr-11 text-sm outline-none focus:border-amber-500" />
              <button type="button" onClick={()=>setShowPassword(v=>!v)} className="absolute right-3 top-1/2 -translate-y-1/2 text-purple-400 hover:text-white">
                {showPassword?<EyeOff className="w-4 h-4"/>:<Eye className="w-4 h-4"/>}
              </button>
            </div>
          </div>
          {error && <div className="rounded-xl border border-red-500/30 bg-red-500/10 text-red-300 text-xs px-3 py-2">{error}</div>}
          <button disabled={loading} className="w-full rounded-xl bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-black font-black py-3 text-sm flex items-center justify-center gap-2">
            <LockKeyhole className="w-4 h-4"/>{loading?'በመግባት ላይ…':'ወደ አስተዳደር ግባ · Sign in'}
          </button>
          <p className="text-[10px] text-center text-purple-500">ይህ ለአስተዳዳሪዎች ብቻ የተዘጋጀ መግቢያ ነው። የተጫዋች መግቢያ ከዚህ አይሰጥም።</p>
        </form>
      </div>
    </div>
  );
};
