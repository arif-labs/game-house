import React from 'react';
import { Gift, ShieldCheck } from 'lucide-react';

export const AdminBonuses: React.FC = () => (
  <div className="max-w-3xl space-y-6">
    <div>
      <h2 className="text-lg font-black text-white">Welcome Bonus Policy</h2>
      <p className="text-xs text-purple-300">Only bonuses actually implemented by the backend are listed here.</p>
    </div>
    <div className="rounded-2xl border border-amber-500/30 bg-[#120626] p-5 space-y-3">
      <div className="flex items-center gap-2"><Gift className="h-5 w-5 text-amber-400" /><h3 className="font-extrabold text-white">New-player welcome bonus</h3></div>
      <p className="text-3xl font-black text-amber-300">10 ETB</p>
      <p className="text-sm leading-6 text-purple-200">Credited once to the Play Wallet when a new Telegram account completes its first valid Mini App authentication. Reopening the same account does not grant it again.</p>
      <div className="flex items-start gap-2 rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-3 text-xs text-emerald-200">
        <ShieldCheck className="h-4 w-4 shrink-0" />
        <span>The credit and its ledger entry are created together. Existing accounts are not credited retroactively.</span>
      </div>
    </div>
    <div className="rounded-2xl border border-purple-900 bg-[#120626] p-4 text-sm text-purple-300">
      Promo-code campaigns, usage limits, referral rewards, and bulk bonus grants are not implemented as persistent backend features. They are intentionally not shown as active promotions.
    </div>
  </div>
);
