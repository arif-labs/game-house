import React, { useCallback, useEffect, useState } from 'react';
import { Download, RefreshCw, ShieldAlert } from 'lucide-react';
import { gameStore } from '../../services/gameStore';

type LedgerRow = {
  id: string; timestamp: number; username: string; type: string; walletType: string;
  amount: number; balanceAfter: number; referenceId: string; description: string;
};
type HouseLedgerRow = { id: string; timestamp: number; type: string; amount: number; balanceAfter: number; referenceId: string; description: string };
type FinanceData = {
  summary: {
    approvedDeposits: number; approvedWithdrawals: number; winnerPayouts: number;
    bonusesRecorded: number; manualAdjustmentCount: number; manualAdjustmentTotal: number; netCashFlow: number; recordedHouseRake: number | null;
    houseRakeEntries: number; unledgeredApprovedDeposits: number;
    houseWalletBalance: number; houseProfitLoss: number; houseLedger: HouseLedgerRow[];
  };
  ledger: LedgerRow[];
  deposits: Array<{ id: string; username: string; amount: number; provider: string | null; referenceNo: string; status: string; createdAt: number; reviewedBy?: string | null }>;
  withdrawals: Array<{ id: string; username: string; amount: number; provider: string; accountNumber: string; accountName: string; status: string; createdAt: number; reviewedBy?: string | null }>;
};

const money = (amount: number) => `${amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ETB`;

export const AdminFinance: React.FC = () => {
  const [tab, setTab] = useState<'deposits' | 'withdrawals' | 'ledger'>('deposits');
  const [data, setData] = useState<FinanceData | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [fundAmount, setFundAmount] = useState('');
  const [fundReason, setFundReason] = useState('');
  const [funding, setFunding] = useState(false);

  const reload = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const response = await fetch('/api/admin/finance-summary', { credentials: 'include' });
      const result = await response.json();
      if (!response.ok || result?.ok !== true) throw new Error(result?.error || 'Finance data could not be loaded.');
      setData(result as FinanceData);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Finance data could not be loaded.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void reload(); }, [reload]);

  const approveDeposit = async (id: string) => {
    await gameStore.adminApproveDeposit(id);
    await reload();
  };
  const approveWithdrawal = async (id: string) => {
    await gameStore.adminApproveWithdrawal(id);
    await reload();
  };

  const fundHouseWallet = async (e: React.FormEvent) => {
    e.preventDefault();
    if (funding || Number(fundAmount) < 1 || !fundReason.trim()) return;
    setFunding(true);
    setError('');
    try {
      const response = await fetch('/api/admin/house-wallet/fund', {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: Number(fundAmount), reason: fundReason.trim() }),
      });
      const result = await response.json();
      if (!response.ok || result?.ok !== true) throw new Error(result?.error || 'House wallet funding failed.');
      setFundAmount(''); setFundReason('');
      await reload();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'House wallet funding failed.');
    } finally { setFunding(false); }
  };

  const exportLedger = () => {
    if (!data) return;
    const quote = (value: unknown) => `"${String(value ?? '').replace(/"/g, '""')}"`;
    const rows = [
      ['ID', 'Timestamp', 'User', 'Type', 'Wallet', 'Amount', 'BalanceAfter', 'Reference', 'Description'],
      ...data.ledger.map((l) => [l.id, new Date(l.timestamp).toISOString(), l.username, l.type, l.walletType, l.amount, l.balanceAfter, l.referenceId, l.description])
    ];
    const blob = new Blob([rows.map((r) => r.map(quote).join(',')).join('\r\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `ethio_bingo_ledger_${Date.now()}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-black text-white">Finance & Operations</h2>
          <p className="text-xs text-purple-300">Figures are loaded from approved transactions and the recorded ledger.</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => void reload()} className="px-3 py-2 rounded-xl border border-purple-700 text-purple-200 text-xs font-bold flex items-center gap-1.5"><RefreshCw className="w-4 h-4" /> Refresh</button>
          <button onClick={exportLedger} disabled={!data} className="px-3 py-2 rounded-xl border border-purple-700 text-purple-200 text-xs font-bold flex items-center gap-1.5 disabled:opacity-40"><Download className="w-4 h-4" /> Export ledger</button>
        </div>
      </div>

      {error && <div role="alert" className="rounded-xl border border-red-500/40 bg-red-500/10 p-3 text-sm text-red-200">{error}</div>}
      {loading && !data && <p className="text-sm text-purple-300">Loading verified finance records…</p>}
      {data && <>
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3">
          {[
            ['Approved deposits', data.summary.approvedDeposits],
            ['Approved withdrawals', data.summary.approvedWithdrawals],
            ['Recorded winner payouts', data.summary.winnerPayouts],
            ['Net cash flow (deposits − withdrawals)', data.summary.netCashFlow],
            ['House wallet balance', data.summary.houseWalletBalance],
            ['House net result (rake + bot outcomes)', data.summary.houseProfitLoss]
          ].map(([label, value]) => (
            <div key={String(label)} className="rounded-2xl border border-purple-900 bg-[#120626] p-4">
              <span className="block text-xs text-purple-300">{label}</span>
              <strong className="mt-2 block text-xl text-white">{money(Number(value))}</strong>
            </div>
          ))}
        </div>

        <div className="rounded-xl border border-purple-900 bg-[#120626] p-4 space-y-2">
          <div className="flex items-center justify-between gap-3">
            <h3 className="font-bold text-white">Reconciliation checks</h3>
            <span className="text-xs text-purple-300">No assumed or sample totals</span>
          </div>
          <p className="text-sm text-purple-200">Recorded house rake: <strong className="text-white">{data.summary.recordedHouseRake === null ? 'Not recorded in the ledger' : money(data.summary.recordedHouseRake)}</strong></p>
          <p className="text-sm text-purple-200">Welcome/other bonuses recorded: <strong className="text-white">{money(data.summary.bonusesRecorded)}</strong></p>
          {data.summary.manualAdjustmentCount > 0 && (
            <div className="flex items-start gap-2 rounded-lg border border-amber-500/40 bg-amber-500/10 p-3 text-sm text-amber-100">
              <ShieldAlert className="w-5 h-5 shrink-0" />
              <span>{data.summary.manualAdjustmentCount} manual wallet adjustment(s), net {money(data.summary.manualAdjustmentTotal)}. These adjustments are not counted as external deposits or cash flow; reconcile their supporting records before treating them as money received.</span>
            </div>
          )}
          {data.summary.unledgeredApprovedDeposits > 0 && (
            <div className="flex items-start gap-2 rounded-lg border border-amber-500/40 bg-amber-500/10 p-3 text-sm text-amber-100">
              <ShieldAlert className="w-5 h-5 shrink-0" />
              <span>{data.summary.unledgeredApprovedDeposits} approved deposit record(s) have no matching DEPOSIT ledger entry. Historical figures are not being silently backfilled.</span>
            </div>
          )}
          {data.summary.unledgeredApprovedDeposits === 0 && data.ledger.length === 0 && (
            <p className="text-sm text-purple-300">No ledger transactions are recorded yet. No balance-integrity claim can be made until transactions exist.</p>
          )}
        </div>

        <form onSubmit={fundHouseWallet} className="rounded-xl border border-purple-900 bg-[#120626] p-4 space-y-3">
          <div><h3 className="font-bold text-white">House wallet reserve</h3><p className="text-xs text-purple-300 mt-1">Fund the house reserve from real business capital before enabling automated participants. Funding is audited and is not counted as profit.</p></div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <input type="number" min="1" step="0.01" required value={fundAmount} onChange={(e) => setFundAmount(e.target.value)} placeholder="Amount (ETB)" className="bg-[#0d051a] border border-purple-800 rounded-xl px-3 py-2 text-sm text-white" />
            <input type="text" minLength={3} maxLength={200} required value={fundReason} onChange={(e) => setFundReason(e.target.value)} placeholder="Funding source / reason" className="bg-[#0d051a] border border-purple-800 rounded-xl px-3 py-2 text-sm text-white" />
            <button type="submit" disabled={funding} className="rounded-xl bg-amber-500 px-4 py-2 text-xs font-extrabold text-black disabled:opacity-50">{funding ? 'Recording…' : 'Record funding'}</button>
          </div>
        </form>

        <div className="overflow-x-auto rounded-2xl border border-purple-900 bg-[#120626]">
          <div className="p-4 font-bold text-white">House wallet ledger</div>
          <table className="w-full text-left text-xs text-purple-200">
            <thead className="bg-[#1a0a34] text-purple-300"><tr>{['Timestamp', 'Type', 'Amount', 'Balance after', 'Reference', 'Description'].map((h) => <th key={h} className="p-3">{h}</th>)}</tr></thead>
            <tbody className="divide-y divide-purple-900/60">
              {data.summary.houseLedger.map((entry) => <tr key={entry.id}><td className="p-3">{new Date(entry.timestamp).toLocaleString()}</td><td className="p-3">{entry.type}</td><td className="p-3">{money(entry.amount)}</td><td className="p-3">{money(entry.balanceAfter)}</td><td className="p-3 font-mono">{entry.referenceId}</td><td className="p-3">{entry.description}</td></tr>)}
              {data.summary.houseLedger.length === 0 && <tr><td colSpan={6} className="p-6 text-center text-purple-400">No house-wallet transactions recorded.</td></tr>}
            </tbody>
          </table>
        </div>

        <div className="flex flex-wrap gap-2 border-b border-purple-900 pb-2 text-xs font-bold">
          {(['deposits', 'withdrawals', 'ledger'] as const).map((name) => (
            <button key={name} onClick={() => setTab(name)} className={`px-4 py-2 rounded-xl ${tab === name ? 'bg-amber-500 text-black' : 'text-purple-300 hover:bg-[#180a30]'}`}>
              {name === 'deposits' ? `Deposit requests (${data.deposits.filter((d) => d.status === 'pending').length} pending)` : name === 'withdrawals' ? `Withdrawal requests (${data.withdrawals.filter((w) => w.status === 'pending').length} pending)` : `Ledger (${data.ledger.length} latest records)`}
            </button>
          ))}
        </div>

        {tab === 'deposits' && <div className="overflow-x-auto rounded-2xl border border-purple-900 bg-[#120626]">
          <table className="w-full text-left text-xs text-purple-200">
            <thead className="bg-[#1a0a34] text-purple-300"><tr>{['ID', 'Player', 'Provider', 'Amount', 'Reference', 'Status', 'Action'].map((h) => <th key={h} className="p-3">{h}</th>)}</tr></thead>
            <tbody className="divide-y divide-purple-900/60">
              {data.deposits.map((d) => <tr key={d.id}>
                <td className="p-3 font-mono">{d.id}</td><td className="p-3 font-bold text-white">{d.username}</td><td className="p-3">{d.provider || '—'}</td><td className="p-3">{money(d.amount)}</td><td className="p-3 font-mono">{d.referenceNo}</td><td className="p-3">{d.status}</td>
                <td className="p-3">{d.status === 'pending' ? <button onClick={() => void approveDeposit(d.id)} className="rounded-lg bg-emerald-600 px-3 py-1.5 font-bold text-white">Approve</button> : (d.reviewedBy || 'Reviewed')}</td>
              </tr>)}
              {data.deposits.length === 0 && <tr><td colSpan={7} className="p-6 text-center text-purple-400">No deposit requests recorded.</td></tr>}
            </tbody>
          </table>
        </div>}

        {tab === 'withdrawals' && <div className="overflow-x-auto rounded-2xl border border-purple-900 bg-[#120626]">
          <table className="w-full text-left text-xs text-purple-200">
            <thead className="bg-[#1a0a34] text-purple-300"><tr>{['ID', 'Player', 'Provider', 'Destination', 'Amount', 'Status', 'Action'].map((h) => <th key={h} className="p-3">{h}</th>)}</tr></thead>
            <tbody className="divide-y divide-purple-900/60">
              {data.withdrawals.map((w) => <tr key={w.id}>
                <td className="p-3 font-mono">{w.id}</td><td className="p-3 font-bold text-white">{w.username}</td><td className="p-3">{w.provider}</td><td className="p-3"><span className="block">{w.accountNumber}</span><span className="text-purple-400">{w.accountName}</span></td><td className="p-3">{money(w.amount)}</td><td className="p-3">{w.status}</td>
                <td className="p-3">{w.status === 'pending' ? <button onClick={() => void approveWithdrawal(w.id)} className="rounded-lg bg-emerald-600 px-3 py-1.5 font-bold text-white">Mark paid / approve</button> : (w.reviewedBy || 'Reviewed')}</td>
              </tr>)}
              {data.withdrawals.length === 0 && <tr><td colSpan={7} className="p-6 text-center text-purple-400">No withdrawal requests recorded.</td></tr>}
            </tbody>
          </table>
        </div>}

        {tab === 'ledger' && <div className="overflow-x-auto rounded-2xl border border-purple-900 bg-[#120626]">
          <table className="w-full text-left text-xs text-purple-200">
            <thead className="bg-[#1a0a34] text-purple-300"><tr>{['Timestamp', 'Player', 'Type', 'Wallet', 'Amount', 'Balance after', 'Reference'].map((h) => <th key={h} className="p-3">{h}</th>)}</tr></thead>
            <tbody className="divide-y divide-purple-900/60">
              {data.ledger.map((l) => <tr key={l.id}><td className="p-3">{new Date(l.timestamp).toLocaleString()}</td><td className="p-3">{l.username}</td><td className="p-3">{l.type}</td><td className="p-3">{l.walletType}</td><td className="p-3">{money(l.amount)}</td><td className="p-3">{money(l.balanceAfter)}</td><td className="p-3 font-mono">{l.referenceId}</td></tr>)}
              {data.ledger.length === 0 && <tr><td colSpan={7} className="p-6 text-center text-purple-400">No ledger transactions recorded.</td></tr>}
            </tbody>
          </table>
        </div>}
      </>}
    </div>
  );
};
