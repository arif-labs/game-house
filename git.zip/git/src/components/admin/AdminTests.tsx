import React, { useState, useEffect } from 'react';
import { TestTube, Play, CheckCircle2, XCircle, Clock, ShieldCheck } from 'lucide-react';
import { runEngineTestSuite, TestResult } from '../../tests/engineTests';

export const AdminTests: React.FC = () => {
  const [results, setResults] = useState<TestResult[]>([]);
  const [isRunning, setIsRunning] = useState(false);

  const runTests = async () => {
    setIsRunning(true);
    const res = await runEngineTestSuite();
    setResults(res);
    setIsRunning(false);
  };

  useEffect(() => {
    runTests();
  }, []);

  const allPassed = results.length > 0 && results.every((r) => r.passed);

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-black text-white">Engine Unit & Integration Test Suite</h2>
          <p className="text-xs text-purple-300">
            Verify deterministic cartela generator, 75-ball winning patterns, CSPRNG seed commitment, and ledger math
          </p>
        </div>

        <button
          onClick={runTests}
          disabled={isRunning}
          className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-extrabold text-xs shadow-md flex items-center space-x-1.5 active:scale-95 transition-all"
        >
          <Play className="w-3.5 h-3.5" />
          <span>{isRunning ? 'Running Tests...' : 'Re-Run All Tests'}</span>
        </button>
      </div>

      {/* Summary Banner */}
      <div
        className={`p-4 rounded-2xl border flex items-center justify-between ${
          allPassed
            ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300'
            : 'bg-amber-500/10 border-amber-500/40 text-amber-300'
        }`}
      >
        <div className="flex items-center space-x-3">
          <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-extrabold text-sm text-white">
              {allPassed ? 'ALL TEST SUITES PASSING (100%)' : results.length > 0 ? 'ONE OR MORE TESTS FAILED' : 'TESTS RUNNING / PENDING'}
            </h3>
            <span className="text-xs text-purple-300">
              {results.filter((r) => r.passed).length} of {results.length} assertions verified
            </span>
          </div>
        </div>

        <span className={`text-xs font-mono font-bold px-3 py-1 rounded-full border ${allPassed ? 'bg-emerald-500/20 border-emerald-500/30 text-emerald-300' : results.length > 0 ? 'bg-red-500/20 border-red-500/30 text-red-300' : 'bg-amber-500/20 border-amber-500/30 text-amber-300'}`}>
          {allPassed ? 'PASSED' : results.length > 0 ? 'FAILED' : 'PENDING'}
        </span>
      </div>

      {/* Tests Results List */}
      <div className="space-y-3">
        {results.map((res, i) => (
          <div
            key={i}
            className="p-4 bg-[#120626] border border-purple-900/80 rounded-2xl flex items-start justify-between shadow-md"
          >
            <div className="flex items-start space-x-3">
              <div className="mt-0.5">
                {res.passed ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                ) : (
                  <XCircle className="w-5 h-5 text-red-400" />
                )}
              </div>
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <span className="font-black text-sm text-white">{res.name}</span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-900/60 text-purple-300 font-mono">
                    {res.category}
                  </span>
                </div>
                <p className="text-xs text-purple-300">{res.message}</p>
              </div>
            </div>

            <div className="text-right shrink-0">
              <span className="text-[10px] font-mono text-purple-400 flex items-center justify-end">
                <Clock className="w-3 h-3 mr-1" />
                {res.durationMs}ms
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
