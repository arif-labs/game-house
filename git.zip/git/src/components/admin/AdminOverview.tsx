import React, { useEffect, useState } from 'react';
import { Users, Coins, TrendingUp, Trophy, Radio, RefreshCw } from 'lucide-react';
import { gameStore } from '../../services/gameStore';

export const AdminOverview: React.FC = () => {
  const [, setTick] = useState(0);
  useEffect(() => gameStore.subscribe(() => setTick((n) => n + 1)), []);
  const rooms = gameStore.rooms;
  const activeRooms = rooms.filter((room) => room.status === 'active');
  const roundStatesLoaded = activeRooms.every((room) => Boolean(gameStore.roundStates[room.id]));
  const playersInRounds = activeRooms.reduce((sum, room) => sum + (gameStore.roundStates[room.id]?.playersCount ?? 0), 0);
  const activePrizePools = activeRooms.reduce((sum, room) => sum + (gameStore.roundStates[room.id]?.derashPrize ?? 0), 0);
  const estimatedRake = activeRooms.reduce((sum, room) => sum + (gameStore.roundStates[room.id]?.rakeEarned ?? 0), 0);

  return <div className="space-y-6">
    <div className="flex items-center justify-between gap-3">
      <div><h2 className="text-lg font-black text-white">Operations Overview</h2><p className="text-xs text-purple-300">Live figures from current server room states.</p></div>
      <button onClick={() => void gameStore.refreshAdminState()} className="px-3 py-2 rounded-xl border border-purple-700 text-purple-200 text-xs font-bold flex items-center gap-1.5"><RefreshCw className="w-4 h-4" /> Refresh</button>
    </div>

    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3">
      {[
        { label: 'Players in current rounds', value: roundStatesLoaded ? String(playersInRounds) : '—', icon: Users },
        { label: 'Active rooms', value: String(activeRooms.length), icon: Radio },
        { label: 'Current prize pools', value: roundStatesLoaded ? `${activePrizePools.toLocaleString(undefined, { maximumFractionDigits: 2 })} ETB` : '—', icon: Trophy },
        { label: 'Estimated rake in current rounds', value: roundStatesLoaded ? `${estimatedRake.toLocaleString(undefined, { maximumFractionDigits: 2 })} ETB` : '—', icon: TrendingUp }
      ].map((item) => <div key={item.label} className="rounded-2xl border border-purple-900 bg-[#140828] p-4">
        <div className="flex items-center justify-between gap-3"><span className="text-xs font-bold text-purple-300">{item.label}</span><item.icon className="h-4 w-4 text-amber-400" /></div>
        <strong className="mt-3 block text-2xl font-black text-white">{item.value}</strong>
      </div>)}
    </div>

    <div className="rounded-2xl border border-purple-900 bg-[#120626] overflow-hidden">
      <div className="flex items-center gap-2 border-b border-purple-900 p-4"><Coins className="h-5 w-5 text-amber-400" /><h3 className="font-extrabold text-white">Current Room State</h3></div>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs text-purple-200">
          <thead className="bg-[#1a0a34] text-purple-300"><tr>{['Room', 'Stake', 'Phase', 'Round code', 'Players in round', 'Prize pool', 'Called balls'].map((h) => <th key={h} className="p-3">{h}</th>)}</tr></thead>
          <tbody className="divide-y divide-purple-900/60">
            {rooms.map((room) => {
              const round = gameStore.roundStates[room.id];
              return <tr key={room.id}>
                <td className="p-3 font-bold text-white">{room.name}</td>
                <td className="p-3">{room.stake} ETB</td>
                <td className="p-3">{round?.phase ?? 'No state loaded'}</td>
                <td className="p-3 font-mono">{round?.roundCode ?? '—'}</td>
                <td className="p-3">{round ? round.playersCount : '—'}</td>
                <td className="p-3">{round ? `${round.derashPrize.toLocaleString()} ETB` : '—'}</td>
                <td className="p-3">{round ? `${round.ballsDrawn.length} / 75` : '—'}</td>
              </tr>;
            })}
            {rooms.length === 0 && <tr><td colSpan={7} className="p-6 text-center text-purple-400">No room data loaded from the server.</td></tr>}
          </tbody>
        </table>
      </div>
      <p className="border-t border-purple-900 p-3 text-[11px] text-purple-400">Estimated rake is the configured calculation for current rounds, not realized revenue. Historical hourly analytics are not stored by the current backend.</p>
    </div>
  </div>;
};
