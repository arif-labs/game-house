import React, { useState } from 'react';
import {
  Radio,
  Play,
  Pause,
  Clock,
  RotateCcw,
  StopCircle,
  FileText,
  Send,
  AlertTriangle,
  Eye,
  CheckCircle2,
  X
} from 'lucide-react';
import { gameStore } from '../../services/gameStore';
import { DrawnBall } from '../../types/bingo';

export const AdminLiveRounds: React.FC = () => {
  const rooms = gameStore.rooms;
  const [selectedRoomForLog, setSelectedRoomForLog] = useState<string | null>(null);
  const [broadcastRoomId, setBroadcastRoomId] = useState<string | null>(null);
  const [broadcastMsg, setBroadcastMsg] = useState('');
  const [actionReason, setActionReason] = useState('Standard operator management');

  const handlePauseResume = (roomId: string) => {
    gameStore.adminPauseRound(roomId, actionReason);
  };

  const handleExtendTimer = (roomId: string, seconds: number) => {
    gameStore.adminExtendSelectionTimer(roomId, seconds, actionReason);
  };

  const handleCancelAndRefund = (roomId: string) => {
    const reason = prompt('Enter mandatory reason for emergency cancellation and refunds:', 'Network lag spike reported by players');
    if (reason) {
      gameStore.adminCancelAndRefundRound(roomId, reason);
    }
  };

  const handleForceEnd = (roomId: string) => {
    if (confirm('Force end this round and evaluate current drawn balls?')) {
      alert('Force-end is not supported by the server. No round was changed.');
    }
  };

  const selectedRound = selectedRoomForLog ? gameStore.roundStates[selectedRoomForLog] : null;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-black text-white">Live Rounds Operations</h2>
          <p className="text-xs text-purple-300">
            Control active rooms, inspect CSPRNG draw sequences, extend timers, or trigger emergency refunds
          </p>
        </div>
      </div>

      {/* Rounds Table */}
      <div className="bg-[#120626] border border-purple-900/80 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-purple-200">
            <thead className="bg-[#1a0a34] text-purple-300 uppercase text-[10px] font-extrabold border-b border-purple-800">
              <tr>
                <th className="p-3.5">Room & Code</th>
                <th className="p-3.5">Stake</th>
                <th className="p-3.5">Phase</th>
                <th className="p-3.5">Players</th>
                <th className="p-3.5">Derash Pool</th>
                <th className="p-3.5">Drawn Balls</th>
                <th className="p-3.5">Timer</th>
                <th className="p-3.5 text-right">Emergency Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-purple-900/60 font-medium">
              {rooms.map((room) => {
                const round = gameStore.roundStates[room.id];
                const phase = round?.phase ?? 'UNKNOWN';
                const isPaused = room.status === 'paused';

                return (
                  <tr key={room.id} className="hover:bg-[#180b32] transition-colors">
                    <td className="p-3.5">
                      <div className="font-black text-white text-sm">{room.name}</div>
                      <span className="font-mono text-[10px] text-amber-400">
                        {round?.roundCode || 'No round loaded'}
                      </span>
                    </td>
                    <td className="p-3.5 font-bold text-white">{room.stake} ETB</td>
                    <td className="p-3.5">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase ${
                          phase === 'DRAWING'
                            ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 animate-pulse'
                            : phase === 'SELECTION'
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            : 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                        }`}
                      >
                        {phase} {isPaused && '(PAUSED)'}
                      </span>
                    </td>
                    <td className="p-3.5 font-bold text-white">{round ? round.playersCount : '—'}</td>
                    <td className="p-3.5 font-black text-amber-300">
                      {round ? `${round.derashPrize.toFixed(0)} ETB` : '—'}
                    </td>
                    <td className="p-3.5">
                      <span className="font-bold text-white">
                        {round ? `${round.ballsDrawn.length} / 75` : '—'}
                      </span>
                    </td>
                    <td className="p-3.5 font-mono text-amber-400 font-bold">
                      {round ? `${round.timerSeconds}s` : '—'}
                    </td>
                    <td className="p-3.5 text-right">
                      <div className="flex items-center justify-end space-x-1.5">
                        {/* Pause / Resume */}
                        <button
                          onClick={() => handlePauseResume(room.id)}
                          className={`p-1.5 rounded-lg border text-xs font-bold transition-colors ${
                            isPaused
                              ? 'bg-emerald-600/30 text-emerald-300 border-emerald-500'
                              : 'bg-purple-900/40 text-purple-200 border-purple-700 hover:bg-purple-800'
                          }`}
                          title={isPaused ? 'Resume Room' : 'Pause Room'}
                        >
                          {isPaused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
                        </button>

                        {/* Extend timer (+15s) */}
                        <button
                          onClick={() => handleExtendTimer(room.id, 15)}
                          className="px-2 py-1 rounded-lg bg-purple-900/40 hover:bg-purple-800 text-purple-200 border border-purple-700 font-bold text-[10px]"
                          title="Extend Selection (+15s)"
                        >
                          +15s
                        </button>

                        {/* View Draw Log */}
                        <button
                          onClick={() => setSelectedRoomForLog(room.id)}
                          className="p-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40"
                          title="View Draw Log"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>

                        {/* Cancel & Refund */}
                        <button
                          onClick={() => handleCancelAndRefund(room.id)}
                          className="px-2 py-1 rounded-lg bg-red-600/30 hover:bg-red-600/50 text-red-200 border border-red-500/40 font-bold text-[10px]"
                          title="Emergency Cancel & Refund Stakes"
                        >
                          Refund
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Draw Log Inspector Modal */}
      {selectedRound && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#1b0c34] border border-purple-700 rounded-2xl p-5 max-w-lg w-full shadow-2xl space-y-4 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between pb-2 border-b border-purple-800">
              <div>
                <h3 className="font-extrabold text-white text-base">
                  Draw Sequence Log: {selectedRound.roundCode}
                </h3>
                <span className="text-xs text-purple-300 font-mono">
                  SHA-256: {selectedRound.seedCommitment.substring(0, 24)}...
                </span>
              </div>
              <button
                onClick={() => setSelectedRoomForLog(null)}
                className="p-1 rounded-full bg-purple-900 text-purple-300 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-2 text-xs">
              <div className="grid grid-cols-5 gap-2">
                {selectedRound.ballsDrawn.map((b, idx) => (
                  <div
                    key={idx}
                    className="p-2 rounded-xl bg-[#120624] border border-purple-800 text-center"
                  >
                    <span className="text-[9px] text-purple-400 block font-bold">#{b.seq}</span>
                    <span className="text-sm font-black text-amber-300">{b.letter}-{b.number}</span>
                  </div>
                ))}
              </div>

              {selectedRound.ballsDrawn.length === 0 && (
                <div className="text-center p-8 text-purple-400">
                  Draw has not yet commenced for this round.
                </div>
              )}
            </div>

            <div className="pt-2 border-t border-purple-800 text-right">
              <button
                onClick={() => setSelectedRoomForLog(null)}
                className="px-4 py-2 rounded-xl bg-purple-900 text-white font-bold text-xs"
              >
                Close Log
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
