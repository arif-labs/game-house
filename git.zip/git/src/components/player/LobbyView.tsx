import React from 'react';
import { Users, Coins, Trophy, ChevronRight, Clock, Award } from 'lucide-react';
import { gameStore } from '../../services/gameStore';
import { RoomConfig } from '../../types/bingo';

interface LobbyViewProps {
  onSelectRoom: (roomId: string) => void;
  onOpenRules: () => void;
}

export const LobbyView: React.FC<LobbyViewProps> = ({ onSelectRoom, onOpenRules }) => {
  const rooms = gameStore.rooms;
  const lang = gameStore.language;

  return (
    <div className="p-3.5 space-y-4 pb-24">
      {/* Room Tiers Header */}
      <div className="flex items-center justify-between px-1">
        <h3 className="text-sm font-bold text-white flex items-center space-x-1.5">
          <Coins className="w-4 h-4 text-amber-400" />
          <span>{lang === 'am' ? 'የውርርድ ክፍሎች' : 'Stake Rooms'}</span>
        </h3>
        <span className="text-[11px] text-purple-300">
          {rooms.length} {lang === 'am' ? 'ክፍሎች ክፍት ናቸው' : 'Rooms Active'}
        </span>
      </div>

      {rooms.length === 0 && (
        <div role="status" className="rounded-xl border border-amber-500/40 bg-amber-500/10 p-3 text-xs leading-5 text-amber-200">
          {gameStore.authoritySyncError
            ? `Could not load rooms: ${gameStore.authoritySyncError}`
            : (lang === 'am' ? 'ክፍሎችን ከሰርቨር በመጫን ላይ…' : 'Waiting for room data from the server…')}
        </div>
      )}

      {/* Rooms Grid */}
      <div className="grid grid-cols-1 gap-3">
        {rooms.map((room) => {
          const round = gameStore.roundStates[room.id];
          const phase = round?.phase ?? 'UNKNOWN';
          const playersCount = round ? round.playersCount : null;
          const derash = round ? round.derashPrize : null;
          const timer = round?.timerSeconds ?? 0;

          const isDrawing = phase === 'DRAWING';
          const isSelection = phase === 'SELECTION';

          return (
            <div
              key={room.id}
              onClick={() => onSelectRoom(room.id)}
              className="group relative cursor-pointer overflow-hidden rounded-xl bg-[#1b0d33] border border-[#341b5e] hover:border-amber-500/50 transition-all duration-200 p-3.5 shadow-md active:scale-[0.99]"
            >
              {/* Highlight ribbon for VIP */}
              {room.isVip && (
                <div className="absolute top-0 right-0 bg-gradient-to-l from-amber-500 to-amber-600 text-black text-[9px] font-black uppercase px-2.5 py-0.5 rounded-bl-lg tracking-wider">
                  {lang === 'am' ? 'ቪአይፒ ክፍል' : 'VIP ROOM'}
                </div>
              )}

              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <h4 className="font-extrabold text-white text-base group-hover:text-amber-300 transition-colors">
                      {lang === 'am' ? room.amharicName : room.name}
                    </h4>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      {room.stake} ETB
                    </span>
                  </div>

                  <div className="flex items-center space-x-3 text-xs text-purple-200/80">
                    <span className="flex items-center">
                      <Users className="w-3.5 h-3.5 mr-1 text-purple-400" />
                      {playersCount === null ? '—' : playersCount} {lang === 'am' ? 'ተጫዋቾች' : 'players'}
                    </span>
                    <span className="flex items-center">
                      <Trophy className="w-3.5 h-3.5 mr-1 text-amber-400" />
                      <strong className="text-amber-300 ml-0.5 font-bold">
                        {derash === null ? '—' : `${derash.toFixed(0)} ETB`}
                      </strong>{' '}
                      <span className="text-[10px] ml-1 text-purple-400">
                        {lang === 'am' ? 'ደራሽ' : 'Derash'}
                      </span>
                    </span>
                  </div>
                </div>

                {/* Status Indicator & Action */}
                <div className="flex flex-col items-end space-y-1.5">
                  <div
                    className={`flex items-center space-x-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      isSelection
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : isDrawing
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30 animate-pulse'
                        : 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                    }`}
                  >
                    <Clock className="w-3 h-3" />
                    <span>
                      {!round
                        ? (lang === 'am' ? 'የዙር መረጃ በመጫን ላይ' : 'Loading round data')
                        : isSelection
                        ? `${round.timerSeconds}s ${lang === 'am' ? 'ቀሪ' : 'left'}`
                        : isDrawing
                        ? `${lang === 'am' ? 'እየወጣ ነው' : 'Drawing'} (${round.ballsDrawn.length})`
                        : `${lang === 'am' ? 'በመዘጋጀት ላይ' : 'Starting'}`}
                    </span>
                  </div>

                  <button className="flex items-center text-xs font-bold text-amber-400 group-hover:translate-x-1 transition-transform">
                    <span>{lang === 'am' ? 'ግባ' : 'Enter'}</span>
                    <ChevronRight className="w-4 h-4 ml-0.5" />
                  </button>
                </div>
              </div>

              {/* Progress indicator bar at bottom */}
              <div className="mt-3 w-full bg-[#120724] h-1.5 rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all duration-500 ${
                    isDrawing ? 'bg-amber-500' : 'bg-gradient-to-r from-purple-500 to-amber-400'
                  }`}
                  style={{
                    width: !round
                      ? '0%'
                      : isSelection
                      ? `${Math.max(5, (timer / room.selectionDuration) * 100)}%`
                      : isDrawing
                      ? `${Math.min(100, (round.ballsDrawn.length / 75) * 100)}%`
                      : '100%'
                  }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
