import React, { useState } from 'react';
import {
  Volume2,
  VolumeX,
  RefreshCw,
  LogOut,
  Star,
  Trophy,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Flame,
  LayoutGrid,
  FileSpreadsheet
} from 'lucide-react';
import { gameStore } from '../../services/gameStore';
import {
  getLetterColorClass,
  getCartelaById,
  checkCardWinningPatterns,
  calculateNumbersToGo
} from '../../engine/bingoEngine';
import { DrawnBall, CartelaCard } from '../../types/bingo';
import { audioCaller } from '../../engine/audioCaller';

interface DrawingViewProps {
  roomId: string;
  onLeaveRoom: () => void;
  onResync: () => void;
  onOpenProvablyFair: () => void;
}

export const DrawingView: React.FC<DrawingViewProps> = ({
  roomId,
  onLeaveRoom,
  onResync,
  onOpenProvablyFair
}) => {
  const room = gameStore.rooms.find((r) => r.id === roomId) || gameStore.rooms[0];
  const round = gameStore.roundStates[roomId];
  const reservations = gameStore.cartelaReservations[roomId] || [];
  const lang = gameStore.language;

  // Manual marking state if user toggles off autoMode
  const [manualMarks, setManualMarks] = useState<Set<number>>(new Set());
  const [activeTab, setActiveTab] = useState<'card' | 'master'>('card');
  const [claimFeedback, setClaimFeedback] = useState<{ text: string; error?: boolean } | null>(null);

  // My cartela
  const myReservation = reservations.find(
    (r) => r.userId === gameStore.player.id && r.status === 'confirmed'
  );
  const myCard: CartelaCard | null = myReservation ? getCartelaById(myReservation.cartelaId) : null;

  // Called numbers set
  const calledNumbers = (round?.ballsDrawn || []).map((b) => b.number);
  const calledSet = new Set(calledNumbers);

  // My card numbers set for master board cross-reference
  const myCardNumbers = React.useMemo(() => {
    if (!myCard) return new Set<number>();
    const nums = new Set<number>();
    myCard.matrix.forEach((row) => {
      row.forEach((v) => {
        if (v > 0) nums.add(v);
      });
    });
    return nums;
  }, [myCard]);

  // Win patterns & numbers-to-go
  const myWinningCheck = reservations
    .filter((r) => r.userId === gameStore.player.id && r.status === 'confirmed')
    .map((reservation) => {
      const card = getCartelaById(reservation.cartelaId);
      if (!card) return null;
      const check = checkCardWinningPatterns(card.matrix, calledNumbers, room.enabledPatterns);
      return check.hasWon ? check : null;
    })
    .find((check) => check !== null) ?? null;

  const winCheck = myWinningCheck ?? (myCard
    ? checkCardWinningPatterns(myCard.matrix, calledNumbers, room.enabledPatterns)
    : { hasWon: false, winningPatterns: [] });

  const numbersToGo = myCard
    ? calculateNumbersToGo(myCard.matrix, calledNumbers, room.enabledPatterns)
    : 25;

  const handleCellClick = (num: number) => {
    if (num === 0) return;
    if (gameStore.autoMode) return; // in auto mode, machine marks
    setManualMarks((prev) => {
      const next = new Set(prev);
      if (next.has(num)) next.delete(num);
      else next.add(num);
      return next;
    });
  };

  const isCellMarked = (num: number) => {
    if (num === 0) return true; // Center Star always marked
    if (gameStore.autoMode) {
      return calledSet.has(num);
    }
    return manualMarks.has(num);
  };

  const handleClaimBingo = async () => {
    const res = await gameStore.claimBingo(roomId);
    if (res.success) {
      setClaimFeedback({ text: res.message });
    } else {
      setClaimFeedback({ text: res.message, error: true });
      setTimeout(() => setClaimFeedback(null), 4000);
    }
  };

  const currentBall: DrawnBall | null = round?.currentBall || null;
  const previousBalls: DrawnBall[] = round?.previousBalls?.slice(0, 6) || [];

  return (
    <div className="flex flex-col h-[calc(100vh-62px)] max-h-screen bg-[#0a0316] text-white">
      {/* 1. Stat Strip: Game ID, Players, Bet, Derash (Prize), Called Count */}
      <div className="bg-[#17092e] border-b border-[#2e1554] px-2.5 py-1.5 grid grid-cols-5 gap-1 text-center text-xs">
        <div className="bg-[#110524] rounded-lg p-1 border border-purple-900/60">
          <span className="text-[9px] uppercase text-purple-300 block">
            {lang === 'am' ? 'ጨዋታ መለያ' : 'Game ID'}
          </span>
          <span className="font-extrabold text-white text-[11px] truncate block">
            {round?.roundCode || '—'}
          </span>
        </div>

        <div className="bg-[#110524] rounded-lg p-1 border border-purple-900/60">
          <span className="text-[9px] uppercase text-purple-300 block">
            {lang === 'am' ? 'ተጫዋቾች' : 'Players'}
          </span>
          <span className="font-extrabold text-purple-200 text-[11px]">
            {round ? round.playersCount : '—'}
          </span>
        </div>

        <div className="bg-[#110524] rounded-lg p-1 border border-purple-900/60">
          <span className="text-[9px] uppercase text-purple-300 block">
            {lang === 'am' ? 'መደብ' : 'Bet'}
          </span>
          <span className="font-extrabold text-purple-200 text-[11px]">
            {room.stake} ETB
          </span>
        </div>

        <div className="bg-[#110524] rounded-lg p-1 border border-amber-500/40 bg-amber-500/5">
          <span className="text-[9px] uppercase text-amber-300 font-bold block flex items-center justify-center">
            <Trophy className="w-2.5 h-2.5 mr-0.5 text-amber-400" />
            {lang === 'am' ? 'ደራሽ' : 'Derash'}
          </span>
          <span className="font-black text-amber-300 text-[11px]">
            {round ? round.derashPrize.toFixed(0) : '—'} <span className="text-[8px] font-normal">{round ? 'ETB' : ''}</span>
          </span>
        </div>

        <div className="bg-[#110524] rounded-lg p-1 border border-purple-900/60">
          <span className="text-[9px] uppercase text-purple-300 block">
            {lang === 'am' ? 'የወጡ' : 'Called'}
          </span>
          <span className="font-extrabold text-amber-400 text-[11px]">
            {round ? `${round.ballsDrawn.length}/75` : '—'}
          </span>
        </div>
      </div>

      {room.automatedPlayersEnabled && (
        <div className="px-3 py-1.5 bg-amber-500/10 border-b border-amber-500/30 text-[10px] text-amber-100 flex items-center justify-between gap-2">
          <span>House-controlled automated participants may join this room; they are identified as BOT. {reservations.filter((r) => r.isBot && r.status === 'confirmed').length > 0 && <>Names: {reservations.filter((r) => r.isBot && r.status === 'confirmed').map((r) => r.username).join(', ')}</>}</span>
          <strong className="whitespace-nowrap">Bots: {reservations.filter((r) => r.isBot && r.status === 'confirmed').length}</strong>
        </div>
      )}

      {/* 2. Ball Call Display Area */}
      <div className="bg-[#120626] border-b border-[#29134d] px-3 py-2">
        <div className="flex items-center justify-between">
          {/* Main Large Circular Ball Display */}
          <div className="flex items-center space-x-3">
            {currentBall ? (
              <div className="relative group">
                <div
                  className={`w-16 h-16 rounded-full flex flex-col items-center justify-center shadow-xl border-2 animate-ball-pop ${
                    currentBall.letter === 'B'
                      ? 'bg-gradient-to-tr from-blue-700 to-blue-500 border-blue-300 shadow-blue-500/40'
                      : currentBall.letter === 'I'
                      ? 'bg-gradient-to-tr from-indigo-700 to-indigo-500 border-indigo-300 shadow-indigo-500/40'
                      : currentBall.letter === 'N'
                      ? 'bg-gradient-to-tr from-purple-700 to-purple-500 border-purple-300 shadow-purple-500/40'
                      : currentBall.letter === 'G'
                      ? 'bg-gradient-to-tr from-emerald-700 to-emerald-500 border-emerald-300 shadow-emerald-500/40'
                      : 'bg-gradient-to-tr from-amber-600 to-amber-400 border-amber-300 shadow-amber-500/40'
                  }`}
                >
                  <span className="text-[11px] font-black tracking-widest text-white/90 uppercase leading-none">
                    {currentBall.letter}
                  </span>
                  <span className="text-2xl font-black text-white leading-none mt-0.5">
                    {currentBall.number}
                  </span>
                </div>
                {/* Glow ring */}
                <div className="absolute inset-0 rounded-full border border-white/40 pointer-events-none" />
              </div>
            ) : (
              <div className="w-16 h-16 rounded-full bg-[#1e0e38] border border-purple-800 flex items-center justify-center text-purple-400 text-xs font-bold">
                {lang === 'am' ? 'ይጠብቁ...' : 'Wait...'}
              </div>
            )}

            {/* Ball Sequence & Provably Fair badge */}
            <div className="space-y-0.5">
              <div className="text-[11px] font-bold text-amber-400 flex items-center">
                <span>
                  {currentBall
                    ? `${lang === 'am' ? 'የወጣ ቁጥር' : 'Ball'} #${currentBall.seq}`
                    : lang === 'am'
                    ? 'ጨዋታው በመጀመር ላይ'
                    : 'Draw starting'}
                </span>
              </div>
              <button
                onClick={onOpenProvablyFair}
                className="text-[9.5px] text-purple-300 hover:text-amber-300 flex items-center underline"
              >
                <ShieldCheck className="w-3 h-3 mr-0.5 text-emerald-400" />
                {lang === 'am' ? 'ትክክለኛነት አረጋግጥ' : 'Provably Fair Seed'}
              </button>
            </div>
          </div>

          {/* History Chips of Last 6 Balls */}
          <div className="flex flex-col items-end space-y-1">
            <span className="text-[9px] font-bold text-purple-400 uppercase tracking-wider">
              {lang === 'am' ? 'ያለፉት ኳሶች' : 'Recent Balls'}
            </span>
            <div className="flex items-center space-x-1 overflow-x-auto max-w-[170px] py-0.5">
              {previousBalls.length > 0 ? (
                previousBalls.map((b, idx) => {
                  const style = getLetterColorClass(b.letter);
                  return (
                    <div
                      key={`${b.number}-${idx}`}
                      className={`w-7 h-7 rounded-full flex flex-col items-center justify-center text-[9px] font-extrabold border ${style.bg} border-white/20 shadow-sm shrink-0`}
                    >
                      <span className="text-[7px] leading-none opacity-80">{b.letter}</span>
                      <span className="leading-none">{b.number}</span>
                    </div>
                  );
                })
              ) : (
                <span className="text-[10px] text-purple-400/60 italic">
                  {lang === 'am' ? 'ገና አልወጡም' : 'None yet'}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Adrenaline Bar: Numbers to go */}
        {myCard && (
          <div className="mt-2 pt-1.5 border-t border-purple-900/50 flex items-center justify-between">
            <div className="flex items-center space-x-1.5 text-xs">
              <span className="text-purple-300 text-[11px]">
                {lang === 'am' ? 'ካርቴላ' : 'Cartela'} #{myReservation?.cartelaId}:
              </span>
              {winCheck.hasWon ? (
                <span className="bg-amber-500 text-black px-2 py-0.5 rounded-full text-[10px] font-black uppercase animate-bounce flex items-center">
                  <Flame className="w-3 h-3 mr-1 fill-black" />
                  {lang === 'am' ? 'ቢንጎ ዝግጁ ነው!' : 'BINGO READY!'}
                </span>
              ) : numbersToGo <= 2 ? (
                <span className="bg-amber-500/20 text-amber-300 border border-amber-500/40 px-2 py-0.5 rounded-full text-[10px] font-black flex items-center animate-pulse">
                  <Flame className="w-3 h-3 mr-1 text-amber-400" />
                  {numbersToGo} {lang === 'am' ? 'ቁጥር ቀርቷል!' : 'TO GO!'}
                </span>
              ) : (
                <span className="text-purple-400 text-[10px]">
                  {numbersToGo} {lang === 'am' ? 'ቁጥሮች ይቀራሉ' : 'numbers to go'}
                </span>
              )}
            </div>

            {/* Toggle between My Card and Master Board */}
            <div className="flex bg-[#1d0b38] rounded-lg p-0.5 border border-purple-800">
              <button
                onClick={() => setActiveTab('card')}
                className={`px-2 py-0.5 rounded-md text-[10px] font-bold flex items-center ${
                  activeTab === 'card'
                    ? 'bg-amber-500 text-black shadow-sm'
                    : 'text-purple-300 hover:text-white'
                }`}
              >
                <LayoutGrid className="w-3 h-3 mr-1" />
                {lang === 'am' ? 'ካርዴ' : 'Card'}
              </button>
              <button
                onClick={() => setActiveTab('master')}
                className={`px-2 py-0.5 rounded-md text-[10px] font-bold flex items-center ${
                  activeTab === 'master'
                    ? 'bg-amber-500 text-black shadow-sm'
                    : 'text-purple-300 hover:text-white'
                }`}
              >
                <FileSpreadsheet className="w-3 h-3 mr-1" />
                {lang === 'am' ? 'ሰሌዳ (1-75)' : 'Board'}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 3. Main Center Content: My 5x5 Card OR Master Board 1-75 */}
      <div className="flex-1 overflow-y-auto p-2.5 flex flex-col justify-center">
        {activeTab === 'card' ? (
          myCard ? (
            <div className="max-w-[17rem] mx-auto w-full bg-[#180b30] border-2 border-purple-700/60 rounded-2xl p-2 shadow-2xl">
              {/* Card B-I-N-G-O Header */}
              <div className="grid grid-cols-5 gap-1.5 mb-1.5 text-center font-black text-sm">
                <span className="bg-blue-600 text-white py-1 rounded-lg shadow-sm">B</span>
                <span className="bg-indigo-600 text-white py-1 rounded-lg shadow-sm">I</span>
                <span className="bg-purple-600 text-white py-1 rounded-lg shadow-sm">N</span>
                <span className="bg-emerald-600 text-white py-1 rounded-lg shadow-sm">G</span>
                <span className="bg-amber-600 text-white py-1 rounded-lg shadow-sm">O</span>
              </div>

              {/* 5x5 Numbers Grid */}
              <div className="space-y-1">
                {myCard.matrix.map((row, rIdx) => (
                  <div key={rIdx} className="grid grid-cols-5 gap-1">
                    {row.map((val, cIdx) => {
                      const isCenter = rIdx === 2 && cIdx === 2;
                      const marked = isCellMarked(val);
                      const isRecentlyCalled = currentBall?.number === val;

                      let cellStyle =
                        'h-10 rounded-lg flex flex-col items-center justify-center font-black text-sm transition-all duration-200 border ';

                      if (isCenter) {
                        cellStyle += 'bg-gradient-to-tr from-amber-600 to-amber-400 text-black border-amber-300 shadow-md ring-2 ring-amber-400/50';
                      } else if (marked) {
                        cellStyle += 'bg-gradient-to-br from-emerald-600 to-emerald-500 text-white border-emerald-300 shadow-md shadow-emerald-950 scale-[1.02] ring-2 ring-emerald-400/60';
                      } else {
                        cellStyle += 'bg-[#230f44] hover:bg-[#2d1456] text-purple-100 border-purple-800/80 active:scale-95';
                      }

                      if (isRecentlyCalled) {
                        cellStyle += ' ring-4 ring-amber-400 animate-pulse';
                      }

                      return (
                        <button
                          key={cIdx}
                          onClick={() => handleCellClick(val)}
                          className={cellStyle}
                        >
                          {isCenter ? (
                            <Star className="w-5 h-5 text-black fill-black" />
                          ) : (
                            <>
                              <span>{val}</span>
                              {marked && (
                                <span className="text-[7.5px] font-bold text-emerald-100 leading-none">
                                  ✓
                                </span>
                              )}
                            </>
                          )}
                        </button>
                      );
                    })}
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="text-center p-6 space-y-3 bg-[#170a2c] rounded-2xl border border-purple-800 max-w-xs mx-auto">
              <AlertTriangle className="w-10 h-10 text-amber-400 mx-auto" />
              <h3 className="font-extrabold text-sm text-white">
                {lang === 'am' ? 'በዚህ ዙር ካርቴላ አልመረጡም' : 'No Cartela in this round'}
              </h3>
              <p className="text-xs text-purple-300">
                {lang === 'am'
                  ? 'ይህ ዙር ሲጠናቀቅ የሚቀጥለውን ዙር ካርቴላ ይምረጡ!'
                  : 'Wait for this round to finish, then select your cartela for the next round!'}
              </p>
            </div>
          )
        ) : (
          /* Master Board 1-75 in B/I/N/G/O columns */
          <div className="bg-[#140828] p-2.5 rounded-2xl border border-purple-900 max-w-sm mx-auto w-full">
            <div className="text-center font-extrabold text-xs text-amber-400 mb-2">
              {lang === 'am' ? 'የወጡ ቁጥሮች ሰሌዳ (1–75)' : 'Master Board (1–75)'}
            </div>
            <div className="grid grid-cols-5 gap-1.5">
              {(['B', 'I', 'N', 'G', 'O'] as const).map((letter, colIdx) => {
                const range = [colIdx * 15 + 1, colIdx * 15 + 15];
                const nums = Array.from({ length: 15 }, (_, i) => range[0] + i);
                return (
                  <div key={letter} className="space-y-1">
                    <div className="text-center font-black text-xs py-1 rounded bg-[#200d3d] text-amber-300 border border-purple-800">
                      {letter}
                    </div>
                    {nums.map((num) => {
                      const isCalled = calledSet.has(num);
                      const isCardNum = myCardNumbers.has(num);

                      let badgeStyle =
                        'h-6 rounded text-[10px] font-bold flex items-center justify-center border ';

                      if (isCalled && isCardNum) {
                        badgeStyle += 'bg-emerald-600 text-white border-emerald-400 font-black shadow-sm';
                      } else if (isCalled) {
                        badgeStyle += 'bg-amber-600 text-white border-amber-400 font-black';
                      } else {
                        badgeStyle += 'bg-[#1b0a33] text-purple-400/70 border-purple-900/40';
                      }

                      return (
                        <div key={num} className={badgeStyle} title={`#${num}`}>
                          {num}
                        </div>
                      );
                    })}
                  </div>
                );
              })}
            </div>

            {/* Master board legend */}
            <div className="mt-2.5 pt-2 border-t border-purple-900/80 flex items-center justify-between text-[10px]">
              <span className="flex items-center text-amber-400">
                <span className="w-2.5 h-2.5 rounded-sm bg-amber-600 mr-1" />
                {lang === 'am' ? 'የወጡ' : 'Called'}
              </span>
              <span className="flex items-center text-emerald-400 font-bold">
                <span className="w-2.5 h-2.5 rounded-sm bg-emerald-600 mr-1" />
                {lang === 'am' ? 'በካርዴ ላይ ያለ' : 'On My Card'}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Claim Feedback Banner if any */}
      {claimFeedback && (
        <div
          className={`mx-3 p-2 rounded-xl text-xs font-black text-center animate-in fade-in ${
            claimFeedback.error
              ? 'bg-red-500/25 text-red-200 border border-red-500/50'
              : 'bg-emerald-500/25 text-emerald-200 border border-emerald-500/50'
          }`}
        >
          {claimFeedback.text}
        </div>
      )}

      {/* 4. Bottom Controls: Automatic toggle, Leave, Refresh, Bingo claim button */}
      <div className="bg-[#17092e] border-t border-[#2e1554] p-2.5 space-y-2">
        <div className="flex items-center justify-between">
          {/* Automatic Toggle */}
          <div className="flex items-center space-x-2">
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={gameStore.autoMode}
                onChange={(e) => {
                  gameStore.autoMode = e.target.checked;
                  onResync();
                }}
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-purple-950 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500"></div>
            </label>
            <span className="text-xs font-bold text-purple-200">
              {lang === 'am' ? 'ራስ-ሰር ምልክት' : 'Auto-Daub'}
            </span>
          </div>

          <div className="flex items-center space-x-2">
            {/* Leave Room */}
            <button
              onClick={onLeaveRoom}
              className="p-1.5 rounded-xl bg-[#251046] hover:bg-[#32165e] text-purple-300 hover:text-white border border-purple-800 transition-colors"
              title="Leave Room"
            >
              <LogOut className="w-4 h-4" />
            </button>

            {/* Resync */}
            <button
              onClick={onResync}
              className="p-1.5 rounded-xl bg-[#251046] hover:bg-[#32165e] text-purple-300 hover:text-white border border-purple-800 transition-colors"
              title="Resync State"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Big Glowing Gold "BINGO!" Claim Button */}
        <button
          onClick={handleClaimBingo}
          disabled={!myCard || Date.now() < gameStore.userClaimLockedUntil}
          className={`w-full py-3.5 rounded-2xl font-black text-base uppercase tracking-wider transition-all duration-200 shadow-xl flex items-center justify-center space-x-2 ${
            winCheck.hasWon
              ? 'bg-gradient-to-r from-amber-400 via-amber-300 to-amber-500 text-black animate-pulse-glow scale-[1.02]'
              : 'bg-gradient-to-r from-[#351a62] to-[#251146] text-purple-300/80 border border-purple-700/60 hover:text-white'
          } ${
            !myCard || Date.now() < gameStore.userClaimLockedUntil
              ? 'opacity-50 cursor-not-allowed'
              : 'cursor-pointer active:scale-95'
          }`}
        >
          <Trophy className="w-5 h-5 text-amber-400" />
          <span>
            {winCheck.hasWon
              ? `${lang === 'am' ? 'ቢንጎ አረጋግጥ!' : 'CLAIM BINGO!'} (${winCheck.winningPatterns[0]})`
              : lang === 'am'
              ? 'ቢንጎ ጥራ (CLAIM)'
              : 'CLAIM BINGO'}
          </span>
        </button>
      </div>
    </div>
  );
};
