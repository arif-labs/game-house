import React, { useState } from 'react';
import { X, User, ShieldAlert, HeartHandshake, Phone, Award, Clock, AlertTriangle } from 'lucide-react';
import { gameStore } from '../../services/gameStore';

interface ProfileModalProps {
  onClose: () => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({ onClose }) => {
  const player = gameStore.player;
  const lang = gameStore.language;

  const [depositLimit, setDepositLimit] = useState<number>(player.dailyDepositLimit ?? 0);
  const [selfExclusionDays, setSelfExclusionDays] = useState<number>(0);
  const [savedMsg, setSavedMsg] = useState<string | null>(null);

  const handleSaveLimits = () => {
    player.dailyDepositLimit = depositLimit;
    if (selfExclusionDays > 0) {
      player.selfExclusionUntil = Date.now() + selfExclusionDays * 86400000;
    }
    setSavedMsg(lang === 'am' ? 'ገደቦች በተሳካ ሁኔታ ተቀምጠዋል' : 'Responsible gaming limits saved');
    setTimeout(() => setSavedMsg(null), 3000);
  };

  const winRate =
    player.roundsPlayed > 0
      ? Math.round((player.roundsWon / player.roundsPlayed) * 100)
      : 0;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 animate-in fade-in duration-200">
      <div className="bg-[#180b30] border-2 border-purple-700/60 rounded-3xl max-w-sm w-full shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 bg-[#1f0e3e] border-b border-purple-800 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center font-black text-xs border border-amber-500/40 overflow-hidden shrink-0">
              {player.avatarUrl ? (
                <img src={player.avatarUrl} alt="Telegram profile" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                (player.fullName || player.username || 'TG').slice(0, 2).toUpperCase()
              )}
            </div>
            <div>
              <h3 className="font-black text-white text-base">
                {lang === 'am' ? 'የተጫዋች መገለጫ' : 'Player Profile'}
              </h3>
              <span className="text-[11px] text-purple-300">
                {player.telegramId || '—'}
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full bg-purple-900/50 hover:bg-purple-800 text-purple-300 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto space-y-4 text-xs">
          {/* User ID card */}
          <div className="p-3 bg-[#120624] rounded-2xl border border-purple-900 flex items-center justify-between">
            <div>
              <span className="font-extrabold text-sm text-white block">
                {player.fullName || 'Name not provided'}
              </span>
              <span className="text-[11px] text-purple-400 flex items-center">
                <Phone className="w-3 h-3 mr-1" />
                {player.phone || 'Phone not provided'}
              </span>
            </div>
            <div className={`flex items-center space-x-1 px-2.5 py-1 rounded-full text-[10px] font-bold ${player.kycStatus === 'verified' ? 'bg-emerald-500/10 border border-emerald-500/40 text-emerald-300' : 'bg-purple-500/10 border border-purple-700/50 text-purple-200'}`}>
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>KYC {player.kycStatus.toUpperCase()}</span>
            </div>
          </div>

          {/* Player Stats */}
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="p-2 bg-[#120624] rounded-xl border border-purple-900">
              <span className="text-[9px] uppercase text-purple-400 block font-bold">
                {lang === 'am' ? 'የተጫወቱት' : 'Played'}
              </span>
              <span className="text-base font-black text-white">{player.roundsPlayed}</span>
            </div>

            <div className="p-2 bg-[#120624] rounded-xl border border-purple-900">
              <span className="text-[9px] uppercase text-amber-400 block font-bold">
                {lang === 'am' ? 'ያሸነፉት' : 'Wins'}
              </span>
              <span className="text-base font-black text-amber-300">{player.roundsWon}</span>
            </div>

            <div className="p-2 bg-[#120624] rounded-xl border border-purple-900">
              <span className="text-[9px] uppercase text-emerald-400 block font-bold">
                {lang === 'am' ? 'የማሸነፍ %' : 'Win Rate'}
              </span>
              <span className="text-base font-black text-emerald-300">{winRate}%</span>
            </div>
          </div>

          {/* Responsible Gaming Controls
          <div className="p-3 bg-[#120624] rounded-2xl border border-purple-900 space-y-3">
            <h4 className="font-black text-white text-xs flex items-center text-amber-400">
              <HeartHandshake className="w-4 h-4 mr-1 text-rose-400" />
              {lang === 'am' ? 'ኃላፊነት የተሞላበት ጨዋታ' : 'Responsible Gaming Controls'}
            </h4>

            Daily Deposit Limit 
            <div className="space-y-1">
              <label className="text-[11px] text-purple-300 block font-medium">
                {lang === 'am' ? 'የቀን ተቀማጭ ከፍተኛ ገደብ (ETB)' : 'Daily Deposit Limit (ETB)'}
              </label>
              <input
                type="number"
                value={depositLimit}
                onChange={(e) => setDepositLimit(Number(e.target.value))}
                step={500}
                className="w-full bg-[#1b0d33] border border-purple-800 rounded-xl px-3 py-1.5 text-white text-xs font-bold focus:outline-none focus:border-amber-400"
              />
            </div>

            Self Exclusion
            <div className="space-y-1">
              <label className="text-[11px] text-purple-300 block font-medium">
                {lang === 'am' ? 'ራስን የማግለል ማረፊያ (ቀናት)' : 'Self-Exclusion Cooldown (Days)'}
              </label>
              <select
                value={selfExclusionDays}
                onChange={(e) => setSelfExclusionDays(Number(e.target.value))}
                className="w-full bg-[#1b0d33] border border-purple-800 rounded-xl px-3 py-1.5 text-white text-xs focus:outline-none focus:border-amber-400"
              >
                <option value={0}>Disabled (Active)</option>
                <option value={1}>24 Hours Cooldown</option>
                <option value={7}>7 Days Break</option>
                <option value={30}>30 Days Self-Exclusion</option>
              </select>
            </div>

            {savedMsg && (
              <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-center text-[11px] font-bold">
                {savedMsg}
              </div>
            )}

            <button
              onClick={handleSaveLimits}
              className="w-full py-2 rounded-xl bg-purple-800/80 hover:bg-purple-700 text-white font-bold text-xs"
            >
              {lang === 'am' ? 'ገደቦችን መዝግብ' : 'Save Limits'}
            </button>
          </div>*/}
        </div>

        {/* Footer */}
        <div className="p-3 bg-[#1f0e3e] border-t border-purple-800">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-extrabold text-xs"
          >
            {lang === 'am' ? 'ተመለስ' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
