import React, { useState } from 'react';
import {
  Wallet,
  ArrowDownLeft,
  ArrowUpRight,
  ArrowRight,
  History,
  CheckCircle2,
  AlertCircle,
  Copy,
  Upload,
  X,
  CreditCard,
  Send
} from 'lucide-react';
import { gameStore } from '../../services/gameStore';

interface WalletModalProps {
  onClose: () => void;
}

export const WalletModal: React.FC<WalletModalProps> = ({ onClose }) => {
  const [tab, setTab] = useState<'deposit' | 'withdraw' | 'move' | 'history'>('deposit');
  const lang = gameStore.language;

  // Deposit Form
  const [depositAmount, setDepositAmount] = useState<number>(200);
  const [depositProvider, setDepositProvider] = useState<'Telebirr' | 'CBE Birr'>('Telebirr');
  const [depositRef, setDepositRef] = useState<string>('');
  const [depositStatus, setDepositStatus] = useState<string | null>(null);

  // Withdraw Form
  const [withdrawAmount, setWithdrawAmount] = useState<number | ''>('');
  const [withdrawProvider, setWithdrawProvider] = useState<'Telebirr' | 'CBE Birr'>('Telebirr');
  const [withdrawAccount, setWithdrawAccount] = useState<string>(gameStore.player.phone || '');
  const [withdrawName, setWithdrawName] = useState<string>(() => {
    const savedName = localStorage.getItem(`ethio-bingo-withdraw-name-${gameStore.player.id}`);
    return savedName ?? '';
  });
  const [withdrawFeedback, setWithdrawFeedback] = useState<{ text: string; error?: boolean } | null>(null);
  const [moveAmount, setMoveAmount] = useState<number | ''>('');
  const [moveFeedback, setMoveFeedback] = useState<{ text: string; error?: boolean } | null>(null);

  const [copied, setCopied] = useState(false);

  const handleDepositSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!depositRef.trim()) {
      setDepositStatus(lang === 'am' ? 'እባክዎ የግብይት ቁጥር (Reference No) ያስገቡ' : 'Please provide transaction reference');
      return;
    }

    await gameStore.requestDeposit(depositAmount, depositProvider, depositRef.trim());
    setDepositStatus(lang === 'am' ? 'የተቀማጭ ጥያቄ በተሳካ ሁኔታ ተልኳል! በደቂቃዎች ውስጥ ይረጋገጣል።' : 'Deposit submitted for approval!');
    setDepositRef('');
    setTimeout(() => {
      setDepositStatus(null);
      setTab('history');
    }, 1500);
  };

  const handleWithdrawSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (withdrawAmount === '' || withdrawAmount < 50) {
      setWithdrawFeedback({ text: lang === 'am' ? 'ቢያንስ 50 ETB ያስገቡ' : 'Enter a withdrawal amount of at least 50 ETB', error: true });
      return;
    }
    const res = await gameStore.requestWithdrawal(withdrawAmount, withdrawProvider, withdrawAccount, withdrawName);
    if (res.success) {
      localStorage.setItem('ethio-bingo-withdraw-name-' + gameStore.player.id, withdrawName.trim());
      setWithdrawFeedback({ text: res.message });
      setTimeout(() => {
        setWithdrawFeedback(null);
        setTab('history');
      }, 1500);
    } else {
      setWithdrawFeedback({ text: res.message, error: true });
    }
  };

  const handleMoveToPlay = async (e: React.FormEvent) => {
    e.preventDefault();
    if (moveAmount === '' || moveAmount <= 0) {
      setMoveFeedback({ text: lang === 'am' ? 'እባክዎ የሚያስተላልፉትን መጠን ያስገቡ' : 'Enter an amount to transfer', error: true });
      return;
    }
    if (moveAmount > gameStore.player.mainWalletBalance) {
      setMoveFeedback({ text: lang === 'am' ? 'በዋና ቦርሳ በቂ ቀሪ ሂሳብ የለም' : 'Insufficient Main Wallet balance', error: true });
      return;
    }
    const res = await gameStore.moveMainToPlay(moveAmount);
    setMoveFeedback({ text: res.message, error: !res.success });
    if (res.success) setMoveAmount('');
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const myLedger = gameStore.ledger.filter((item) => item.userId === gameStore.player.id);

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 animate-in fade-in duration-200">
      <div className="bg-[#180b30] border-2 border-purple-700/60 rounded-3xl max-w-sm w-full shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 bg-[#1f0e3e] border-b border-purple-800 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <Wallet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-white text-base">
                {lang === 'am' ? 'የገንዘብ ቦርሳ' : 'My Wallet'}
              </h3>
              <span className="text-[11px] text-purple-300">
                {lang === 'am' ? 'ቴሌብር እና ሲቢኢ ፈጣን ክፍያዎች' : 'Telebirr & CBE Birr Instant'}
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full bg-purple-900/50 hover:bg-purple-800 text-purple-300 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Balances Strip */}
        <div className="p-3 bg-[#130726] border-b border-purple-900 grid grid-cols-2 gap-2 text-center">
          <div className="bg-[#1c0c36] p-2 rounded-2xl border border-amber-500/30">
            <span className="text-[10px] uppercase font-bold text-amber-400 block">
              {lang === 'am' ? 'ዋና ቦርሳ (ተመላሽ)' : 'Main Wallet (Withdrawable)'}
            </span>
            <span className="text-lg font-black text-white">
              {gameStore.player.mainWalletBalance.toFixed(0)}{' '}
              <span className="text-xs text-amber-300">ETB</span>
            </span>
          </div>

          <div className="bg-[#1c0c36] p-2 rounded-2xl border border-purple-800">
            <span className="text-[10px] uppercase font-bold text-purple-300 block">
              {lang === 'am' ? 'የጨዋታ ቦርሳ(ቦነስ)' : 'Play Wallet (Bonus)'}
            </span>
            <span className="text-lg font-black text-purple-200">
              {gameStore.player.playWalletBalance.toFixed(0)}{' '}
              <span className="text-xs text-purple-400">ETB</span>
            </span>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-purple-900 bg-[#170a2c] text-xs font-extrabold text-center">
          <button
            onClick={() => setTab('deposit')}
            className={`flex-1 py-2.5 flex items-center justify-center space-x-1 border-b-2 transition-colors ${
              tab === 'deposit'
                ? 'border-amber-400 text-amber-400 bg-amber-500/10'
                : 'border-transparent text-purple-300 hover:text-white'
            }`}
          >
            <ArrowDownLeft className="w-4 h-4 text-emerald-400" />
            <span>{lang === 'am' ? 'ገንዘብ አስገባ' : 'Deposit'}</span>
          </button>

          <button
            onClick={() => setTab('withdraw')}
            className={`flex-1 py-2.5 flex items-center justify-center space-x-1 border-b-2 transition-colors ${
              tab === 'withdraw'
                ? 'border-amber-400 text-amber-400 bg-amber-500/10'
                : 'border-transparent text-purple-300 hover:text-white'
            }`}
          >
            <ArrowUpRight className="w-4 h-4 text-amber-400" />
            <span>{lang === 'am' ? 'ገንዘብ አውጣ' : 'Withdraw'}</span>
          </button>

          <button
            onClick={() => setTab('move')}
            className={`flex-1 py-2.5 flex items-center justify-center space-x-1 border-b-2 transition-colors ${
              tab === 'move'
                ? 'border-amber-400 text-amber-400 bg-amber-500/10'
                : 'border-transparent text-purple-300 hover:text-white'
            }`}
          >
            <ArrowRight className="w-4 h-4" />
            <span>{lang === 'am' ? 'ወደ ጨዋታ አስተላልፍ' : 'Move to Play'}</span>
          </button>

          <button
            onClick={() => setTab('history')}
            className={`flex-1 py-2.5 flex items-center justify-center space-x-1 border-b-2 transition-colors ${
              tab === 'history'
                ? 'border-amber-400 text-amber-400 bg-amber-500/10'
                : 'border-transparent text-purple-300 hover:text-white'
            }`}
          >
            <History className="w-4 h-4" />
            <span>{lang === 'am' ? 'ታሪክ' : 'History'}</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-4">
          {tab === 'deposit' && (
            <form onSubmit={handleDepositSubmit} className="space-y-3.5">
              {/* Provider Selection */}
              <div>
                <label className="text-[11px] font-bold text-purple-300 block mb-1">
                  {lang === 'am' ? 'የክፍያ አማራጭ ይምረጡ' : 'Select Payment Provider'}
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setDepositProvider('Telebirr')}
                    className={`p-2.5 rounded-xl border text-xs font-bold text-left flex items-center space-x-2 transition-all ${
                      depositProvider === 'Telebirr'
                        ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                        : 'bg-[#1b0d33] border-purple-900 text-purple-300'
                    }`}
                  >
                    <div className="w-6 h-6 rounded bg-amber-500 text-black font-black text-[10px] flex items-center justify-center">
                      TB
                    </div>
                    <div>
                      <span className="block leading-none">Telebirr</span>
                      <span className="text-[9px] text-purple-400">ቴሌብር</span>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setDepositProvider('CBE Birr')}
                    className={`p-2.5 rounded-xl border text-xs font-bold text-left flex items-center space-x-2 transition-all ${
                      depositProvider === 'CBE Birr'
                        ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                        : 'bg-[#1b0d33] border-purple-900 text-purple-300'
                    }`}
                  >
                    <div className="w-6 h-6 rounded bg-purple-600 text-white font-black text-[10px] flex items-center justify-center">
                      CBE
                    </div>
                    <div>
                      <span className="block leading-none">CBE Birr</span>
                      <span className="text-[9px] text-purple-400">ሲቢኢ ብር</span>
                    </div>
                  </button>
                </div>
              </div>

              {/* Deposit Instructions Card */}
              <div className="bg-[#120624] p-3 rounded-2xl border border-purple-900/80 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-purple-300 text-[11px]">
                    {depositProvider === 'Telebirr' ? 'የቴሌ ብር ቁጥር' : 'የሲቢኢ ብር ቁጥር'}:
                  </span>
                  <button
                    type="button"
                    onClick={() => handleCopy(depositProvider === 'Telebirr' ? '0902695384' : '0902695384')}
                    className="text-amber-400 hover:text-amber-300 text-[11px] font-bold flex items-center"
                  >
                    <Copy className="w-3 h-3 mr-0.5" />
                    {copied ? 'Copied!' : 'Copy'}
                  </button>
                </div>
                <div className="font-mono text-base font-black text-white bg-[#1b0c34] p-2 rounded-xl text-center border border-purple-800">
                  {depositProvider === 'Telebirr' ? '092695384' : '0902695384'}
                </div>
                <p className="text-[10px] text-purple-400 leading-tight">
                  {lang === 'am'
                    ? 'ወደዚህ ቁጥር በቴሌብር/ሲቢኢ ያስገቡ እና የተሰጠዎትን የግብይት ቁጥር ከታች ይሙሉ!'
                    : 'Transfer funds to our account and paste your transaction reference ID below!'}
                </p>
              </div>

              {/* Amount Presets */}
              <div>
                <label className="text-[11px] font-bold text-purple-300 block mb-1">
                  {lang === 'am' ? 'የብር መጠን (ETB)' : 'Amount (ETB)'}
                </label>
                <div className="grid grid-cols-4 gap-1.5 mb-2">
                  {[50, 100, 200, 500].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setDepositAmount(amt)}
                      className={`py-1.5 rounded-lg text-xs font-bold border transition-colors ${
                        depositAmount === amt
                          ? 'bg-amber-500 text-black border-amber-400'
                          : 'bg-[#1b0d33] text-purple-200 border-purple-900'
                      }`}
                    >
                      {amt}
                    </button>
                  ))}
                </div>
                <input
                  type="number"
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(Number(e.target.value))}
                  min={10}
                  step={10}
                  className="w-full bg-[#120624] border border-purple-800 rounded-xl px-3 py-2 text-white text-sm font-bold focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Transaction Reference input */}
              <div>
                <label className="text-[11px] font-bold text-purple-300 block mb-1">
                  {lang === 'am' ? 'የግብይት ቁጥር (Transaction Reference / SMS Code)' : 'Transaction Reference / SMS Code'}
                </label>
                <input
                  type="text"
                  placeholder="e.g. TXN-TB-982314"
                  value={depositRef}
                  onChange={(e) => setDepositRef(e.target.value)}
                  className="w-full bg-[#120624] border border-purple-800 rounded-xl px-3 py-2 text-white text-sm focus:outline-none focus:border-amber-400"
                />
              </div>

              {depositStatus && (
                <div className="p-2 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs text-center font-bold">
                  {depositStatus}
                </div>
              )}

              <button
                type="submit"
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black text-sm shadow-xl active:scale-95 transition-all flex items-center justify-center space-x-1.5"
              >
                <Send className="w-4 h-4" />
                <span>{lang === 'am' ? 'ተቀማጭ አረጋግጥ' : 'Submit Deposit'}</span>
              </button>
            </form>
          )}

          {tab === 'withdraw' && (
            <form onSubmit={handleWithdrawSubmit} className="space-y-3.5">
              <div>
                <label className="text-[11px] font-bold text-purple-300 block mb-1">
                  {lang === 'am' ? 'የማውጫ አማራጭ' : 'Withdrawal Method'}
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setWithdrawProvider('Telebirr')}
                    className={`p-2.5 rounded-xl border text-xs font-bold text-left flex items-center space-x-2 transition-all ${
                      withdrawProvider === 'Telebirr'
                        ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                        : 'bg-[#1b0d33] border-purple-900 text-purple-300'
                    }`}
                  >
                    <div className="w-6 h-6 rounded bg-amber-500 text-black font-black text-[10px] flex items-center justify-center">
                      TB
                    </div>
                    <span>Telebirr</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setWithdrawProvider('CBE Birr')}
                    className={`p-2.5 rounded-xl border text-xs font-bold text-left flex items-center space-x-2 transition-all ${
                      withdrawProvider === 'CBE Birr'
                        ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                        : 'bg-[#1b0d33] border-purple-900 text-purple-300'
                    }`}
                  >
                    <div className="w-6 h-6 rounded bg-purple-600 text-white font-black text-[10px] flex items-center justify-center">
                      CBE
                    </div>
                    <span>CBE Birr</span>
                  </button>
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold text-purple-300 block mb-1">
                  {lang === 'am' ? 'የመውጫ ብር መጠን (ዝቅተኛ 50 ETB)' : 'Withdraw Amount (Min 50 ETB)'}
                </label>
                <input
                  type="number"
                  value={withdrawAmount}
                  onChange={(e) => setWithdrawAmount(e.target.value === '' ? '' : Number(e.target.value))}
                  min={50}
                  max={gameStore.player.mainWalletBalance}
                  required
                  className="w-full bg-[#120624] border border-purple-800 rounded-xl px-3 py-2 text-white text-sm font-bold focus:outline-none focus:border-amber-400"
                />
                <span className="text-[10px] text-purple-400 mt-1 block">
                  {lang === 'am' ? 'ሊወጣ የሚችል ቀሪ ሂሳብ' : 'Available to withdraw'}:{' '}
                  <strong className="text-amber-300">{gameStore.player.mainWalletBalance} ETB</strong>
                </span>
              </div>

              <div>
                <label className="text-[11px] font-bold text-purple-300 block mb-1">
                  {withdrawProvider === 'Telebirr'
                    ? lang === 'am' ? 'የቴሌብር ስልክ ቁጥር' : 'Telebirr Phone Number'
                    : lang === 'am' ? 'የሲቢኢ የሂሳብ ቁጥር' : 'CBE Account Number'}
                </label>
                <input
                  type="text"
                  value={withdrawAccount}
                  onChange={(e) => setWithdrawAccount(e.target.value)}
                  className="w-full bg-[#120624] border border-purple-800 rounded-xl px-3 py-2 text-white text-sm focus:outline-none focus:border-amber-400 font-mono"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-purple-300 block mb-1">
                  {lang === 'am' ? 'የመለያ ሙሉ ስም' : 'Account Full Name'}
                </label>
                <input
                  type="text"
                  value={withdrawName}
                  onChange={(e) => setWithdrawName(e.target.value)}
                  className="w-full bg-[#120624] border border-purple-800 rounded-xl px-3 py-2 text-white text-sm focus:outline-none focus:border-amber-400"
                />
              </div>

              {withdrawFeedback && (
                <div
                  className={`p-2 rounded-xl text-xs font-bold text-center ${
                    withdrawFeedback.error
                      ? 'bg-red-500/20 text-red-300 border border-red-500/40'
                      : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  }`}
                >
                  {withdrawFeedback.text}
                </div>
              )}

              <button
                type="submit"
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black text-sm shadow-xl active:scale-95 transition-all flex items-center justify-center space-x-1.5"
              >
                <ArrowUpRight className="w-4 h-4" />
                <span>{lang === 'am' ? 'የማውጣት ጥያቄ ላክ' : 'Submit Withdrawal'}</span>
              </button>
            </form>
          )}

          {tab === 'move' && (
            <form onSubmit={handleMoveToPlay} className="space-y-3.5">
              <div className="rounded-2xl bg-[#120624] border border-purple-900 p-3 text-xs text-purple-200">
                {lang === 'am'
                  ? 'ለቢንጎ ካርድ ለመምረጥ ገንዘብን ከዋና ቦርሳ ወደ የጨዋታ ቦርሳ ያስተላልፉ። ጨዋታ ሲጫወቱ የጨዋታ ቦርሳ ብቻ ይቀነሳል።'
                  : 'Move money from Main Wallet to Play Wallet before selecting bingo cards. Card stakes are deducted only from Play Wallet.'}
              </div>
              <div>
                <label className="text-[11px] font-bold text-purple-300 block mb-1">
                  {lang === 'am' ? 'የሚተላለፍ መጠን (ETB)' : 'Transfer Amount (ETB)'}
                </label>
                <input
                  type="number"
                  value={moveAmount}
                  onChange={(e) => setMoveAmount(e.target.value === '' ? '' : Number(e.target.value))}
                  min={1}
                  max={gameStore.player.mainWalletBalance}
                  required
                  className="w-full bg-[#120624] border border-purple-800 rounded-xl px-3 py-2 text-white text-sm font-bold focus:outline-none focus:border-amber-400"
                />
                <span className="text-[10px] text-purple-400 mt-1 block">
                  {lang === 'am' ? 'የዋና ቦርሳ ቀሪ ሂሳብ' : 'Main Wallet available'}: <strong className="text-amber-300">{gameStore.player.mainWalletBalance.toFixed(2)} ETB</strong>
                </span>
              </div>
              {moveFeedback && (
                <div className={`p-2 rounded-xl text-xs font-bold text-center ${moveFeedback.error ? 'bg-red-500/20 text-red-300 border border-red-500/40' : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'}`}>
                  {moveFeedback.text}
                </div>
              )}
              <button type="submit" className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black text-sm shadow-xl active:scale-95 transition-all flex items-center justify-center space-x-1.5">
                <ArrowRight className="w-4 h-4" />
                <span>{lang === 'am' ? 'ወደ ጨዋታ ቦርሳ አስተላልፍ' : 'Move to Play Wallet'}</span>
              </button>
            </form>
          )}

          {tab === 'history' && (
            <div className="space-y-2">
              <div className="text-[11px] font-bold text-purple-400 uppercase tracking-wider mb-2 flex justify-between">
                <span>{lang === 'am' ? 'የግብይቶች ታሪክ' : 'Immutable Ledger'}</span>
                <span className="text-amber-400">{myLedger.length} Records</span>
              </div>

              {myLedger.length === 0 ? (
                <div className="text-center p-6 text-purple-400 text-xs">
                  {lang === 'am' ? 'ምንም ታሪክ የለም' : 'No transactions recorded'}
                </div>
              ) : (
                myLedger.map((item) => {
                  const isPositive = item.amount > 0;
                  return (
                    <div
                      key={item.id}
                      className="p-2.5 rounded-2xl bg-[#120624] border border-purple-900/80 flex items-center justify-between text-xs"
                    >
                      <div className="space-y-0.5">
                        <div className="flex items-center space-x-1.5">
                          <span
                            className={`w-2 h-2 rounded-full ${
                              isPositive ? 'bg-emerald-400' : 'bg-red-400'
                            }`}
                          />
                          <span className="font-extrabold text-white text-[11px]">
                            {item.type}
                          </span>
                          <span className="text-[9px] text-purple-400">
                            ({item.walletType})
                          </span>
                        </div>
                        <p className="text-[10px] text-purple-300/80">{item.description}</p>
                        <span className="text-[9px] text-purple-500 font-mono">
                          {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>

                      <div className="text-right">
                        <span
                          className={`font-black text-sm block ${
                            isPositive ? 'text-emerald-400' : 'text-red-400'
                          }`}
                        >
                          {isPositive ? `+${item.amount}` : item.amount} ETB
                        </span>
                        <span className="text-[9px] text-purple-400">
                          Bal: {item.balanceAfter} ETB
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
