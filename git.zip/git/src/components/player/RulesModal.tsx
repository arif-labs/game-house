import React from 'react';
import { X, Award, ShieldCheck, Check, Sparkles, BookOpen } from 'lucide-react';
import { gameStore } from '../../services/gameStore';

interface RulesModalProps {
  onClose: () => void;
}

export const RulesModal: React.FC<RulesModalProps> = ({ onClose }) => {
  const lang = gameStore.language;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 animate-in fade-in duration-200">
      <div className="bg-[#180b30] border-2 border-purple-700/60 rounded-3xl max-w-sm w-full shadow-2xl overflow-hidden flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="p-4 bg-[#1f0e3e] border-b border-purple-800 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-white text-base">
                {lang === 'am' ? 'የጨዋታ ህጎች' : 'How to Play'}
              </h3>
              <span className="text-[11px] text-purple-300">
                {lang === 'am' ? '75-ኳስ ኢትዮ ቢንጎ አጨዋወት' : '75-Ball Ethio Bingo Rules'}
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full bg-purple-900/50 hover:bg-purple-800 text-purple-300 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto space-y-4 text-xs text-purple-200">
          {/* Card Overview */}
          <div className="bg-[#120624] p-3 rounded-2xl border border-purple-900 space-y-2">
            <h4 className="font-extrabold text-white text-sm flex items-center text-amber-400">
              <Sparkles className="w-4 h-4 mr-1" />
              {lang === 'am' ? '1. የካርቴላ መዋቅር (5x5)' : '1. Cartela Structure (5x5)'}
            </h4>
            <p className="text-[11px] text-purple-300 leading-relaxed">
              {lang === 'am'
                ? 'እያንዳንዱ ካርቴላ 24 ቁጥሮች እና በመሃል 1 ነፃ ★ (Free Star) አለው። ቁጥሮቹ በ B (1-15), I (16-30), N (31-45), G (46-60), O (61-75) ረድፎች ይከፈላሉ።'
                : 'Every cartela has 24 numbers and 1 Free Center Star (★). Numbers are organized in B (1-15), I (16-30), N (31-45), G (46-60), O (61-75) columns.'}
            </p>
          </div>

          {/* Winning Patterns */}
          <div className="bg-[#120624] p-3 rounded-2xl border border-purple-900 space-y-2.5">
            <h4 className="font-extrabold text-white text-sm flex items-center text-amber-400">
              <Award className="w-4 h-4 mr-1" />
              {lang === 'am' ? '2. የማሸነፊያ መንገዶች (Winning Patterns)' : '2. Winning Patterns'}
            </h4>

            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="p-2 rounded-xl bg-[#1b0d33] border border-purple-800">
                <span className="font-bold text-white block">
                  {lang === 'am' ? 'አግድም መስመር' : 'Horizontal Row'}
                </span>
                <span className="text-[10px] text-purple-400">
                  {lang === 'am' ? 'ማንኛውም 5 ቁጥሮች በአግድም' : 'Any 5 horizontal cells'}
                </span>
              </div>

              <div className="p-2 rounded-xl bg-[#1b0d33] border border-purple-800">
                <span className="font-bold text-white block">
                  {lang === 'am' ? 'ቁልቁል ረድፍ' : 'Vertical Column'}
                </span>
                <span className="text-[10px] text-purple-400">
                  {lang === 'am' ? 'ማንኛውም 5 ቁጥሮች በቁልቁል' : 'Any 5 vertical cells'}
                </span>
              </div>

              <div className="p-2 rounded-xl bg-[#1b0d33] border border-purple-800">
                <span className="font-bold text-white block">
                  {lang === 'am' ? 'ዲያጎናል (ሰያፍ)' : 'Diagonal Line'}
                </span>
                <span className="text-[10px] text-purple-400">
                  {lang === 'am' ? 'ከጫፍ እስከ ጫፍ በመሃል ኮከብ' : 'Corner to corner with star'}
                </span>
              </div>

              <div className="p-2 rounded-xl bg-[#1b0d33] border border-purple-800">
                <span className="font-bold text-white block">
                  {lang === 'am' ? 'አራቱ ማዕዘናት' : 'Four Corners'}
                </span>
                <span className="text-[10px] text-purple-400">
                  {lang === 'am' ? 'የካርቴላው አራቱ ጫፎች' : 'Four outer corner cells'}
                </span>
              </div>
            </div>

            <div className="p-2 rounded-xl bg-[#1b0d33] border border-amber-500/30">
              <span className="font-extrabold text-amber-300 block">
                {lang === 'am' ? 'ሙሉ ቤት (Full House / Coverall)' : 'Full House (Coverall)'}
              </span>
              <span className="text-[10px] text-purple-300">
                {lang === 'am' ? 'ሁሉም 24ቱ የካርቴላ ቁጥሮች ሲወጡ' : 'All 24 numbered squares complete'}
              </span>
            </div>
          </div>

          {/* Derash Math */}
          <div className="bg-[#120624] p-3 rounded-2xl border border-purple-900 space-y-2">
            <h4 className="font-extrabold text-white text-sm flex items-center text-amber-400">
              <ShieldCheck className="w-4 h-4 mr-1 text-emerald-400" />
              {lang === 'am' ? '3. የደራሽ ሽልማት ቀመር' : '3. Prize Math (Derash)'}
            </h4>
            <p className="text-[11px] text-purple-300 font-mono bg-[#190c30] p-2 rounded-xl text-center border border-purple-800">
              ደራሽ = (ተጫዋቾች × መደብ) × (1 - 20% የቤት ድርሻ)
            </p>
            <p className="text-[10px] text-purple-400">
              {lang === 'am'
                ? 'በአንድ ዙር ብዙ አሸናፊዎች እኩል ቢያሸንፉ ሽልማቱ እኩል ይከፋፈላል!'
                : 'Ties on the exact same ball split the prize pool equally.'}
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-[#1f0e3e] border-t border-purple-800">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-extrabold text-xs shadow-md"
          >
            {lang === 'am' ? 'ተረድቻለሁ • ተመለስ' : 'Got it • Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
