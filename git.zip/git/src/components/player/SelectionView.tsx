import React, { useState } from 'react';
import { ArrowLeft, RefreshCw, Clock, Check, X, Star, AlertCircle, Shield } from 'lucide-react';
import { gameStore } from '../../services/gameStore';
import { getCartelaById, getLetterColorClass } from '../../engine/bingoEngine';
import { CartelaCard } from '../../types/bingo';

interface SelectionViewProps {
  roomId: string;
  onBackToLobby: () => void;
  onResync: () => void;
}

export const SelectionView: React.FC<SelectionViewProps> = ({ roomId, onBackToLobby, onResync }) => {
  const room = gameStore.rooms.find((r) => r.id === roomId) || gameStore.rooms[0];
  const round = gameStore.roundStates[roomId];
  const reservations = gameStore.cartelaReservations[roomId] || [];
  const lang = gameStore.language;

  // Selected card preview modal state
  const [previewCardId, setPreviewCardId] = useState<number | null>(null);
  const [feedbackMsg, setFeedbackMsg] = useState<{ text: string; error?: boolean } | null>(null);

  const myReservations = reservations.filter(
    (r) => r.userId === gameStore.player.id && r.status === 'confirmed'
  );
  const myReservation = myReservations[0];
  const previewMyReservation = previewCardId === null ? undefined : myReservations.find((r) => r.cartelaId === previewCardId);
  const cartelaLimit = Math.max(1, room.maxCartelasPerPlayer || 1);

  const timer = round?.timerSeconds || 0;
  const timerPercent = Math.max(0, Math.min(100, (timer / (room.selectionDuration || 45)) * 100));

  const handleCardClick = (id: number) => {
    // Open preview
    setPreviewCardId(id);
    setFeedbackMsg(null);
  };

  const handleConfirmReservation = async (cartelaId: number) => {
    const res = await gameStore.selectCartela(roomId, cartelaId);
    if (res.success) {
      setFeedbackMsg({ text: res.message });
      setTimeout(() => {
        setPreviewCardId(null);
        setFeedbackMsg(null);
      }, 700);
    } else {
      setFeedbackMsg({ text: res.message, error: true });
    }
  };

  const handleReleaseCartela = async (cartelaId: number) => {
    const ok = await gameStore.releaseCartela(roomId, cartelaId);
    if (ok) {
      setFeedbackMsg({ text: lang === 'am' ? 'ካርቴላ ተሰርዟል' : 'Cartela released' });
      setTimeout(() => {
        setPreviewCardId(null);
        setFeedbackMsg(null);
      }, 500);
    }
  };

  const previewCard: CartelaCard | null = previewCardId ? getCartelaById(previewCardId) : null;

  return (
    <div className="flex flex-col h-[calc(100vh-62px)] max-h-screen bg-[#0d051a]">
      {/* 1. Header: Back Arrow, Title, Refresh */}
      <div className="bg-[#170a2c] border-b border-[#2d1752] px-3 py-2 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <button
            onClick={onBackToLobby}
            className="p-1.5 rounded-full hover:bg-[#251246] text-purple-300 hover:text-white transition-colors"
            title={lang === 'am' ? 'ወደ ክፍሎች ዝርዝር ተመለስ' : 'Back to Lobby'}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-sm font-extrabold text-white leading-tight">
              {lang === 'am' ? room.amharicName : room.name}
            </h2>
            <div className="text-[10px] text-amber-400 font-semibold">
              {round?.roundCode || '—'}
            </div>
          </div>
        </div>

        <button
          onClick={onResync}
          className="p-1.5 rounded-full hover:bg-[#251246] text-purple-300 hover:text-white transition-colors"
          title={lang === 'am' ? 'ዙሩን ዳግም አዘምን' : 'Resync Round'}
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      {room.automatedPlayersEnabled && (
        <div className="px-3 py-2 bg-amber-500/10 border-b border-amber-500/30 text-[10px] text-amber-100">
          House-controlled automated participants may join when real-player participation is below {room.automatedPlayersTriggerBelow || 10}. Any automated participant is identified as BOT. Currently joined: {reservations.filter((r) => r.isBot && r.status === 'confirmed').length}.
          {reservations.some((r) => r.isBot && r.status === 'confirmed') && <span className="block mt-1">Automated names: {reservations.filter((r) => r.isBot && r.status === 'confirmed').map((r) => r.username).join(', ')}</span>}
        </div>
      )}

      {/* 2. Stat Strip: Main Wallet, Play Wallet, Stake, Countdown Timer */}
      <div className="bg-[#1f0e3a] border-b border-[#361a64] px-3 py-2 grid grid-cols-4 gap-1.5 text-center text-xs">
        <div className="bg-[#140827] rounded-lg p-1.5 border border-purple-900/50">
          <span className="text-[9px] uppercase text-purple-300/80 block">
            {lang === 'am' ? 'ዋና ቦርሳ' : 'Main Wal'}
          </span>
          <span className="font-extrabold text-amber-300 text-xs">
            {gameStore.player.mainWalletBalance.toFixed(0)} <span className="text-[8px] font-normal">ETB</span>
          </span>
        </div>

        <div className="bg-[#140827] rounded-lg p-1.5 border border-purple-900/50">
          <span className="text-[9px] uppercase text-purple-300/80 block">
            {lang === 'am' ? 'ቦነስ ቦርሳ' : 'Play Wal'}
          </span>
          <span className="font-extrabold text-purple-300 text-xs">
            {gameStore.player.playWalletBalance.toFixed(0)} <span className="text-[8px] font-normal">ETB</span>
          </span>
        </div>

        <div className="bg-[#140827] rounded-lg p-1.5 border border-purple-900/50">
          <span className="text-[9px] uppercase text-purple-300/80 block">
            {lang === 'am' ? 'መደብ' : 'Stake'}
          </span>
          <span className="font-extrabold text-white text-xs">
            {room.stake} <span className="text-[8px] font-normal text-amber-400">ETB</span>
          </span>
        </div>

        <div className="bg-[#140827] rounded-lg p-1.5 border border-purple-900/50 relative overflow-hidden">
          <span className="text-[9px] uppercase text-amber-400 font-bold block flex items-center justify-center">
            <Clock className="w-2.5 h-2.5 mr-0.5" />
            {lang === 'am' ? 'ቀሪ ሰዓት' : 'Timer'}
          </span>
          <span className="font-black text-amber-300 text-xs">{round ? `${timer}s` : '—'}</span>
          {/* subtle countdown line */}
          <div
            className="absolute bottom-0 left-0 h-0.5 bg-amber-500 transition-all duration-1000"
            style={{ width: `${timerPercent}%` }}
          />
        </div>
      </div>

      {/* Cartela status indicator legend */}
      <div className="px-3 py-1.5 bg-[#120722] border-b border-[#251144] flex items-center justify-between text-[10px]">
        <span className="text-purple-300 font-medium">
          {lang === 'am' ? 'ካርቴላ ይምረጡ (1-200)' : 'Select Cartelas (1-200)'} • {myReservations.length}/{cartelaLimit} selected:
        </span>
        <div className="flex items-center space-x-2.5">
          <span className="flex items-center text-purple-300">
            <span className="w-2.5 h-2.5 rounded-sm bg-[#2b174b] border border-purple-700 mr-1" />
            {lang === 'am' ? 'ነፃ' : 'Free'}
          </span>
          <span className="flex items-center text-amber-400">
            <span className="w-2.5 h-2.5 rounded-sm bg-amber-600 mr-1" />
            {lang === 'am' ? 'የተያዘ' : 'Taken'}
          </span>
          <span className="flex items-center text-emerald-400 font-bold">
            <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500 mr-1" />
            {lang === 'am' ? 'የኔ' : 'Mine'}
          </span>
        </div>
      </div>

      {/* 3. Scrollable Grid of Cartelas 1..200 */}
      <div className="flex-1 overflow-y-auto p-2.5">
        <div className="grid grid-cols-5 gap-1.5">
          {Array.from({ length: 200 }, (_, i) => i + 1).map((cartelaId) => {
            const reservation = reservations.find((r) => r.cartelaId === cartelaId);
            const isMine = reservation?.userId === gameStore.player.id;
            const isTaken = !!reservation && !isMine;

            let btnClasses =
              'h-11 rounded-lg font-bold text-xs flex flex-col items-center justify-center transition-all duration-150 border ';

            if (isMine) {
              btnClasses += 'bg-emerald-600 text-white border-emerald-400 shadow-md shadow-emerald-900/50 scale-[1.03] ring-2 ring-emerald-400';
            } else if (isTaken) {
              btnClasses += 'bg-[#823a05] text-amber-100 border-amber-600/60 opacity-90 cursor-not-allowed';
            } else {
              btnClasses += 'bg-[#22103f] hover:bg-[#31175b] active:scale-95 text-purple-100 border-[#3b1d6e] hover:border-amber-500/60';
            }

            return (
              <button
                key={cartelaId}
                onClick={() => handleCardClick(cartelaId)}
                className={btnClasses}
                title={`Cartela #${cartelaId} ${isTaken ? (reservation.isBot ? `(House-controlled BOT: ${reservation.username})` : `(Taken by ${reservation.username})`) : ''}`}
              >
                <span className="text-[12px] font-black">{cartelaId}</span>
                {isMine ? (
                  <span className="text-[8px] font-bold text-emerald-200">
                    {lang === 'am' ? 'የኔ' : 'MINE'}
                  </span>
                ) : isTaken ? (
                  <span className="text-[7.5px] truncate max-w-[50px] text-amber-200 font-medium">
                    {reservation?.isBot ? 'BOT' : reservation?.username.substring(0, 5)}
                  </span>
                ) : (
                  <span className="text-[8px] text-purple-400">
                    {room.stake} ETB
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* 4. Footer Bar */}
      <div className="bg-[#170a2c] border-t border-[#2d1752] p-2.5">
        <div className="flex items-center justify-between">
          <div className="text-xs">
            <span className="text-purple-300 block text-[11px]">
              {myReservations.length > 0
                ? `${lang === 'am' ? 'የተመረጡ ካርቴላዎች' : 'My Cartelas'}: ${myReservations.map((r) => `#${r.cartelaId}`).join(', ')}`
                : lang === 'am'
                ? 'ካርቴላ ይምረጡ'
                : 'Choose your cartela'}
            </span>
            {myReservation ? (
              <span className="text-emerald-400 font-black text-xs flex items-center">
                <Check className="w-3.5 h-3.5 mr-1" />
                {lang === 'am' ? 'ተረጋግጧል' : 'Confirmed & Ready'}
              </span>
            ) : (
              <span className="text-amber-400 font-bold text-xs">
                {lang === 'am' ? 'እስከ ቆጠራው ማብቂያ ድረስ ይምረጡ' : 'Tap any number above to preview'}
              </span>
            )}
          </div>

          {/* Quick select or Preview button */}
          <button
            disabled={myReservations.length >= cartelaLimit}
            onClick={() => {
              const takenIds = new Set(reservations.map((r) => r.cartelaId));
              let free = 1;
              while (takenIds.has(free) && free <= 200) free++;
              if (free <= 200) setPreviewCardId(free);
            }}
            className="px-3 py-1.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 disabled:opacity-40 disabled:cursor-not-allowed text-black font-extrabold text-xs rounded-xl shadow-md active:scale-95 transition-all"
          >
            {myReservations.length >= cartelaLimit ? (lang === 'am' ? 'የተፈቀደው ተሞልቷል' : 'Limit Reached') : (lang === 'am' ? 'በእድል ምረጥ' : 'Add Cartela')}
          </button>
        </div>

        {/* Colored B-I-N-G-O letter strip decoration */}
        <div className="mt-2 grid grid-cols-5 gap-1 pt-1 border-t border-purple-900/50 text-center font-black text-[10px]">
          <span className="bg-blue-600/30 text-blue-400 py-0.5 rounded border border-blue-500/40">B (1-15)</span>
          <span className="bg-indigo-600/30 text-indigo-400 py-0.5 rounded border border-indigo-500/40">I (16-30)</span>
          <span className="bg-purple-600/30 text-purple-400 py-0.5 rounded border border-purple-500/40">N (31-45)</span>
          <span className="bg-emerald-600/30 text-emerald-400 py-0.5 rounded border border-emerald-500/40">G (46-60)</span>
          <span className="bg-amber-600/30 text-amber-400 py-0.5 rounded border border-amber-500/40">O (61-75)</span>
        </div>
      </div>

      {/* 5x5 Card Preview & Confirmation Modal */}
      {previewCard && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 animate-in fade-in duration-150">
          <div className="bg-[#1b0d33] border-2 border-amber-500/50 rounded-2xl p-4 w-full max-w-sm shadow-2xl space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-purple-900">
              <div>
                <h3 className="text-base font-black text-white flex items-center space-x-1.5">
                  <span>{lang === 'am' ? 'ካርቴላ ቁጥር' : 'Cartela'} #{previewCard.id}</span>
                </h3>
                <span className="text-[11px] text-amber-400 font-medium">
                  {room.stake} ETB • {lang === 'am' ? 'ደራሽ ድርሻ' : 'Derash Pool'}: {round ? `${round.derashPrize.toFixed(0)} ETB` : '—'}
                </span>
              </div>
              <button
                onClick={() => setPreviewCardId(null)}
                className="p-1 rounded-full bg-purple-900/50 hover:bg-purple-800 text-purple-300 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* 5x5 Matrix Preview */}
            <div className="bg-[#120724] p-2 rounded-xl border border-purple-900/80">
              {/* Header B-I-N-G-O */}
              <div className="grid grid-cols-5 gap-1 mb-1 text-center font-black text-xs">
                <span className="bg-blue-600 text-white py-1 rounded">B</span>
                <span className="bg-indigo-600 text-white py-1 rounded">I</span>
                <span className="bg-purple-600 text-white py-1 rounded">N</span>
                <span className="bg-emerald-600 text-white py-1 rounded">G</span>
                <span className="bg-amber-600 text-white py-1 rounded">O</span>
              </div>

              {/* 5 Rows */}
              <div className="space-y-1">
                {previewCard.matrix.map((row, rIdx) => (
                  <div key={rIdx} className="grid grid-cols-5 gap-1">
                    {row.map((val, cIdx) => {
                      const isCenter = rIdx === 2 && cIdx === 2;
                      return (
                        <div
                          key={cIdx}
                          className={`h-9 rounded-md flex items-center justify-center font-bold text-xs border ${
                            isCenter
                              ? 'bg-amber-500/20 text-amber-300 border-amber-400/60 font-black'
                              : 'bg-[#210f3c] text-white border-purple-800/40'
                          }`}
                        >
                          {isCenter ? (
                            <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                          ) : (
                            val
                          )}
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>
            </div>

            {/* Feedback alert */}
            {feedbackMsg && (
              <div
                className={`p-2 rounded-lg text-xs font-bold text-center ${
                  feedbackMsg.error
                    ? 'bg-red-500/20 text-red-300 border border-red-500/40'
                    : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                }`}
              >
                {feedbackMsg.text}
              </div>
            )}

            {/* Actions */}
            <div className="pt-1 flex items-center space-x-2">
              {previewMyReservation ? (
                <button
                  onClick={() => handleReleaseCartela(previewCard.id)}
                  className="flex-1 py-2.5 rounded-xl bg-red-600/30 hover:bg-red-600/50 text-red-200 border border-red-500/40 font-bold text-xs"
                >
                  {lang === 'am' ? 'ካርቴላውን መልስ' : 'Release Cartela'}
                </button>
              ) : (
                <button
                  onClick={() => handleConfirmReservation(previewCard.id)}
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black text-xs shadow-lg active:scale-95 transition-all"
                >
                  {lang === 'am'
                    ? `ካርቴላ #${previewCard.id} አረጋግጥ (${room.stake} ብር)`
                    : `Confirm Cartela #${previewCard.id} (${room.stake} ETB)`}
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
