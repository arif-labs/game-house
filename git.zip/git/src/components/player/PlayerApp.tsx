import React, { useState, useEffect, useSyncExternalStore } from 'react';
import { Trophy, LayoutGrid, Wallet, Radio } from 'lucide-react';
import { gameStore } from '../../services/gameStore';
import { HeaderBar } from './HeaderBar';
import { LobbyView } from './LobbyView';
import { SelectionView } from './SelectionView';
import { CountdownTransition } from './CountdownTransition';
import { DrawingView } from './DrawingView';
import { WinModal } from './WinModal';
import { WalletModal } from './WalletModal';
import { ProfileModal } from './ProfileModal';
import { RulesModal } from './RulesModal';
import { ProvablyFairModal } from './ProvablyFairModal';

const ACTIVE_PHASES: readonly string[] = ['SELECTION', 'COUNTDOWN_END', 'DRAWING', 'FINISHED', 'PAYOUT'];

export const PlayerApp: React.FC = () => {
  // Subscribe to central game store
  useSyncExternalStore(gameStore.subscribe, gameStore.getVersion);

  useEffect(() => {
    const telegramUser = window.Telegram?.WebApp?.initDataUnsafe?.user;
    if (telegramUser?.photo_url && !gameStore.player.avatarUrl) {
      gameStore.setPlayer({ avatarUrl: telegramUser.photo_url });
    }
  }, []);

  const [activeTab, setActiveTab] = useState<'lobby' | 'game' | 'leaderboard'>('lobby');
  const [showWalletModal, setShowWalletModal] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [showRulesModal, setShowRulesModal] = useState(false);
  const [showProvablyFairModal, setShowProvablyFairModal] = useState(false);
  const [showWinModal, setShowWinModal] = useState(true);
  const [isResyncing, setIsResyncing] = useState(false);
  const [resyncMessage, setResyncMessage] = useState('');
  const [isCheckingPhone, setIsCheckingPhone] = useState(false);
  const [phoneCheckMessage, setPhoneCheckMessage] = useState('');
  const [leaders, setLeaders] = useState<Array<{ id: string; name: string; wins: number; won: number }>>([]);
  const [leaderboardLoading, setLeaderboardLoading] = useState(false);
  const [leaderboardError, setLeaderboardError] = useState('');

  useEffect(() => {
    if (activeTab !== 'leaderboard') return;
    const controller = new AbortController();
    setLeaderboardLoading(true);
    setLeaderboardError('');
    fetch('/api/player/leaderboard', { credentials: 'include', signal: controller.signal })
      .then(async (response) => {
        const data = await response.json().catch(() => null);
        if (!response.ok || data?.ok !== true) throw new Error(data?.error || 'Leaderboard is unavailable.');
        setLeaders(
          Array.isArray(data.leaders)
            ? data.leaders.map((l: any) => ({ ...l, wins: Number(l.wins) || 0, won: Number(l.won) || 0 }))
            : []
        );
      })
      .catch((error) => {
        if (error instanceof Error && error.name === 'AbortError') return;
        setLeaderboardError(error instanceof Error ? error.message : 'Leaderboard is unavailable.');
        setLeaders([]);
      })
      .finally(() => {
        if (!controller.signal.aborted) setLeaderboardLoading(false);
      });
    return () => controller.abort();
  }, [activeTab]);

  const currentRoomId = gameStore.activeRoomId;
  const currentRound = gameStore.roundStates[currentRoomId];
  const lang = gameStore.language;

  // Re-arm the win modal whenever a round leaves FINISHED, so it shows again next round.
  useEffect(() => {
    if (currentRound?.phase !== 'FINISHED') setShowWinModal(true);
  }, [currentRound?.phase]);

  // Auto-dismiss the resync banner.
  useEffect(() => {
    if (!resyncMessage) return;
    const timer = setTimeout(() => setResyncMessage(''), 4000);
    return () => clearTimeout(timer);
  }, [resyncMessage]);

  const handleSelectRoom = (roomId: string) => {
    gameStore.setActiveRoom(roomId);
    setActiveTab('game');
  };

  const handleLeaveRoom = () => {
    setActiveTab('lobby');
  };

  const handleResync = async () => {
    if (isResyncing) return;
    setIsResyncing(true);
    setResyncMessage('');
    try {
      await gameStore.refreshPlayerState();
      setResyncMessage(lang === 'am' ? 'የጨዋታ መረጃ ተዘምኗል።' : 'Game state refreshed.');
    } catch (error) {
      setResyncMessage(
        error instanceof Error
          ? error.message
          : (lang === 'am' ? 'የጨዋታ መረጃን ማዘመን አልተቻለም።' : 'Could not refresh game state.')
      );
    } finally {
      setIsResyncing(false);
    }
  };

  if (!gameStore.player.phone || !gameStore.player.phoneVerifiedAt) {
    return (
      <div className="min-h-screen bg-[#0b0416] text-white flex items-center justify-center p-5">
        <div className="w-full max-w-sm rounded-3xl border border-amber-500/30 bg-[#180b30] p-6 text-center space-y-4 shadow-2xl">
          <div className="text-4xl">📱</div>
          <h1 className="text-xl font-black text-amber-300">ምዝገባዎን ያጠናቅቁ</h1>
          <p className="text-sm leading-6 text-purple-200">
            የቴሌግራም መለያዎ ታውቋል። ምዝገባዎን ከዚህ ሳይወጡ ለማጠናቀቅ ከታች ያለውን ቁልፍ ይጫኑና ስልክ ቁጥርዎን ያጋሩ።
          </p>
          <button
            type="button"
            onClick={() => {
              const telegram = window.Telegram?.WebApp;
              if (!telegram?.requestContact) {
                setPhoneCheckMessage('የስልክ ቁጥር ማጋራት በዚህ የቴሌግራም ስሪት አይደገፍም። እባክዎ Telegram ያዘምኑና Mini App-ውን እንደገና ይክፈቱ።');
                return;
              }
              const started = telegram.requestContact((sent) => {
                setPhoneCheckMessage(sent
                  ? 'ስልክ ቁጥሩ ተልኳል። ምዝገባዎን ለማጠናቀቅ “አጋርቻለሁ — እንደገና አረጋግጥ” ይጫኑ።'
                  : 'ስልክ ቁጥሩ አልተጋራም። ሲዘጋጁ እንደገና ይሞክሩ።');
              });
              if (!started) {
                setPhoneCheckMessage('የስልክ ቁጥር ማጋራት መጀመር አልተቻለም። Telegram ውስጥ እንደገና ይክፈቱና ይሞክሩ።');
              }
            }}
            className="w-full rounded-xl border border-amber-400/70 bg-purple-900/70 px-4 py-3 text-sm font-black text-white"
          >
            📱 ስልክ ቁጥር አጋራ
          </button>
          <button
            type="button"
            disabled={isCheckingPhone}
            onClick={async () => {
              setIsCheckingPhone(true);
              setPhoneCheckMessage('');
              try {
                const initData = window.Telegram?.WebApp?.initData || '';
                const botKey = new URLSearchParams(window.location.search).get('bot') || '';
                if (!initData) {
                  setPhoneCheckMessage('እባክዎ በቴሌግራም ሚኒ አፕ ውስጥ እንደገና ይክፈቱ።');
                  return;
                }

                const authResponse = await fetch('/api/player/telegram-auth', {
                  method: 'POST',
                  credentials: 'include',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ initData, ...(botKey ? { botKey } : {}) })
                });
                const authData = await authResponse.json().catch(() => null);

                if (!authResponse.ok || authData?.ok !== true || !authData.player) {
                  throw new Error(authData?.error || 'የቴሌግራም መለያን ማረጋገጥ አልተቻለም።');
                }

                gameStore.setPlayer(authData.player);
                await gameStore.refreshPlayerState();

                if (!gameStore.player.phone || !gameStore.player.phoneVerifiedAt) {
                  setPhoneCheckMessage('ስልክ ቁጥርዎ ገና አልተረጋገጠም። በቦቱ ውይይት ውስጥ “ስልክ ቁጥር አጋራ” ይጫኑና እንደገና ይሞክሩ።');
                }
              } catch (error) {
                setPhoneCheckMessage(error instanceof Error ? error.message : 'ማረጋገጥ አልተሳካም። እባክዎ እንደገና ይሞክሩ።');
              } finally {
                setIsCheckingPhone(false);
              }
            }}
            className="w-full rounded-xl bg-amber-400 px-4 py-3 text-sm font-black text-[#180b30] disabled:opacity-60"
          >
            {isCheckingPhone ? 'በማረጋገጥ ላይ…' : 'አጋርቻለሁ — እንደገና አረጋግጥ'}
          </button>
          {phoneCheckMessage && (
            <p role="status" className="text-xs leading-5 text-amber-200">{phoneCheckMessage}</p>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen bg-[#0b0416] text-white">
      {/* Top Header */}
      <HeaderBar
        onOpenWallet={() => setShowWalletModal(true)}
        onOpenProfile={() => setShowProfileModal(true)}
        onOpenRules={() => setShowRulesModal(true)}
        onRefresh={handleResync}
      />
      {resyncMessage && (
        <div role="status" className="px-4 py-2 text-center text-xs text-amber-200 bg-[#180b30] border-b border-purple-900">
          {resyncMessage}
        </div>
      )}

      {/* Main View Body */}
      <main className="flex-1 flex flex-col pb-[calc(4.5rem+env(safe-area-inset-bottom))]">
        {activeTab === 'lobby' && (
          <LobbyView
            onSelectRoom={handleSelectRoom}
            onOpenRules={() => setShowRulesModal(true)}
          />
        )}

        {activeTab === 'game' && currentRound && (
          <>
            {currentRound.phase === 'SELECTION' && (
              <SelectionView
                roomId={currentRoomId}
                onBackToLobby={() => setActiveTab('lobby')}
                onResync={handleResync}
              />
            )}

            {currentRound.phase === 'COUNTDOWN_END' && (
              <CountdownTransition timerSeconds={currentRound.timerSeconds} />
            )}

            {(currentRound.phase === 'DRAWING' ||
              currentRound.phase === 'FINISHED' ||
              currentRound.phase === 'PAYOUT') && (
              <DrawingView
                roomId={currentRoomId}
                onLeaveRoom={handleLeaveRoom}
                onResync={handleResync}
                onOpenProvablyFair={() => setShowProvablyFairModal(true)}
              />
            )}
          </>
        )}

        {activeTab === 'game' && !currentRoomId && (
          <div className="flex flex-col items-center justify-center flex-1 min-h-[55vh] p-6 text-center bg-[#0d051a]">
            <div className="w-full max-w-sm rounded-2xl border border-amber-500/30 bg-[#180b30] p-5 space-y-3">
              <div className="text-3xl">🎱</div>
              <p role="status" className="text-sm leading-6 text-purple-200">
                {lang === 'am' ? 'ገና ክፍል አልመረጡም። ለመጫወት አንድ ክፍል ይምረጡ።' : 'No room selected yet. Pick a room to start playing.'}
              </p>
              <button
                type="button"
                onClick={handleLeaveRoom}
                className="w-full rounded-xl bg-amber-400 px-4 py-3 text-sm font-black text-[#180b30]"
              >
                {lang === 'am' ? 'ወደ ክፍሎች ሂድ' : 'Go to rooms'}
              </button>
            </div>
          </div>
        )}

        {activeTab === 'game' &&
          currentRoomId &&
          (!currentRound || !ACTIVE_PHASES.includes(currentRound.phase)) && (
            <div className="flex flex-col items-center justify-center flex-1 min-h-[55vh] p-6 text-center bg-[#0d051a]">
              <div className="w-full max-w-sm rounded-2xl border border-amber-500/30 bg-[#180b30] p-5 space-y-3">
                <div className="text-3xl">🎱</div>
                <h2 className="text-lg font-black text-amber-300">
                  {lang === 'am' ? 'የጨዋታ መረጃ በመጫን ላይ ነው' : 'Game state is syncing'}
                </h2>
                <p role="status" className="text-sm leading-6 text-purple-200">
                  {lang === 'am'
                    ? 'ካርቴላዎ ከተረጋገጠ በኋላ ገጹ ካልተከፈተ፣ የጨዋታ መረጃውን ዳግም ያዘምኑ። ተጨማሪ ክፍያ አይፈጽሙ።'
                    : 'If your cartela was confirmed but the game did not appear, refresh the game state. Do not confirm or pay again.'}
                </p>
                <button
                  type="button"
                  disabled={isResyncing}
                  onClick={handleResync}
                  className="w-full rounded-xl bg-amber-400 px-4 py-3 text-sm font-black text-[#180b30] disabled:opacity-60"
                >
                  {isResyncing
                    ? (lang === 'am' ? 'በማዘመን ላይ…' : 'Refreshing…')
                    : (lang === 'am' ? 'ዳግም አዘምን' : 'Refresh game')}
                </button>
                <button
                  type="button"
                  onClick={handleLeaveRoom}
                  className="w-full rounded-xl border border-purple-700 px-4 py-3 text-sm font-bold text-purple-100"
                >
                  {lang === 'am' ? 'ወደ ክፍሎች ተመለስ' : 'Back to rooms'}
                </button>
              </div>
            </div>
          )}


        {activeTab === 'leaderboard' && (
          <div className="p-4 space-y-4">
            <div className="text-center space-y-1">
              <h2 className="text-lg font-black text-white flex items-center justify-center space-x-1.5">
                <Trophy className="w-5 h-5 text-amber-400" />
                <span>{lang === 'am' ? 'የሳምንቱ ምርጥ አሸናፊዎች' : 'Weekly Champions'}</span>
              </h2>
              <p className="text-xs text-purple-300">
                {lang === 'am'
                  ? 'ከፍተኛ የደራሽ ሽልማት የወሰዱ ተጫዋቾች'
                  : 'Highest Derash jackpot winners this week'}
              </p>
            </div>

            <div className="space-y-2 max-w-sm mx-auto">
              {leaderboardLoading && <p className="text-center text-xs text-purple-300">የአሸናፊዎችን መረጃ በመጫን ላይ…</p>}
              {leaderboardError && <p role="status" className="rounded-xl border border-amber-500/40 bg-amber-500/10 p-3 text-xs text-amber-100">{leaderboardError}</p>}
              {!leaderboardLoading && !leaderboardError && leaders.length === 0 && (
                <p className="rounded-xl border border-purple-900 bg-[#180b30] p-4 text-center text-xs text-purple-300">
                  {lang === 'am' ? 'በዚህ ሳምንት የተመዘገበ የሽልማት ክፍያ የለም።' : 'No verified winner payouts have been recorded this week.'}
                </p>
              )}
              {leaders.map((item, index) => (
                <div
                  key={item.id}
                  className="p-3 rounded-2xl flex items-center justify-between border bg-[#180b30] border-purple-900/80"
                >
                  <div className="flex items-center space-x-3">
                    <span className="text-lg">{index < 3 ? ['🥇', '🥈', '🥉'][index] : '🏅'}</span>
                    <div>
                      <span className="font-extrabold text-sm text-white block">{item.name}</span>
                      <span className="text-[10px] text-purple-400">
                        {item.wins} {lang === 'am' ? 'ዙሮች አሸንፈዋል' : 'verified wins this week'}
                      </span>
                    </div>
                  </div>
                  <span className="font-black text-amber-300 text-sm">
                    {item.won.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ETB
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Persistent Bottom Mobile Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#120724]/95 backdrop-blur-md border-t border-[#2d1752] px-4 pt-2 pb-[calc(0.5rem+env(safe-area-inset-bottom))] flex items-center justify-around max-w-lg mx-auto">
        <button
          type="button"
          aria-current={activeTab === 'lobby' ? 'page' : undefined}
          onClick={() => setActiveTab('lobby')}
          className={`flex flex-col items-center py-1 transition-colors ${
            activeTab === 'lobby' ? 'text-amber-400' : 'text-purple-400 hover:text-purple-200'
          }`}
        >
          <LayoutGrid className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] font-bold">
            {lang === 'am' ? 'ክፍሎች' : 'Rooms'}
          </span>
        </button>

        <button
          type="button"
          aria-current={activeTab === 'game' ? 'page' : undefined}
          onClick={() => setActiveTab('game')}
          className={`flex flex-col items-center py-1 transition-colors relative ${
            activeTab === 'game' ? 'text-amber-400' : 'text-purple-400 hover:text-purple-200'
          }`}
        >
          <div className="relative">
            <Radio className="w-5 h-5 mb-0.5" />
            {currentRound?.phase === 'DRAWING' && (
              <span aria-hidden="true" className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-amber-400 rounded-full animate-ping" />
            )}
          </div>
          <span className="text-[10px] font-bold">
            {lang === 'am' ? 'የቀጥታ ጨዋታ' : 'Live Game'}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setShowWalletModal(true)}
          className={`flex flex-col items-center py-1 transition-colors ${
            showWalletModal ? 'text-amber-400' : 'text-purple-400 hover:text-amber-400'
          }`}
        >
          <Wallet className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] font-bold">
            {lang === 'am' ? 'ቦርሳ' : 'Wallet'}
          </span>
        </button>

        <button
          type="button"
          aria-current={activeTab === 'leaderboard' ? 'page' : undefined}
          onClick={() => setActiveTab('leaderboard')}
          className={`flex flex-col items-center py-1 transition-colors ${
            activeTab === 'leaderboard' ? 'text-amber-400' : 'text-purple-400 hover:text-purple-200'
          }`}
        >
          <Trophy className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] font-bold">
            {lang === 'am' ? 'ደረጃዎች' : 'Leaders'}
          </span>
        </button>
      </nav>

      {/* Modals */}
      {showWalletModal && <WalletModal onClose={() => setShowWalletModal(false)} />}
      {showProfileModal && <ProfileModal onClose={() => setShowProfileModal(false)} />}
      {showRulesModal && <RulesModal onClose={() => setShowRulesModal(false)} />}
      {showProvablyFairModal && (
        <ProvablyFairModal
          roomId={currentRoomId}
          onClose={() => setShowProvablyFairModal(false)}
        />
      )}

      {/* Win Celebration Modal if round finished and has winners */}
      {currentRound &&
        currentRound.phase === 'FINISHED' &&
        currentRound.winners.length > 0 &&
        showWinModal && (
          <WinModal
            round={currentRound}
            onPlayAgain={() => {
              setShowWinModal(false);
              // auto re-opens next round
            }}
            onClose={() => setShowWinModal(false)}
          />
        )}
    </div>
  );
};
