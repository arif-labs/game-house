import React from 'react';
import { Sparkles, Zap } from 'lucide-react';
import { gameStore } from '../../services/gameStore';

interface CountdownTransitionProps {
  timerSeconds: number;
}

export const CountdownTransition: React.FC<CountdownTransitionProps> = ({ timerSeconds }) => {
  const lang = gameStore.language;
  const progressPercent = Math.max(10, (timerSeconds / 3) * 100);

  return (
    <div className="flex flex-col items-center justify-center h-[calc(100vh-62px)] px-6 text-center bg-[#0e051c] space-y-6">
      <div className="relative">
        <div className="w-28 h-28 rounded-full bg-gradient-to-tr from-amber-500 via-purple-600 to-indigo-600 p-1 animate-spin duration-1000">
          <div className="w-full h-full rounded-full bg-[#130726] flex items-center justify-center">
            <Zap className="w-12 h-12 text-amber-400 animate-bounce" />
          </div>
        </div>
        <div className="absolute inset-0 rounded-full bg-amber-500/20 blur-xl animate-pulse" />
      </div>

      <div className="space-y-2 max-w-xs">
        <h2 className="text-xl font-black text-white tracking-tight">
          {lang === 'am' ? 'ለሚቀጥለው ቁጥር ተዘጋጁ!' : 'Get ready for the next number!'}
        </h2>
        <p className="text-xs text-purple-200/80">
          {lang === 'am'
            ? 'ካርቴላዎች ተዘግተዋል። የዕጣ ማውጣቱ ሂደት አሁን ይጀምራል!'
            : 'Selections locked. The CSPRNG draw sequence is initiating!'}
        </p>
      </div>

      <div className="w-full max-w-xs space-y-1.5">
        <div className="flex justify-between text-xs font-bold text-amber-400">
          <span>{lang === 'am' ? 'በመጀመር ላይ...' : 'Starting draw...'}</span>
          <span>{timerSeconds}s</span>
        </div>
        <div className="w-full h-3 bg-[#1e0e38] rounded-full overflow-hidden border border-purple-800/60 p-0.5">
          <div
            className="h-full bg-gradient-to-r from-amber-500 to-amber-300 rounded-full transition-all duration-300 ease-linear shadow-lg"
            style={{ width: `${100 - progressPercent}%` }}
          />
        </div>
      </div>

      <div className="flex items-center space-x-2 text-xs text-purple-400 bg-[#1b0d33] px-3.5 py-1.5 rounded-full border border-purple-800">
        <Sparkles className="w-4 h-4 text-amber-400" />
        <span>{lang === 'am' ? 'ደራሽ ሽልማት ተዘጋጅቷል' : 'Derash Prize Pool Locked'}</span>
      </div>
    </div>
  );
};
