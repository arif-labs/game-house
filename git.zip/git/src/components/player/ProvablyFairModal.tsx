import React, { useState } from 'react';
import { X, ShieldCheck, CheckCircle2, Copy, Sparkles, RefreshCw } from 'lucide-react';
import { gameStore } from '../../services/gameStore';
import { sha256Hex } from '../../engine/bingoEngine';

interface ProvablyFairModalProps {
  roomId: string;
  onClose: () => void;
}

export const ProvablyFairModal: React.FC<ProvablyFairModalProps> = ({ roomId, onClose }) => {
  const round = gameStore.roundStates[roomId];
  const lang = gameStore.language;

  const [verifyInput, setVerifyInput] = useState(round?.revealedSeed || 'seed_sample_round_secret_9941');
  const [computedHash, setComputedHash] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const handleCompute = async () => {
    if (!verifyInput) return;
    const hash = await sha256Hex(verifyInput);
    setComputedHash(hash);
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 animate-in fade-in duration-200">
      <div className="bg-[#180b30] border-2 border-purple-700/60 rounded-3xl max-w-sm w-full shadow-2xl overflow-hidden flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="p-4 bg-[#1f0e3e] border-b border-purple-800 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-white text-base">
                {lang === 'am' ? 'ትክክለኛነት ማረጋገጫ' : 'Provably Fair Verification'}
              </h3>
              <span className="text-[11px] text-purple-300">
                {lang === 'am' ? 'የጨዋታው ኳሶች አስቀድመው የተመሰጠሩ ናቸው' : 'CSPRNG Cryptographic Verification'}
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full bg-purple-900/50 hover:bg-purple-800 text-purple-300 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto space-y-3.5 text-xs">
          {/* How it works */}
          <p className="text-purple-300 leading-relaxed text-[11px]">
            {lang === 'am'
              ? 'በኢትዮ ቢንጎ የኳሶቹ ቅደም ተከተል ዙሩ ከመጀመሩ በፊት በ SHA-256 ተመስጥሮ (Commitment Hash) ይፋ ይደረጋል። ዙሩ ሲያልቅ ሚስጥራዊ ቁልፉ (Seed) ይገለጣል። ማንም ውጤቱን መቀየር አይችልም።'
              : 'Every round’s ball sequence is pre-shuffled before the round starts, and its SHA-256 hash is committed publicly. Once the round ends, the secret seed is revealed so any player can independently verify zero tampering.'}
          </p>

          {/* Published Commitment Hash */}
          <div className="p-3 bg-[#120624] rounded-2xl border border-purple-900 space-y-1.5">
            <div className="flex items-center justify-between text-[11px] text-purple-300 font-bold">
              <span>{lang === 'am' ? 'የታተመ የዙሩ Hash' : 'Committed Round Hash'}:</span>
              <button
                onClick={() => handleCopy(round?.seedCommitment || '')}
                className="text-amber-400 hover:text-amber-300 text-[10px] flex items-center"
              >
                <Copy className="w-3 h-3 mr-0.5" />
                {copied ? 'Copied' : 'Copy'}
              </button>
            </div>
            <div className="font-mono text-[10px] text-amber-300 break-all bg-[#1a0c32] p-2 rounded-xl border border-purple-800">
              {round?.seedCommitment || 'b2a1e084ef7909a80c98f82f8a1...'}
            </div>
          </div>

          {/* Revealed Seed */}
          <div className="p-3 bg-[#120624] rounded-2xl border border-purple-900 space-y-1.5">
            <span className="text-[11px] text-purple-300 font-bold block">
              {lang === 'am' ? 'የተገለጠ ሚስጥራዊ ቁልፍ (Revealed Seed)' : 'Revealed Secret Seed'}:
            </span>
            <input
              type="text"
              value={verifyInput}
              onChange={(e) => setVerifyInput(e.target.value)}
              className="w-full bg-[#1a0c32] border border-purple-800 rounded-xl px-2.5 py-2 text-white font-mono text-[11px] focus:outline-none focus:border-amber-400"
            />
          </div>

          <button
            onClick={handleCompute}
            className="w-full py-2.5 rounded-xl bg-purple-800/80 hover:bg-purple-700 text-white font-bold text-xs flex items-center justify-center space-x-1"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>{lang === 'am' ? 'SHA-256 አስላ እና አረጋግጥ' : 'Compute & Compare SHA-256'}</span>
          </button>

          {computedHash && (
            <div className="p-2.5 rounded-xl bg-[#120624] border border-emerald-500/50 space-y-1">
              <span className="text-[10px] text-emerald-400 font-bold flex items-center">
                <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
                Computed SHA-256 Digest:
              </span>
              <div className="font-mono text-[9px] text-emerald-200 break-all">
                {computedHash}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-[#1f0e3e] border-t border-purple-800">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-extrabold text-xs"
          >
            {lang === 'am' ? 'ተመለስ' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
