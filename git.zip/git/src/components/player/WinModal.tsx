import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Trophy, Sparkles, ShieldCheck, ArrowRight, X } from 'lucide-react';
import { gameStore } from '../../services/gameStore';
import { RoundState } from '../../types/bingo';

interface WinModalProps {
  round: RoundState;
  onPlayAgain: () => void;
  onClose: () => void;
}

export const WinModal: React.FC<WinModalProps> = ({ round, onPlayAgain, onClose }) => {
  const lang = gameStore.language;
  const winners = round.winners || [];
  const didIWin = winners.some((w) => w.userId === gameStore.player.id);
  const myWin = winners.find((w) => w.userId === gameStore.player.id);

  useEffect(() => {
    if (didIWin) {
      try {
        confetti({
          particleCount: 120,
          spread: 80,
          origin: { y: 0.6 }
        });
      } catch {}
    }
  }, [didIWin]);

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="relative bg-[#190c30] border-2 border-amber-500/60 rounded-3xl p-5 max-w-sm w-full shadow-2xl text-center space-y-4 overflow-hidden">
        {/* Glow backdrop */}
        <div className="absolute -top-12 -left-12 w-36 h-36 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />

        <button
          onClick={onClose}
          className="absolute top-3 right-3 p-1.5 rounded-full bg-purple-900/60 hover:bg-purple-800 text-purple-300 hover:text-white"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Trophy icon */}
        <div className="relative mx-auto w-20 h-20 rounded-full bg-gradient-to-tr from-amber-500 via-amber-400 to-amber-600 p-1 shadow-lg shadow-amber-500/40">
          <div className="w-full h-full rounded-full bg-[#160a2b] flex items-center justify-center">
            <Trophy className="w-10 h-10 text-amber-400 animate-bounce" />
          </div>
        </div>

        {/* Heading */}
        <div className="space-y-1">
          <span className="text-xs uppercase font-extrabold tracking-widest text-amber-400 flex items-center justify-center space-x-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{round.roundCode} {lang === 'am' ? 'ተጠናቋል' : 'ROUND FINISHED'}</span>
          </span>

          <h2 className="text-2xl font-black text-white">
            {didIWin
              ? lang === 'am'
                ? 'እንኳን ደስ አሎት! አሸንፈዋል!'
                : 'CONGRATULATIONS! YOU WON!'
              : lang === 'am'
              ? 'አሸናፊ ተገኝቷል!'
              : 'WE HAVE A WINNER!'}
          </h2>

          <p className="text-xs text-purple-200">
            {didIWin
              ? lang === 'am'
                ? `የደራሽ ሽልማት ድርሻዎ ${myWin?.prizeAmount.toFixed(0)} ETB ወደ ቦርሳዎ ገብቷል!`
                : `Your share of ${myWin?.prizeAmount.toFixed(0)} ETB is credited to your wallet!`
              : lang === 'am'
              ? 'ለቀጣዩ ዙር አሁኑኑ ተዘጋጁ!'
              : 'Better luck in the next round! Join the action now.'}
          </p>
        </div>

        {/* Winners Card */}
        <div className="bg-[#110522] rounded-2xl p-3 border border-purple-900 space-y-2 text-left">
          <div className="text-[11px] font-bold text-purple-300 uppercase flex justify-between">
            <span>{lang === 'am' ? 'አሸናፊ(ዎች)' : 'Winner(s)'}</span>
            <span className="text-amber-400">
              {round.derashPrize.toFixed(0)} ETB {lang === 'am' ? 'ጠቅላላ ደራሽ' : 'Total Derash'}
            </span>
          </div>

          <div className="space-y-1.5 max-h-32 overflow-y-auto pr-1">
            {winners.map((w, idx) => (
              <div
                key={idx}
                className={`p-2 rounded-xl flex items-center justify-between text-xs border ${
                  w.userId === gameStore.player.id
                    ? 'bg-amber-500/20 border-amber-400/60 text-amber-200'
                    : 'bg-[#1e0e38] border-purple-800 text-purple-200'
                }`}
              >
                <div>
                  <span className="font-extrabold text-white block">
                    {w.isBot ? `BOT · ${w.username}` : w.username} {w.userId === gameStore.player.id ? ' (YOU)' : ''}
                  </span>
                  <span className="text-[10px] text-purple-300">
                    {lang === 'am' ? 'ካርቴላ' : 'Cartela'} #{w.cartelaId} • {w.pattern}
                  </span>
                </div>
                <div className="text-right">
                  <span className="font-black text-amber-300 text-xs">
                    {w.isBot ? `HOUSE +${w.prizeAmount.toFixed(0)} ETB` : `+${w.prizeAmount.toFixed(0)} ETB`}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Provably fair commitment */}
        <div className="text-[10px] text-purple-400 bg-[#120624] p-2 rounded-xl border border-purple-950 flex items-center justify-between">
          <span className="flex items-center">
            <ShieldCheck className="w-3.5 h-3.5 mr-1 text-emerald-400" />
            {lang === 'am' ? 'የተረጋገጠ ሚስጥራዊ ቁልፍ' : 'Provably Fair Seed Revealed'}:
          </span>
          <span className="font-mono text-purple-300 truncate max-w-[120px]">
            {round.revealedSeed || 'seed_verified'}
          </span>
        </div>

        {/* Action Button */}
        <button
          onClick={onPlayAgain}
          className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black text-sm shadow-xl active:scale-95 transition-all flex items-center justify-center space-x-1.5"
        >
          <span>{lang === 'am' ? 'ቀጣዩን ዙር ተጫወት' : 'Play Next Round'}</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
