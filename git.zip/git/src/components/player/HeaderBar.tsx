import React from 'react';
import { Volume2, VolumeX, Globe, Wallet, ShieldCheck, RefreshCw } from 'lucide-react';
import { gameStore } from '../../services/gameStore';
import { audioCaller } from '../../engine/audioCaller';

interface HeaderBarProps {
  onOpenWallet: () => void;
  onOpenProfile: () => void;
  onOpenRules: () => void;
  onRefresh?: () => void;
}

export const HeaderBar: React.FC<HeaderBarProps> = ({
  onOpenWallet,
  onOpenProfile,
  onOpenRules,
  onRefresh
}) => {
  const [sound, setSound] = React.useState(gameStore.soundEnabled);
  const [lang, setLang] = React.useState(gameStore.language);

  const toggleSound = () => {
    const next = !sound;
    setSound(next);
    gameStore.soundEnabled = next;
    audioCaller.setEnabled(next);
  };

  const toggleLang = () => {
    const next = lang === 'am' ? 'en' : 'am';
    setLang(next);
    gameStore.setLanguage(next);
    audioCaller.setLanguage(next);
  };

  return (
    <header className="sticky top-0 z-40 bg-[#130924]/95 backdrop-blur-md border-b border-[#2d1b4e] px-3 py-2.5 flex items-center justify-between">
      {/* Brand & Mini App Pill */}
      <div className="flex items-center space-x-2">
        <button 
          onClick={onOpenProfile} 
          className="relative group focus:outline-none"
          title={lang === 'am' ? 'የተጫዋች መገለጫ' : 'Player Profile'}
        >
          <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-500 to-purple-600 p-0.5 shadow-md">
            <div className="w-full h-full rounded-full bg-[#1b0d33] flex items-center justify-center text-amber-300 font-black text-sm overflow-hidden">
              {(window.Telegram?.WebApp?.initDataUnsafe?.user?.photo_url || gameStore.player.avatarUrl) ? (
                <img
                  src={window.Telegram?.WebApp?.initDataUnsafe?.user?.photo_url || gameStore.player.avatarUrl}
                  alt="Player profile"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              ) : (
                (gameStore.player.fullName || gameStore.player.username || 'EB').slice(0, 2).toUpperCase()
              )}
            </div>
          </div>
          <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-emerald-500 border-2 border-[#130924] rounded-full"></span>
        </button>

        <div className="flex min-w-0 items-center gap-2.5 leading-tight">
          <div className="min-w-0 max-w-[104px]">
            <div className="text-[11px] font-extrabold text-white truncate">
              {gameStore.player.fullName || gameStore.player.username || (lang === 'am' ? 'ተጫዋች' : 'Player')}
            </div>
            <div className="text-[10px] text-purple-300/90 font-medium truncate">
              {gameStore.player.username ? (gameStore.player.username.startsWith('@') ? gameStore.player.username : `@${gameStore.player.username}`) : (lang === 'am' ? 'የተጠቃሚ ስም የለም' : 'No username')}
            </div>
          </div>
          <div className="min-w-0 max-w-[100px] flex flex-col items-center text-center">
            <div className="text-[10px] font-extrabold text-amber-300 truncate w-full">
              Ethio Game House
            </div>
            <div className="text-[10px] font-bold text-purple-200 truncate w-full">
              ኢትዮ ጌም ሀውስ
            </div>
          </div>
        </div>
      </div>

      {/* Right Controls: Wallet Balances & Utilities */}
      <div className="flex items-center space-x-1.5">
        {/* Wallet Balance Pill */}
        <button
          onClick={onOpenWallet}
          className="flex items-center bg-[#22123f] hover:bg-[#2b184e] transition-colors border border-amber-500/30 rounded-full px-2.5 py-1 text-xs text-left group"
        >
          <Wallet className="w-3.5 h-3.5 text-amber-400 mr-1.5 shrink-0" />
          <div className="flex flex-col">
            <span className="text-[11px] font-bold text-amber-300 leading-tight">
              {gameStore.player.mainWalletBalance.toFixed(0)} <span className="text-[9px] font-normal text-amber-200/70">ETB</span>
            </span>
            {gameStore.player.playWalletBalance > 0 && (
              <span className="text-[9px] text-purple-300 leading-none">
                +{gameStore.player.playWalletBalance.toFixed(0)} {lang === 'am' ? 'ቦነስ' : 'bonus'}
              </span>
            )}
          </div>
        </button>

        {/* Audio Toggle */}
        <button
          onClick={toggleSound}
          className={`p-1.5 rounded-full border transition-colors ${
            sound
              ? 'bg-[#2b184e] text-amber-400 border-amber-500/30'
              : 'bg-[#1b0f31] text-gray-500 border-purple-900/50'
          }`}
          title={sound ? (lang === 'am' ? 'ድምፅ አጥፋ' : 'Mute Caller') : (lang === 'am' ? 'ድምፅ አብራ' : 'Unmute Caller')}
        >
          {sound ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
        </button>

        {/* Language Switch */}
        <button
          onClick={toggleLang}
          className="px-2 py-1 rounded-full bg-[#22123f] text-purple-200 border border-purple-800 text-[11px] font-bold hover:bg-[#2f1954] transition-colors"
          title={lang === 'am' ? 'ቋንቋ ቀይር (አማርኛ / English)' : 'Switch Language (Amharic / English)'}
        >
          {lang === 'am' ? 'አማ' : 'EN'}
        </button>

        {/* Refresh Sync */}
        {onRefresh && (
          <button
            onClick={onRefresh}
            className="p-1.5 rounded-full bg-[#22123f] text-purple-300 hover:text-white border border-purple-800 transition-colors"
            title={lang === 'am' ? 'ዳግም አዘምን' : 'Resync State'}
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    </header>
  );
};
