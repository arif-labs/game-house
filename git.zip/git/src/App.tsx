import React, { useEffect, useState } from 'react';
import logoUrl from './assets/ethio-game-house-logo.jpg';
import { Smartphone, Monitor } from 'lucide-react';
import { PlayerApp } from './components/player/PlayerApp';
import { AdminLayout, AdminTab } from './components/admin/AdminLayout';
import { AdminOverview } from './components/admin/AdminOverview';
import { AdminPlatformControl } from './components/admin/AdminPlatformControl';
import { AdminTelegram } from './components/admin/AdminTelegram';
import { AdminLiveRounds } from './components/admin/AdminLiveRounds';
import { AdminSettings } from './components/admin/AdminSettings';
import { AdminRooms } from './components/admin/AdminRooms';
import { AdminAutomatedPlayers } from './components/admin/AdminAutomatedPlayers';
import { AdminCartelas } from './components/admin/AdminCartelas';
import { AdminUsers } from './components/admin/AdminUsers';
import { AdminFinance } from './components/admin/AdminFinance';
import { AdminBonuses } from './components/admin/AdminBonuses';
import { AdminFraud } from './components/admin/AdminFraud';
import { AdminReports } from './components/admin/AdminReports';
import { AdminContent } from './components/admin/AdminContent';
import { AdminSystem } from './components/admin/AdminSystem';
import { AdminTests } from './components/admin/AdminTests';
import { AdminLogin } from './components/admin/AdminLogin';
import { telegramService } from './services/telegramService';

export function App() {
  const isAdminRoute = window.location.pathname.startsWith('/admin');
  const [viewMode, setViewMode] = useState<'mobile' | 'fullscreen'>('mobile');
  const [adminTab, setAdminTab] = useState<AdminTab>('overview');
  const [adminAuthenticated, setAdminAuthenticated] = useState(false);
  const [checkingAdmin, setCheckingAdmin] = useState(isAdminRoute);
  const [telegramAuthChecked, setTelegramAuthChecked] = useState(false);

  useEffect(() => {
    if (!isAdminRoute) {
      const splashMinimum = new Promise<void>((resolve) => {
        window.setTimeout(resolve, 3000);
      });
      Promise.allSettled([telegramService.initialize(), splashMinimum])
        .finally(() => setTelegramAuthChecked(true));
      setCheckingAdmin(false);
      return;
    }
    fetch('/api/admin/me', { credentials: 'include' })
      .then((response) => { if (!response.ok) throw new Error('unauthorized'); return response.json(); })
      .then(() => setAdminAuthenticated(true))
      .catch(() => setAdminAuthenticated(false))
      .finally(() => setCheckingAdmin(false));
  }, [isAdminRoute]);

  const renderAdminContent = () => {
    switch (adminTab) {
      case 'overview': return <AdminOverview />;
      case 'platform': return <AdminPlatformControl />;
      case 'telegram': return <AdminTelegram />;
      case 'live_rounds': return <AdminLiveRounds />;
      case 'settings': return <AdminSettings />;
      case 'rooms': return <AdminRooms />;
      case 'automated_players': return <AdminAutomatedPlayers />;
      case 'cartelas': return <AdminCartelas />;
      case 'users': return <AdminUsers />;
      case 'finance': return <AdminFinance />;
      case 'bonuses': return <AdminBonuses />;
      case 'fraud': return <AdminFraud />;
      case 'reports': return <AdminReports />;
      case 'content': return <AdminContent />;
      case 'system': return <AdminSystem />;
      case 'tests': return <AdminTests />;
      default: return <AdminOverview />;
    }
  };

  if (isAdminRoute) {
    if (checkingAdmin) return <div className="min-h-screen bg-[#07020f] text-white flex items-center justify-center">የአስተዳዳሪ መግቢያን በማረጋገጥ ላይ…</div>;
    if (!adminAuthenticated) return <AdminLogin onAuthenticated={() => setAdminAuthenticated(true)} />;
    return <AdminLayout currentTab={adminTab} onSelectTab={setAdminTab} onExitToPlayer={() => { window.location.href = '/'; }}>{renderAdminContent()}</AdminLayout>;
  }

  if (!isAdminRoute && !telegramAuthChecked) {
    return (
      <div
        style={{
          minHeight: '100vh',
          width: '100%',
          boxSizing: 'border-box',
          background: '#07020f',
          color: '#ffffff',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '0px',
          padding: '24px',
          textAlign: 'center',
          fontFamily: 'Arial, sans-serif',
        }}
      >
        <img
          src={logoUrl}
          alt="Ethio Game House · ኢትዮ ጌም ሀውስ"
          style={{ display: 'block', width: '192px', height: '192px', maxWidth: '65vw', objectFit: 'contain' }}
          onError={(event) => { event.currentTarget.style.display = 'none'; }}
        />
      </div>
    );
  }

  if (!isAdminRoute && (!telegramService.isInsideTelegram || !telegramService.verifiedHmac)) {
    return (
      <div className="min-h-screen bg-[#07020f] text-white flex items-center justify-center p-6">
        <div className="max-w-sm text-center space-y-3">
          <img src={logoUrl} alt="Ethio Game House · ኢትዮ ጌም ሀውስ" className="mx-auto mb-4 w-40 h-40 sm:w-48 sm:h-48 object-contain" onError={(event) => { event.currentTarget.style.display = 'none'; }} />
          <div className="text-3xl">🎱</div>
          <h1 className="text-xl font-black text-amber-300">Ethio Game House · ኢትዮ ጌም ሀውስ</h1>
          <p className="text-sm text-purple-200">ለመለያዎ ደህንነት ጨዋታውን በይፋዊው የቴሌግራም ሚኒ አፕ ብቻ መጫወት ይችላሉ።</p>
          <p className="text-xs text-purple-400">በቴሌግራም ውስጥ የEthio Game House ቦትን ይክፈቱና “ጨዋታ ክፈት” የሚለውን ይጫኑ።</p>
          {telegramService.authError && <p className="text-xs text-amber-200 break-words">Troubleshooting: {telegramService.authError}</p>}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#07020f] text-slate-100 flex flex-col font-sans">
      {/*<header className="h-10 bg-[#120722] border-b border-[#251145] px-3 flex items-center justify-between text-xs shrink-0 select-none z-50">
        <span className="font-extrabold text-amber-400 tracking-tight">Ethio Bingo</span>
        <div className="flex items-center space-x-1 bg-[#190a30] p-1 rounded-xl border border-purple-800/80">
          <button onClick={() => setViewMode('mobile')} className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center space-x-1.5 ${viewMode === 'mobile' ? 'bg-amber-500 text-black' : 'text-purple-300 hover:text-white'}`}><Smartphone className="w-3.5 h-3.5" /><span>Telegram Player</span></button>
          <button onClick={() => setViewMode('fullscreen')} className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center space-x-1.5 ${viewMode === 'fullscreen' ? 'bg-amber-500 text-black' : 'text-purple-300 hover:text-white'}`}><Monitor className="w-3.5 h-3.5" /><span>Fullscreen</span></button>
        </div>
      </header>*/}
      <div className="flex-1 flex flex-col overflow-hidden">
        {viewMode === 'fullscreen' ? (
          <div className="flex-1 overflow-y-auto flex items-center justify-center p-3 sm:p-6 bg-radial from-[#180a32] to-[#07020f]">
            <div className="w-full max-w-[410px] h-[844px] max-h-[92vh] bg-[#0b0416] rounded-[42px] border-4 border-[#2b1652] shadow-2xl overflow-hidden flex flex-col">
              <div className="w-full h-5 bg-[#120724] flex items-center justify-center shrink-0"><div className="w-16 h-3 bg-black rounded-full" /></div>
              <div className="flex-1 overflow-hidden flex flex-col"><PlayerApp /></div>
            </div>
          </div>
        ) : <div className="flex-1 overflow-y-auto max-w-2xl mx-auto w-full border-x border-[#251145]"><PlayerApp /></div>}
      </div>
    </div>
  );
}
export default App;
