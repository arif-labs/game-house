import {
  RoomConfig,
  RoundState,
  CartelaReservation,
  PlayerProfile,
  LedgerEntry,
  AdminUser,
  AuditLogItem,
  DepositRequest,
  WithdrawalRequest,
  FraudAlert,
  SystemAnnouncement
} from '../types/bingo';

export type AdminPlayerRecord = {
  id: string;
  username: string;
  fullName: string | null;
  phone: string | null;
  phoneVerifiedAt: string | null;
  mainWalletBalance: number;
  playWalletBalance: number;
  totalDeposited: number;
  totalWithdrawn: number;
  roundsPlayed: number;
  roundsWon: number;
};

const REQUEST_TIMEOUT_MS = 10_000;
const POLL_MS = 1_000;
const MAX_BACKOFF_MS = 15_000;

type FetchResult = { response: Response; data: any; text: string };

/**
 * fetch with a hard timeout that also covers reading the body, and a JSON parse
 * that never throws (an HTML error page from a proxy becomes `{}`).
 */
async function fetchJson(url: string, init: RequestInit = {}, timeoutMs = REQUEST_TIMEOUT_MS): Promise<FetchResult> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, { credentials: 'include', ...init, signal: controller.signal });
    const text = await response.text();
    let data: any = {};
    try {
      data = text ? JSON.parse(text) : {};
    } catch {
      data = {};
    }
    return { response, data, text };
  } finally {
    clearTimeout(timer);
  }
}

function postJson(url: string, body: unknown, method: 'POST' | 'PUT' = 'POST') {
  return fetchJson(url, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
}

async function getJsonOrNull(url: string): Promise<any | null> {
  try {
    const { response, data } = await fetchJson(url);
    return response.ok ? data : null;
  } catch {
    return null;
  }
}

export class GameStore {
  public rooms: RoomConfig[] = [];
  public player: PlayerProfile = {
    id: '', username: '', fullName: '', telegramId: '', phone: '', avatarUrl: '',
    mainWalletBalance: 0, playWalletBalance: 0, totalDeposited: 0, totalWithdrawn: 0,
    roundsPlayed: 0, roundsWon: 0, isBanned: null, riskScore: null,
    kycStatus: 'unknown', selfExclusionUntil: null, dailyDepositLimit: null
  };
  public activeRoomId = '';
  public isKillSwitchActive = false;
  public currentAdmin: AdminUser = { id: '', name: '', email: '', role: 'support', totpEnabled: false, lastActive: 0 };
  public users: AdminPlayerRecord[] = [];
  public todayPayouts = 0;

  // Server-authoritative room state
  public roundStates: Record<string, RoundState> = {};
  public cartelaReservations: Record<string, CartelaReservation[]> = {};

  // Ledgers & Audits
  public ledger: LedgerEntry[] = [];
  public auditLogs: AuditLogItem[] = [];
  public deposits: DepositRequest[] = [];
  public withdrawals: WithdrawalRequest[] = [];
  public fraudAlerts: FraudAlert[] = [];
  public announcements: SystemAnnouncement[] = [];

  // Client UI Preferences
  public autoMode: boolean = true; // Auto-daub & auto-claim
  public soundEnabled: boolean = true;
  public language: 'am' | 'en' = 'am';
  public userClaimLockedUntil: number = 0; // false claim penalty lock

  public authoritySyncError = '';

  private listeners: Set<() => void> = new Set();
  private version = 0;

  // Polling state
  private pollTimer: ReturnType<typeof setTimeout> | null = null;
  private pollDelay = POLL_MS;
  private stopped = false;
  private authoritySyncInFlight = false;
  private requestSeq = 0;
  private appliedSeq = 0;
  private lastPlayerStateText = '';

  private onFocus = () => { void this.syncNow(); };
  private onVisibility = () => {
    if (document.visibilityState !== 'hidden') void this.syncNow();
  };

  constructor() {
    if (typeof window !== 'undefined' && window.location.pathname.startsWith('/admin')) {
      void this.loadAdminData(true);
    } else {
      this.startAuthoritySync();
    }
  }

  // ---------------------------------------------------------------------------
  // Subscription API (arrow properties so the identity is stable for
  // useSyncExternalStore(gameStore.subscribe, gameStore.getVersion))
  // ---------------------------------------------------------------------------
  public subscribe = (listener: () => void): (() => void) => {
    this.listeners.add(listener);
    return () => { this.listeners.delete(listener); };
  };

  /** Monotonic snapshot: changes whenever the store notifies. */
  public getVersion = (): number => this.version;

  private notify() {
    this.version += 1;
    this.listeners.forEach((fn) => fn());
  }

  /** Stop polling and remove global listeners (tests, HMR, logout). */
  public stop(): void {
    this.stopped = true;
    if (this.pollTimer) clearTimeout(this.pollTimer);
    this.pollTimer = null;
    if (typeof window !== 'undefined') {
      window.removeEventListener('focus', this.onFocus);
      document.removeEventListener('visibilitychange', this.onVisibility);
    }
  }

  // ---------------------------------------------------------------------------
  // Explicit mutators (use these instead of assigning to store fields from UI)
  // ---------------------------------------------------------------------------
  public setLanguage(language: 'am' | 'en'): void {
    this.language = language;
    this.notify();
  }

  public setActiveRoom(roomId: string): void {
    if (this.activeRoomId === roomId) return;
    this.activeRoomId = roomId;
    this.notify();
  }

  public setPlayer(patch: Partial<PlayerProfile>): void {
    this.player = { ...this.player, ...patch };
    this.notify();
  }

  // ---------------------------------------------------------------------------
  // Player authority sync
  // ---------------------------------------------------------------------------
  private startAuthoritySync() {
    this.stopped = false;
    void this.pollOnce();
    // Refresh immediately when the Mini App becomes active again instead of
    // making players reload Telegram to see a new round or their cartela.
    if (typeof window !== 'undefined') {
      window.addEventListener('focus', this.onFocus);
      document.addEventListener('visibilitychange', this.onVisibility);
    }
  }

  private schedulePoll() {
    if (this.stopped) return;
    if (this.pollTimer) clearTimeout(this.pollTimer);
    this.pollTimer = setTimeout(() => { void this.pollOnce(); }, this.pollDelay);
  }

  private async pollOnce() {
    if (this.stopped || this.authoritySyncInFlight) return; // the in-flight run reschedules
    if (typeof document !== 'undefined' && document.visibilityState === 'hidden') {
      this.schedulePoll();
      return;
    }
    this.authoritySyncInFlight = true;
    try {
      const ok = await this.loadPlayerState();
      // Back off while the API is failing (e.g. 401 before login) instead of hammering it every second.
      this.pollDelay = ok ? POLL_MS : Math.min(this.pollDelay * 2, MAX_BACKOFF_MS);
    } finally {
      this.authoritySyncInFlight = false;
      this.schedulePoll();
    }
  }

  private async syncNow() {
    this.pollDelay = POLL_MS;
    if (this.pollTimer) clearTimeout(this.pollTimer);
    await this.pollOnce();
  }

  private setSyncError(message: string) {
    if (this.authoritySyncError === message) return;
    this.authoritySyncError = message;
    this.notify();
  }

  /**
   * Single place that fetches and applies /api/player/state.
   * - never throws unless `throwOnError`
   * - drops responses that arrive after a newer one was already applied
   * - skips notify() when the payload is byte-identical (no idle re-renders)
   */
  private async loadPlayerState(opts: { throwOnError?: boolean } = {}): Promise<boolean> {
    const seq = ++this.requestSeq;
    try {
      const { response, data, text } = await fetchJson('/api/player/state', { cache: 'no-store' });
      if (!response.ok || data?.ok === false) {
        throw new Error(
          data?.error ||
            (response.ok
              ? 'Player state request was rejected.'
              : `Player state request failed (HTTP ${response.status}).`)
        );
      }
      if (seq < this.appliedSeq) return true; // stale response
      this.appliedSeq = seq;
      if (text === this.lastPlayerStateText && !this.authoritySyncError) return true;
      this.lastPlayerStateText = text;
      this.authoritySyncError = '';
      this.applyPlayerState(data);
      this.notify();
      return true;
    } catch (error) {
      const message =
        error instanceof Error
          ? (error.name === 'AbortError' ? 'Player state request timed out.' : error.message)
          : 'Unable to contact the player-state API.';
      this.setSyncError(message);
      if (opts.throwOnError) throw new Error(message);
      return false;
    }
  }

  private applyPlayerState(data: any) {
    if (data.player) this.player = { ...this.player, ...data.player };
    if (typeof data.todayPayouts === 'number') this.todayPayouts = data.todayPayouts;
    if (Array.isArray(data.rooms)) { this.rooms = data.rooms; this.ensureActiveRoom(); }
    if (data.roundStates) this.roundStates = data.roundStates;
    if (data.cartelaReservations) this.cartelaReservations = data.cartelaReservations;
  }

  private ensureActiveRoom() {
    if (!this.rooms.some((room) => room.id === this.activeRoomId)) {
      this.activeRoomId = this.rooms.find((room) => room.status === 'active')?.id ?? this.rooms[0]?.id ?? '';
    }
  }

  private async refreshAuthorityState(throwOnError = false) {
    await this.loadPlayerState({ throwOnError });
  }

  public async refreshPlayerState(): Promise<void> {
    this.pollDelay = POLL_MS;
    await this.refreshAuthorityState(true);
  }

  // ---------------------------------------------------------------------------
  // Player actions
  // ---------------------------------------------------------------------------
  public async selectCartela(roomId: string, cartelaId: number): Promise<{ success: boolean; message: string }> {
    try {
      const { response, data } = await postJson('/api/game/select', { roomId, cartelaId });
      if (!response.ok || !data.success) {
        return { success: false, message: data.error || data.message || 'Unable to select cartela' };
      }

      // Reflect the server-confirmed selection immediately while the authoritative
      // state refresh completes, so the player never needs to reopen the Mini App.
      const currentReservations = this.cartelaReservations[roomId] || [];
      this.cartelaReservations = {
        ...this.cartelaReservations,
        [roomId]: [
          ...currentReservations.filter((reservation) => reservation.userId !== this.player.id),
          {
            cartelaId,
            userId: this.player.id,
            username: this.player.username,
            status: 'confirmed',
            reservedAt: Date.now(),
          },
        ],
      };
      this.lastPlayerStateText = ''; // force the next server snapshot to be applied
      this.notify();
      await this.refreshAuthorityState();
      return { success: true, message: data.message || 'Cartela confirmed' };
    } catch {
      return { success: false, message: 'Network error. Please try again.' };
    }
  }

  public async releaseCartela(roomId: string, cartelaId: number, _isSilentSwitch = false): Promise<boolean> {
    try {
      const { response } = await postJson('/api/game/release', { roomId, cartelaId });
      if (!response.ok) return false;
      await this.refreshAuthorityState();
      return true;
    } catch {
      return false;
    }
  }

  public async claimBingo(roomId: string): Promise<{ success: boolean; message: string }> {
    try {
      const { data } = await postJson('/api/game/claim', { roomId });
      await this.refreshAuthorityState();
      return { success: Boolean(data.success), message: data.message || data.error || 'Claim rejected' };
    } catch {
      return { success: false, message: 'Network error. Please try again.' };
    }
  }

  public async requestDeposit(amount: number, provider: 'Telebirr' | 'CBE Birr', referenceNo: string) {
    const { response, data } = await postJson('/api/player/deposit', { amount, provider, referenceNo });
    if (!response.ok) throw new Error(data.error || 'Deposit request failed');
    return data.deposit;
  }

  public async requestWithdrawal(
    amount: number,
    provider: 'Telebirr' | 'CBE Birr',
    accountNumber: string,
    accountName: string
  ): Promise<{ success: boolean; message: string }> {
    try {
      const { data } = await postJson('/api/player/withdrawal', { amount, provider, accountNumber, accountName });
      await this.refreshAuthorityState();
      return { success: Boolean(data.success), message: data.message || data.error || 'Withdrawal failed' };
    } catch {
      return { success: false, message: 'Network error. Please try again.' };
    }
  }

  // ---------------------------------------------------------------------------
  // ADMIN OPERATIONS
  // ---------------------------------------------------------------------------
  private async loadAdminData(includeKillSwitch: boolean): Promise<void> {
    try {
      if (includeKillSwitch) {
        const state = await getJsonOrNull('/api/admin/state');
        if (!state) return;
        this.isKillSwitchActive = Boolean(state.killSwitch);
      }
      const [game, finance] = await Promise.all([
        getJsonOrNull('/api/admin/game-state'),
        getJsonOrNull('/api/admin/finance-summary')
      ]);
      if (game) {
        if (Array.isArray(game.rooms)) { this.rooms = game.rooms; this.ensureActiveRoom(); }
        if (Array.isArray(game.users)) this.users = game.users;
        if (Array.isArray(game.ledger)) this.ledger = game.ledger;
        if (game.roundStates) this.roundStates = game.roundStates;
        if (game.cartelaReservations) this.cartelaReservations = game.cartelaReservations;
      }
      if (finance) {
        if (Array.isArray(finance.ledger)) this.ledger = finance.ledger;
        if (Array.isArray(finance.deposits)) this.deposits = finance.deposits;
        if (Array.isArray(finance.withdrawals)) this.withdrawals = finance.withdrawals;
      }
      this.notify();
    } catch (error) {
      console.warn('Admin state refresh failed', error);
    }
  }

  private async adminAction(action: string, payload: Record<string, unknown>) {
    const { response, data } = await postJson('/api/admin/game-action', { action, ...payload });
    if (!response.ok) throw new Error(data.error || 'Admin action failed');
    await this.loadAdminData(false);
    return data;
  }

  public async refreshAdminState(): Promise<void> {
    await this.loadAdminData(true);
  }

  public async adminPauseRound(roomId: string, reason: string) {
    try { await this.adminAction('pause', { roomId, reason }); } catch (e) { console.error(e); }
  }

  public async adminExtendSelectionTimer(roomId: string, extraSeconds: number, reason: string) {
    try { await this.adminAction('extend', { roomId, extraSeconds, reason }); } catch (e) { console.error(e); }
  }

  public async adminCancelAndRefundRound(roomId: string, reason: string) {
    try { await this.adminAction('cancel', { roomId, reason }); } catch (e) { console.error(e); }
  }

  public async adminAdjustUserBalance(userId: string, walletType: 'MAIN' | 'PLAY', amount: number, reason: string) {
    try { await this.adminAction('adjust', { userId, walletType, amount, reason }); } catch (e) { console.error(e); }
  }

  public async adminApproveDeposit(depositId: string) {
    try { await this.adminAction('approveDeposit', { depositId }); } catch (e) { console.error(e); }
  }

  public async adminApproveWithdrawal(withdrawalId: string) {
    try { await this.adminAction('approveWithdrawal', { withdrawalId }); } catch (e) { console.error(e); }
  }

  public async adminToggleKillSwitch(reason: string) {
    try {
      const active = !this.isKillSwitchActive;
      const { response } = await postJson('/api/admin/kill-switch', { enabled: active, reason });
      if (!response.ok) throw new Error('Kill switch update failed');
      this.isKillSwitchActive = active;
      this.notify();
    } catch (e) { console.error(e); }
  }

  public async adminUpdateSettings(settings: Partial<RoomConfig>, targetRoomId?: string, reason: string = 'Settings update') {
    try {
      const { response } = await postJson('/api/admin/settings', { settings, targetRoomId, reason }, 'PUT');
      if (!response.ok) throw new Error('Settings update failed');
      await this.loadAdminData(false);
    } catch (e) { console.error(e); }
  }
}

export const gameStore = new GameStore();
