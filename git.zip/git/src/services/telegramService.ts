import { gameStore } from './gameStore';
import { audioCaller } from '../engine/audioCaller';

declare global {
  interface Window {
    Telegram?: {
      WebApp?: {
        initData: string;
        initDataUnsafe?: {
          query_id?: string;
          user?: {
            id: number;
            first_name: string;
            last_name?: string;
            username?: string;
            language_code?: string;
            photo_url?: string;
          };
          auth_date?: number;
          hash?: string;
        };
        version?: string;
        platform?: string;
        isExpanded?: boolean;
        ready: () => void;
        expand: () => void;
        close: () => void;
        openTelegramLink?: (url: string) => void;
        requestContact?: (callback?: (sent: boolean) => void) => boolean;
        setHeaderColor?: (color: string) => void;
        setBackgroundColor?: (color: string) => void;
        HapticFeedback?: {
          impactOccurred: (style: 'light' | 'medium' | 'heavy' | 'rigid' | 'soft') => void;
          notificationOccurred: (type: 'error' | 'success' | 'warning') => void;
          selectionChanged: () => void;
        };
      };
    };
  }
}

class TelegramMiniAppService {
  public isInsideTelegram: boolean = false;
  public verifiedHmac: boolean = false;
  public authError: string = '';
  public platform: string = 'web';

  public async initialize() {
    if (typeof window === 'undefined') return;
    const tg = window.Telegram?.WebApp;
    if (!tg) { this.authError = 'Telegram WebApp SDK is missing on this page.'; return; }

    try {
      tg.ready();
      tg.expand();
      if (tg.setHeaderColor) tg.setHeaderColor('#130924');
      if (tg.setBackgroundColor) tg.setBackgroundColor('#0b0416');

      this.platform = tg.platform || 'web';

      const unsafeUser = tg.initDataUnsafe?.user;
      if (unsafeUser) {
        this.isInsideTelegram = true;
        const fullName = [unsafeUser.first_name, unsafeUser.last_name].filter(Boolean).join(' ');
        gameStore.player.username = unsafeUser.username || `tg_${unsafeUser.id}`;
        gameStore.player.fullName = fullName || gameStore.player.fullName;
        gameStore.player.telegramId = unsafeUser.username ? `@${unsafeUser.username}` : `ID:${unsafeUser.id}`;
        if (unsafeUser.photo_url) {
          gameStore.player.avatarUrl = unsafeUser.photo_url;
        }
      }

      if (!unsafeUser) this.authError = 'Telegram did not provide user details. Open this using the bot Play button inside Telegram.';

      if (tg.initData && tg.initData.length > 0) {
  const botKey = new URLSearchParams(window.location.search).get('bot') || '';
  const response = await fetch('/api/player/telegram-auth', {
    method: 'POST',
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ initData: tg.initData, ...(botKey ? { botKey } : {}) })
  });

  const res = await response.json();

  this.verifiedHmac = response.ok && res?.ok === true;
  this.authError = this.verifiedHmac ? '' : (res?.error || ('Authentication request failed (HTTP ' + response.status + ').'));

  if (this.verifiedHmac && res.player) {
    Object.assign(gameStore.player, res.player);
    const savedLanguage: 'am' | 'en' = res.language === 'en' ? 'en' : 'am';
    gameStore.setLanguage(savedLanguage);
    audioCaller.setLanguage(savedLanguage);
    // The store's initial poll can run before this session is established.
    // Fetch authoritative rooms only after Telegram auth has set the session cookie.
    await gameStore.refreshPlayerState();
  }
      } else {
        this.authError = 'Signed initData is empty. SDK=' + (tg.version || 'unknown') + '; platform=' + (tg.platform || 'unknown') + '; user=' + (unsafeUser ? 'yes' : 'no') + '; initDataLength=' + (tg.initData ? tg.initData.length : 0) + '; host=' + window.location.host + '. Open from the Play button inside the bot chat.';
      }
    } catch (error) {
      this.authError = error instanceof Error
        ? 'Authentication request failed: ' + error.message
        : 'Authentication request failed unexpectedly.';
    }
  }

  public triggerHaptic(type: 'light' | 'medium' | 'heavy' | 'success' | 'warning' | 'error') {
    const haptics = window.Telegram?.WebApp?.HapticFeedback;
    if (!haptics) return;
    try {
      if (type === 'success' || type === 'warning' || type === 'error') {
        haptics.notificationOccurred(type);
      } else {
        haptics.impactOccurred(type);
      }
    } catch {}
  }
}

export const telegramService = new TelegramMiniAppService();

