<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class GameRoomSeeder extends Seeder
{
    public function run(): void
    {
        $patterns = ['any_row', 'any_col', 'any_diagonal', 'four_corners', 'full_house'];

        $rooms = [
            [
                'id' => 'room-1',
                'name' => 'Addis Mini',
                'stake' => 10,
                'amharicName' => 'አዲስ ሚኒ',
                'isVip' => false,
            ],
            [
                'id' => 'room-b61df362-32d3-456b-b9f7-691d08a95353',
                'name' => 'Bole Classic',
                'stake' => 20,
                'amharicName' => 'ቦሌ ክላሲክ',
                'isVip' => false,
            ],
            [
                'id' => 'room-meskel-gold',
                'name' => 'Meskel Gold',
                'stake' => 50,
                'amharicName' => 'መስቀል ጎልድ',
                'isVip' => false,
            ],
            [
                'id' => 'room-entoto-vip',
                'name' => 'Entoto VIP',
                'stake' => 100,
                'amharicName' => 'እንጦጦ ቪአይፒ',
                'isVip' => true,
            ],
        ];

        foreach ($rooms as $room) {
            $existing = DB::table('game_rooms')->where('id', $room['id'])->first();
            $oldConfig = $existing ? (json_decode($existing->config, true) ?: []) : [];
            $config = array_merge($oldConfig, [
                'stake' => $room['stake'],
                'rakePercent' => (float) ($oldConfig['rakePercent'] ?? 10),
                'minPlayers' => (int) ($oldConfig['minPlayers'] ?? 2),
                'maxPlayers' => (int) ($oldConfig['maxPlayers'] ?? 200),
                'selectionSeconds' => (int) ($oldConfig['selectionSeconds'] ?? 40),
                'drawInterval' => (int) ($oldConfig['drawInterval'] ?? 3),
                'enabledPatterns' => $oldConfig['enabledPatterns'] ?? $patterns,
                'isVip' => $room['isVip'],
                'amharicName' => $room['amharicName'],
                'inviteCode' => $oldConfig['inviteCode'] ?? null,
            ]);

            DB::table('game_rooms')->updateOrInsert(
                ['id' => $room['id']],
                [
                    'name' => $room['name'],
                    'status' => 'active',
                    'config' => json_encode($config, JSON_UNESCAPED_UNICODE),
                    'created_at' => $existing->created_at ?? now(),
                    'updated_at' => now(),
                ]
            );
        }

        // Keep the existing Down Town room ID and its historical rounds intact.
        $downTown = DB::table('game_rooms')->where('name', 'Down Town')->first();
        if ($downTown) {
            $config = json_decode($downTown->config, true) ?: [];
            $config['amharicName'] = $config['amharicName'] ?? 'ዳውን ታውን';
            $config['maxPlayers'] = $config['maxPlayers'] ?? 200;
            $config['enabledPatterns'] = $config['enabledPatterns'] ?? $patterns;
            DB::table('game_rooms')->where('id', $downTown->id)->update([
                'status' => 'active',
                'config' => json_encode($config, JSON_UNESCAPED_UNICODE),
                'updated_at' => now(),
            ]);
        }

        // Synchronize only empty, not-yet-started current rounds with the room config.
        // Rounds that already have players or have started keep their original snapshot.
        foreach (DB::table('game_rooms')->get() as $room) {
            $round = DB::table('game_rounds')
                ->where('room_id', $room->id)
                ->orderByDesc('created_at')
                ->first();

            if (
                !$round ||
                $round->phase !== 'SELECTION' ||
                $round->started_at !== null ||
                DB::table('cartela_reservations')->where('round_id', $round->id)->exists()
            ) {
                continue;
            }

            $roomConfig = json_decode($room->config, true) ?: [];
            DB::table('game_rounds')->where('id', $round->id)->update([
                'config' => json_encode(array_merge([
                    'id' => $room->id,
                    'name' => $room->name,
                    'status' => $room->status,
                ], $roomConfig), JSON_UNESCAPED_UNICODE),
                'timer_seconds' => (int) ($roomConfig['selectionSeconds'] ?? 60),
                'updated_at' => now(),
            ]);
        }
    }
}
