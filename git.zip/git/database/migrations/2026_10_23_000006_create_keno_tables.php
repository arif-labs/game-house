<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('keno_seed_states', function (Blueprint $table) {
            $table->string('user_id', 64)->primary();
            $table->text('server_seed');
            $table->string('server_seed_hash', 64);
            $table->unsignedBigInteger('next_nonce')->default(1);
            $table->timestamps();
            $table->foreign('user_id')->references('id')->on('users')->cascadeOnDelete();
        });

        Schema::create('keno_rounds', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('user_id', 64);
            $table->decimal('stake', 18, 2);
            $table->decimal('payout', 18, 2)->default(0);
            $table->decimal('profit', 18, 2)->default(0);
            $table->json('spots');
            $table->json('drawn_numbers');
            $table->json('hits');
            $table->decimal('multiplier', 12, 2)->default(0);
            $table->string('client_seed', 128);
            $table->string('server_seed_hash', 64);
            $table->text('server_seed');
            $table->unsignedBigInteger('nonce');
            $table->string('idempotency_key', 100);
            $table->json('result_json');
            $table->timestamp('created_at')->useCurrent();
            $table->unique(['user_id', 'idempotency_key']);
            $table->index(['user_id', 'created_at']);
            $table->foreign('user_id')->references('id')->on('users')->cascadeOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('keno_rounds');
        Schema::dropIfExists('keno_seed_states');
    }
};
