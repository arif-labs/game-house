<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('game_control_settings', function (Blueprint $table) {
            $table->string('game_key', 32)->primary();
            $table->json('settings');
            $table->timestamps();
        });

        Schema::create('game_control_audits', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('admin_email', 190)->nullable();
            $table->string('game_key', 32);
            $table->string('action', 64);
            $table->json('details')->nullable();
            $table->string('ip_address', 45)->nullable();
            $table->timestamps();
            $table->index(['game_key', 'created_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('game_control_audits');
        Schema::dropIfExists('game_control_settings');
    }
};
