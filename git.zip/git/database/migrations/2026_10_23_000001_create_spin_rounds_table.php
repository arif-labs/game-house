<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('spin_rounds', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('user_id', 64);
            $table->decimal('stake', 18, 2);
            $table->decimal('payout', 18, 2)->default(0);
            $table->decimal('profit', 18, 2)->default(0);
            $table->string('segment_id', 64);
            $table->string('segment_label', 100);
            $table->decimal('multiplier', 10, 2);
            $table->string('client_seed', 128);
            $table->string('server_seed_hash', 64);
            $table->string('server_seed', 64);
            $table->unsignedBigInteger('nonce');
            $table->string('idempotency_key', 100);
            $table->json('result_json')->nullable();
            $table->timestamp('created_at')->useCurrent();
            $table->unique(['user_id', 'idempotency_key'], 'spin_user_idempotency_unique');
            $table->index(['user_id', 'created_at']);
            $table->foreign('user_id')->references('id')->on('users')->cascadeOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('spin_rounds');
    }
};
