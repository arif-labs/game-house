<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('phone', 32)->nullable()->after('username');
            $table->timestamp('phone_verified_at')->nullable()->after('phone');
        });

        Schema::table('game_rounds', function (Blueprint $table) {
            $table->timestamp('started_at')->nullable()->after('phase');
            $table->index(['room_id', 'started_at']);
        });

        Schema::create('telegram_pending_contacts', function (Blueprint $table) {
            $table->string('telegram_id', 64)->primary();
            $table->string('phone', 32);
            $table->timestamp('received_at');
        });
    }

    public function down(): void
    {
        Schema::table('game_rounds', function (Blueprint $table) {
            $table->dropIndex(['room_id', 'started_at']);
            $table->dropColumn('started_at');
        });

        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn(['phone', 'phone_verified_at']);
        });

        Schema::dropIfExists('telegram_pending_contacts');
    }
};
