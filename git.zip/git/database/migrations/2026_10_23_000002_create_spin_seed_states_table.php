<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('spin_seed_states', function (Blueprint $table) {
            $table->string('user_id', 64)->primary();
            $table->string('server_seed', 64);
            $table->string('server_seed_hash', 64);
            $table->unsignedBigInteger('next_nonce')->default(1);
            $table->timestamp('updated_at')->useCurrent();
            $table->foreign('user_id')->references('id')->on('users')->cascadeOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('spin_seed_states');
    }
};
