<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('crash_rounds', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->unsignedBigInteger('round_number')->unique();
            $table->string('status', 16)->default('COUNTDOWN');
            $table->string('server_seed_hash', 64);
            $table->string('server_seed', 64)->nullable();
            $table->decimal('crash_point', 10, 2)->nullable();
            $table->timestamp('started_at')->nullable();
            $table->timestamp('crashed_at')->nullable();
            $table->timestamps();
            $table->index(['status', 'created_at']);
        });

        Schema::create('crash_bets', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('round_id');
            $table->string('user_id', 64);
            $table->decimal('stake', 18, 2);
            $table->decimal('auto_cashout', 10, 2)->nullable();
            $table->decimal('cashout_multiplier', 10, 2)->nullable();
            $table->decimal('payout', 18, 2)->default(0);
            $table->string('status', 16)->default('ACTIVE');
            $table->string('idempotency_key', 100);
            $table->timestamp('cashed_out_at')->nullable();
            $table->timestamps();
            $table->unique(['round_id', 'user_id'], 'crash_round_user_unique');
            $table->unique(['user_id', 'idempotency_key'], 'crash_user_idempotency_unique');
            $table->index(['round_id', 'status']);
            $table->foreign('round_id')->references('id')->on('crash_rounds')->cascadeOnDelete();
            $table->foreign('user_id')->references('id')->on('users')->cascadeOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('crash_bets');
        Schema::dropIfExists('crash_rounds');
    }
};
