<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table): void {
            $table->boolean('is_banned')->default(false);
            $table->timestamp('self_exclusion_until')->nullable();
            $table->decimal('daily_deposit_limit', 18, 2)->nullable();
            $table->timestamp('deposit_limit_set_at')->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table): void {
            $table->dropColumn([
                'is_banned',
                'self_exclusion_until',
                'daily_deposit_limit',
                'deposit_limit_set_at',
            ]);
        });
    }
};
