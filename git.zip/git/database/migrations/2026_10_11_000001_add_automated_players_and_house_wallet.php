<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->boolean('is_bot')->default(false)->after('username');
            $table->index('is_bot');
        });

        Schema::create('house_wallet', function (Blueprint $table) {
            $table->string('id', 16)->primary();
            $table->decimal('balance', 18, 2)->default(0);
            $table->timestamps();
        });

        Schema::create('house_ledger', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('type', 48);
            $table->decimal('amount', 18, 2);
            $table->decimal('balance_after', 18, 2);
            $table->string('reference_id', 128);
            $table->text('description')->nullable();
            $table->timestamps();
            $table->unique(['type', 'reference_id']);
            $table->index('created_at');
        });

        DB::table('house_wallet')->insert([
            'id' => 'main',
            'balance' => 0,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    public function down(): void
    {
        Schema::dropIfExists('house_ledger');
        Schema::dropIfExists('house_wallet');
        Schema::table('users', function (Blueprint $table) {
            $table->dropIndex(['is_bot']);
            $table->dropColumn('is_bot');
        });
    }
};
