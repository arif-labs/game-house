<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasColumn('users', 'is_bot')) {
            Schema::table('users', function (Blueprint $table) {
                $table->boolean('is_bot')->default(false)->after('username');
            });
        }

        $indexes = collect(Schema::getIndexes('users'))->pluck('name')->all();
        if (!in_array('users_is_bot_index', $indexes, true)) {
            Schema::table('users', function (Blueprint $table) {
                $table->index('is_bot');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('users', 'is_bot')) {
            $indexes = collect(Schema::getIndexes('users'))->pluck('name')->all();
            if (in_array('users_is_bot_index', $indexes, true)) {
                Schema::table('users', function (Blueprint $table) {
                    $table->dropIndex('users_is_bot_index');
                });
            }
            Schema::table('users', function (Blueprint $table) {
                $table->dropColumn('is_bot');
            });
        }
    }
};
