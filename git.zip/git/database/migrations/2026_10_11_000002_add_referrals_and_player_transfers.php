<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('referral_code', 24)->nullable()->unique();
            $table->string('referred_by', 64)->nullable()->index();
            $table->timestamp('referral_bonus_awarded_at')->nullable();
        });

        Schema::create('telegram_referrals', function (Blueprint $table) {
            $table->string('telegram_id', 64)->primary();
            $table->string('referral_code', 24);
            $table->timestamps();
            $table->index('referral_code');
        });

        Schema::create('telegram_transfer_sessions', function (Blueprint $table) {
            $table->string('telegram_id', 64)->primary();
            $table->string('state', 24);
            $table->string('recipient_user_id', 64)->nullable();
            $table->decimal('amount', 18, 2)->nullable();
            $table->timestamp('expires_at');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('telegram_transfer_sessions');
        Schema::dropIfExists('telegram_referrals');
        Schema::table('users', function (Blueprint $table) {
            $table->dropUnique(['referral_code']);
            $table->dropIndex(['referred_by']);
            $table->dropColumn(['referral_code', 'referred_by', 'referral_bonus_awarded_at']);
        });
    }
};
