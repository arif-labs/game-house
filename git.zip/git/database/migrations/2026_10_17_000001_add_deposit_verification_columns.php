<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Automatic deposit verification.
 *
 * - reference_key: normalised payment reference (upper-case letters/digits). Unique, so the same
 *   Telebirr / CBE Birr receipt can never be credited twice, even under concurrent requests.
 * - verification_*: what the automatic checker decided and why (shown to admins when a deposit
 *   stays pending and needs a manual look).
 */
return new class extends Migration {
    public function up(): void
    {
        Schema::table('deposits', function (Blueprint $table) {
            if (!Schema::hasColumn('deposits', 'reference_key')) {
                $table->string('reference_key', 128)->nullable()->unique();
            }
            if (!Schema::hasColumn('deposits', 'verification_status')) {
                $table->string('verification_status', 24)->nullable();
            }
            if (!Schema::hasColumn('deposits', 'verification_note')) {
                $table->text('verification_note')->nullable();
            }
            if (!Schema::hasColumn('deposits', 'verified_amount')) {
                $table->decimal('verified_amount', 18, 2)->nullable();
            }
            if (!Schema::hasColumn('deposits', 'verified_at')) {
                $table->timestamp('verified_at')->nullable();
            }
            if (!Schema::hasColumn('deposits', 'verification_attempts')) {
                $table->unsignedSmallInteger('verification_attempts')->default(0);
            }
            if (!Schema::hasColumn('deposits', 'last_verification_at')) {
                $table->timestamp('last_verification_at')->nullable();
            }
        });

        // Backfill the key for existing rows. Only the first row of a duplicated reference gets the key,
        // so the unique index can be created without failing on old duplicate data.
        $seen = [];
        DB::table('deposits')->whereNull('reference_key')->orderBy('created_at')->get(['id', 'reference_no'])
            ->each(function ($row) use (&$seen) {
                $key = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string) $row->reference_no));
                if ($key === '' || isset($seen[$key])) {
                    return;
                }
                $seen[$key] = true;
                DB::table('deposits')->where('id', $row->id)->update(['reference_key' => $key]);
            });
    }

    public function down(): void
    {
        Schema::table('deposits', function (Blueprint $table) {
            foreach (['reference_key'] as $column) {
                if (Schema::hasColumn('deposits', $column)) {
                    $table->dropUnique(['reference_key']);
                }
            }
            $drop = array_filter(
                ['reference_key', 'verification_status', 'verification_note', 'verified_amount', 'verified_at', 'verification_attempts', 'last_verification_at'],
                fn ($c) => Schema::hasColumn('deposits', $c)
            );
            if ($drop) {
                $table->dropColumn(array_values($drop));
            }
        });
    }
};
