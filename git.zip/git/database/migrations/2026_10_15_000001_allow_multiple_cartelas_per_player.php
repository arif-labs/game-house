<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * A player can reserve multiple cartelas in one round.
     * Keep cartela uniqueness per round, but remove the one-cartela-per-player constraint.
     */
    public function up(): void
    {
        Schema::table('cartela_reservations', function (Blueprint $table) {
            $table->dropUnique(['round_id', 'user_id']);
            $table->index(['round_id', 'user_id'], 'cartela_reservations_round_user_index');
        });
    }

    public function down(): void
    {
        Schema::table('cartela_reservations', function (Blueprint $table) {
            $table->dropIndex('cartela_reservations_round_user_index');
            $table->unique(['round_id', 'user_id']);
        });
    }
};
