(() => {
  const params = new URLSearchParams(window.location.search);
  const language = params.get('lang') || 'am';
  document.documentElement.lang = language === 'am' ? 'am' : 'en';
  if (language !== 'am') return;

  // Shared Amharic locale for the original Spin, Crash and Keno game screens.
  // This layer only localizes visible copy; game rules, requests and outcomes are untouched.
  const am = {
    'ETHIO SPIN': 'ኢትዮ ስፒን',
    'ETHIO CRASH': 'ኢትዮ ክራሽ',
    'ETHIO KENO': 'ኢትዮ ኬኖ',
    'Spin': 'ስፒን',
    'Crash': 'ክራሽ',
    'Keno': 'ኬኖ',
    'Shared Play Wallet': 'የጨዋታ ቦርሳ',
    'Play Wallet': 'የጨዋታ ቦርሳ',
    'Your stake and result are settled by the server.': 'ውርርድዎና ውጤቱ በሰርቨሩ ይረጋገጣሉ።',
    'Refresh balance': 'ቀሪ ሂሳብ አድስ',
    'Refresh': 'አድስ',
    'Stake (ETB)': 'ውርርድ (ETB)',
    'Stake amount': 'የውርርድ መጠን',
    'Spin for': 'ስፒን ለ',
    'Spinning…': 'በስፒን ላይ…',
    'Result': 'ውጤት',
    'Net': 'ትርፍ/ኪሳራ',
    'Pre-spin fairness commitment': 'ከስፒን በፊት የፍትሃዊነት ማረጋገጫ',
    'Loading commitment…': 'የማረጋገጫ መረጃ በመጫን ላይ…',
    'The server records the result before the animation finishes.': 'ሰርቨሩ እነማው ከማለቁ በፊት ውጤቱን ይመዘግባል።',
    'Published odds & payout table': 'የታተመ የዕድልና የክፍያ ሰንጠረዥ',
    'Theoretical RTP:': 'የቲዎሪ የመመለሻ መጠን፦',
    'RTP is the long-run theoretical payout from the published weights and multipliers, not a promise about any individual result.': 'RTP በረጅም ጊዜ የሚጠበቀውን ክፍያ ያመለክታል፤ ለእያንዳንዱ ውጤት ዋስትና አይደለም።',
    'Server calculates the result and records wallet changes before the animation finishes.': 'ሰርቨሩ እነማው ከማለቁ በፊት ውጤቱን ያሰላል እና የቦርሳ ለውጦችን ይመዘግባል።',
    'Loading your player wallet…': 'የተጫዋች ቦርሳዎን በመጫን ላይ…',
    'Spin is temporarily unavailable until the house wallet has enough reserve to cover the maximum possible payout.': 'የቤቱ ቦርሳ ከፍተኛውን ክፍያ ለመሸፈን በቂ ገንዘብ እስኪኖረው ድረስ ስፒን ለጊዜው አይገኝም።',
    'Last result': 'የመጨረሻ ውጤት',
    'Verify this result': 'ይህን ውጤት አረጋግጥ',
    'Play responsibly. Every wager can be lost; past results do not predict future draws.': 'በኃላፊነት ይጫወቱ። የውርርድ ገንዘብ ሊጠፋ ይችላል፤ ያለፉ ውጤቶች የወደፊቱን አይተነብዩም።',

    'Rise fast · Cash out smart': 'በፍጥነት ይጨምራል · በጥበብ ያውጡ',
    'SERVER LIVE': 'ሰርቨሩ በቀጥታ ላይ ነው',
    'Live arena': 'የቀጥታ ጨዋታ ሜዳ',
    'Catch the climb.': 'ጭማሪውን ይከታተሉ።',
    'Beat the crash.': 'ከመውደቁ በፊት ያውጡ።',
    'Place your stake before takeoff, watch the multiplier rise, and cash out before the rocket disappears.': 'ጨዋታው ከመጀመሩ በፊት ውርርድ ያስገቡ፣ ማባዣውን ይከታተሉ እና ሮኬቱ ከመውደቁ በፊት ገንዘብዎን ያውጡ።',
    'Fairness committed': 'የፍትሃዊነት ማረጋገጫ ተመዝግቧል',
    'TAKEOFF IN': 'ጨዋታው የሚጀምረው በ',
    'CASH OUT BEFORE CRASH': 'ከመውደቁ በፊት ገንዘብዎን ያውጡ',
    'CRASHED AT': 'የወደቀበት ማባዣ',
    'RECENT CRASHES': 'የቅርብ ጊዜ ውድቀቶች',
    'Fairness': 'ፍትሃዊነት',
    'Each round publishes a SHA-256 commitment before betting. After the round ends, its seed is revealed so the result can be checked.': 'እያንዳንዱ ዙር ውርርድ ከመጀመሩ በፊት SHA-256 ማረጋገጫ ያትማል። ዙሩ ሲያበቃ ውጤቱ እንዲፈተሽ ሚስጥራዊ ቁልፉ ይገለጣል።',
    'Waiting for round commitment…': 'የዙሩን ማረጋገጫ በመጠበቅ ላይ…',
    'YOUR BET': 'የእርስዎ ውርርድ',
    'ETB · PLAY WALLET': 'ETB · የጨዋታ ቦርሳ',
    'Stake amount': 'የውርርድ መጠን',
    'Server auto cash-out': 'በሰርቨር ራስ-ሰር ገንዘብ ማውጣት',
    'Potential payout at': 'ሊከፈል የሚችል መጠን በ',
    'Maximum round multiplier': 'የዙሩ ከፍተኛ ማባዣ',
    'Processing…': 'በማስኬድ ላይ…',
    'Cash out': 'ገንዘብ አውጣ',
    'CASH OUT NOW': 'አሁን ገንዘብ አውጣ',
    'WAITING FOR TAKEOFF': 'ጨዋታውን በመጠበቅ ላይ',
    'Please wait…': 'እባክዎ ይጠብቁ…',
    'Game disabled': 'ጨዋታው ተዘግቷል',
    'Bets open until takeoff': 'ጨዋታው እስኪጀምር ውርርድ ክፍት ነው',
    'PLAYERS IN ROUND': 'በዙሩ ውስጥ ያሉ ተጫዋቾች',
    'Be the first to join this flight.': 'በዚህ ዙር መጀመሪያ ይቀላቀሉ።',
    'IN FLIGHT': 'በጨዋታ ላይ',
    'CRASHED': 'ወድቋል',
    'CASHED OUT': 'ገንዘብ ወጥቷል',
    'BET': 'ውርርድ',
    'Cash-out anytime': 'በማንኛውም ጊዜ ገንዘብ ያውጡ',
    'Cash out anytime': 'በማንኛውም ጊዜ ገንዘብ ያውጡ',
    'SHA-256 commitment · server-authoritative': 'SHA-256 ማረጋገጫ · በሰርቨር የተቆጣጠረ',

    'Pick up to 10 numbers. Server draws 20 unique numbers from 1–80.': 'እስከ 10 ቁጥሮች ይምረጡ። ሰርቨሩ ከ1–80 ውስጥ 20 የተለያዩ ቁጥሮችን ያወጣል።',
    'Pick numbers': 'ቁጥሮችን ይምረጡ',
    'Draw tray ·': 'የወጡ ቁጥሮች ·',
    'hits': 'ተዛምደዋል',
    'Clear': 'አጽዳ',
    'Auto Pick': 'በራስ-ሰር ምረጥ',
    'Draw 20 balls ·': '20 ቁጥሮችን አውጣ ·',
    'Drawing…': 'ቁጥሮችን በማውጣት ላይ…',
    'Loading Keno and wallet…': 'ኬኖንና ቦርሳውን በመጫን ላይ…',
    'Keno is unavailable until the house reserve can cover the maximum possible payout. Contact the administrator.': 'የቤቱ ቀሪ ገንዘብ ከፍተኛውን ክፍያ መሸፈን እስኪችል ድረስ ኬኖ አይገኝም። አስተዳዳሪውን ያነጋግሩ።',
    'Keno is disabled by the administrator.': 'ኬኖ በአስተዳዳሪው ተዘግቷል።',
    'Hits': 'የተዛመዱ',
    'Payout': 'ክፍያ',
    'Last result': 'የመጨረሻ ውጤት',
    'Hide': 'ደብቅ',
    'Show': 'አሳይ',
    'fairness data': 'የፍትሃዊነት መረጃ',
    'Verify this draw': 'ይህን ማውጣት አረጋግጥ',
    'Recent rounds': 'የቅርብ ጊዜ ዙሮች',
    'Completed rounds will appear here.': 'የተጠናቀቁ ዙሮች እዚህ ይታያሉ።',
    'Play responsibly. Every wager can be lost; past results do not predict future draws.': 'በኃላፊነት ይጫወቱ። የውርርድ ገንዘብ ሊጠፋ ይችላል፤ ያለፉ ውጤቶች የወደፊቱን አይተነብዩም።'
  };

  const translateTextNode = (node) => {
    const original = node.nodeValue;
    if (!original || !original.trim()) return;
    const trimmed = original.trim();
    let translated = am[trimmed];
    if (!translated) {
      // Translate common dynamic fragments while preserving numbers and punctuation.
      const patterns = [
        [/^Stake \(ETB\)$/, 'ውርርድ (ETB)'],
        [/^Min$/, 'ዝቅተኛ'],
        [/^Max$/, 'ከፍተኛ'],
        [/^Per$/, 'ለእያንዳንዱ'],
        [/^Choose numbers to see possible payouts\.$/, 'ሊከፈሉ የሚችሉ ክፍያዎችን ለማየት ቁጥሮችን ይምረጡ።'],
        [/^Payout table ·$/, 'የክፍያ ሰንጠረዥ ·'],
        [/^ETB ·$/, 'ETB ·'],
        [/^Cash out before crash$/, 'ከመውደቁ በፊት ገንዘብ ያውጡ'],
        [/^Shared Play Wallet$/, 'የጨዋታ ቦርሳ'],
        [/^Draw 20 balls ·$/, '20 ቁጥሮችን አውጣ ·'],
        [/^Choose between 1 and 10 numbers\.$/, 'ከ1 እስከ 10 ቁጥሮች ይምረጡ።'],
        [/^Check your stake, Play Wallet balance, and current limits\.$/, 'ውርርድዎን፣ የጨዋታ ቦርሳ ቀሪ ሂሳብዎንና ገደቦቹን ያረጋግጡ።']
      ];
      for (const [pattern, value] of patterns) {
        if (pattern.test(trimmed)) { translated = value; break; }
      }
    }
    if (translated && translated !== trimmed) {
      const leading = original.match(/^\s*/)?.[0] || '';
      const trailing = original.match(/\s*$/)?.[0] || '';
      node.nodeValue = leading + translated + trailing;
    }
  };

  const translateAttributes = (element) => {
    for (const attr of ['placeholder', 'title', 'aria-label']) {
      const value = element.getAttribute?.(attr);
      if (value && am[value]) element.setAttribute(attr, am[value]);
    }
  };

  const translateTree = (root) => {
    if (root.nodeType === Node.TEXT_NODE) {
      translateTextNode(root);
      return;
    }
    if (root.nodeType !== Node.ELEMENT_NODE && root !== document) return;
    if (root.nodeType === Node.ELEMENT_NODE) translateAttributes(root);
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) translateTextNode(node);
    if (root.querySelectorAll) root.querySelectorAll('input,button,[title],[aria-label]').forEach(translateAttributes);
  };

  const start = () => {
    translateTree(document.body);
    const observer = new MutationObserver((records) => {
      for (const record of records) {
        if (record.type === 'characterData') translateTextNode(record.target);
        for (const node of record.addedNodes || []) translateTree(node);
        if (record.type === 'attributes') translateAttributes(record.target);
      }
    });
    observer.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['placeholder', 'title', 'aria-label'] });
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true });
  else start();
})();