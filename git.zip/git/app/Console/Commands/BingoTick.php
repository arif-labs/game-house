<?php
namespace App\Console\Commands;

use App\Services\GameService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class BingoTick extends Command
{
    protected $signature = 'beteseb:tick';
    protected $description = 'Advance active Ethiobingo rounds';

    public function handle(GameService $game): int
    {
        // Heartbeat so the admin dashboard can tell whether the scheduler is actually running.
        try {
            \Illuminate\Support\Facades\Cache::put('beteseb:tick:last', now()->timestamp, 3600);
        } catch (\Throwable $e) {
            // Never let diagnostics stop the game loop.
        }

        // Advance every active room, not only the default room-1.
        foreach ($game->rooms() as $room) {
            if (($room['status'] ?? 'active') !== 'active') {
                continue;
            }

            // One failing room must never stop the remaining rooms from advancing.
            try {
                $game->advance($room['id']);
            } catch (\Throwable $e) {
                Log::error('beteseb:tick failed for room ' . $room['id'] . ': ' . $e->getMessage());
            }
        }

        return self::SUCCESS;
    }
}
