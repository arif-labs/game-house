<?php

namespace App\Http\Controllers;

use App\Services\GameControlService;
use App\Services\HouseWalletService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;

class KenoController
{
    private const MAX_DRAW = 20;
    private const MAX_SPOTS = 10;
    private const MAX_MULTIPLIER = 50000.0;

    public function __construct(
        private HouseWalletService $houseWallet,
        private GameControlService $controls
    ) {}

    private function paytable(): array
    {
        return [
            1 => [1 => 3.5],
            2 => [1 => 1, 2 => 9],
            3 => [2 => 2.5, 3 => 45],
            4 => [2 => 1, 3 => 5, 4 => 90],
            5 => [3 => 2, 4 => 12, 5 => 800],
            6 => [3 => 1, 4 => 4, 5 => 75, 6 => 1600],
            7 => [3 => 1, 4 => 2, 5 => 20, 6 => 400, 7 => 5000],
            8 => [4 => 2, 5 => 12, 6 => 90, 7 => 1500, 8 => 10000],
            9 => [4 => 1, 5 => 6, 6 => 40, 7 => 350, 8 => 4000, 9 => 25000],
            10 => [0 => 2, 5 => 3, 6 => 22, 7 => 100, 8 => 1000, 9 => 4500, 10 => 50000],
        ];
    }

    private function settings(): array
    {
        return $this->controls->get('keno');
    }

    private function getMaxStake(array $settings): float
    {
        $reserveLimit = floor(max(0, $this->houseWallet->balance()) / self::MAX_MULTIPLIER * 100) / 100;
        return min((float) ($settings['maxStake'] ?? 100), 100.0, $reserveLimit);
    }

    public function config(Request $request)
    {
        $userId = (string) $request->attributes->get('player_id');
        $user = DB::table('users')->where('id', $userId)->where('is_bot', false)->first();
        if (!$user) return response()->json(['ok' => false, 'error' => 'Player account is unavailable.'], 401);

        $seed = bin2hex(random_bytes(32));
        DB::table('keno_seed_states')->insertOrIgnore([
            'user_id' => $userId, 'server_seed' => $seed,
            'server_seed_hash' => hash('sha256', $seed), 'next_nonce' => 1,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $seedState = DB::table('keno_seed_states')->where('user_id', $userId)->first();
        $settings = $this->settings();
        $maxStake = $this->getMaxStake($settings);
        $minStake = (float) ($settings['minStake'] ?? 1);
        return response()->json([
            'ok' => true, 'currency' => 'ETB',
            'enabled' => (bool) ($settings['enabled'] ?? false),
            'minStake' => $minStake, 'maxStake' => $maxStake,
            'canPlay' => (bool) ($settings['enabled'] ?? false) && $maxStake >= $minStake,
            'balance' => (float) $user->play_balance,
            'serverSeedHash' => $seedState->server_seed_hash,
            'nextNonce' => (int) $seedState->next_nonce,
            'paytable' => $this->paytable(),
            'drawCount' => self::MAX_DRAW,
            'numberCount' => 80,
            'maxSpots' => self::MAX_SPOTS,
        ]);
    }

    private function drawNumbers(string $serverSeed, string $clientSeed, int $nonce): array
    {
        $pool = range(1, 80);
        // Deterministic Fisher-Yates shuffle, with a fresh HMAC stream per index.
        for ($i = count($pool) - 1; $i > 0; $i--) {
            $digest = hash_hmac('sha256', $clientSeed . ':' . $nonce . ':' . $i, $serverSeed);
            $j = (int) (hexdec(substr($digest, 0, 8)) % ($i + 1));
            [$pool[$i], $pool[$j]] = [$pool[$j], $pool[$i]];
        }
        return array_slice($pool, 0, self::MAX_DRAW);
    }

    public function play(Request $request)
    {
        $userId = (string) $request->attributes->get('player_id');
        $rawStake = $request->input('stake');
        $stakeValue = is_numeric($rawStake) ? (float) $rawStake : NAN;
        $spots = $request->input('spots');
        $clientSeed = trim((string) $request->input('clientSeed', ''));
        $key = trim((string) $request->input('idempotencyKey', ''));
        $committedHash = trim((string) $request->input('serverSeedHash', ''));
        $settings = $this->settings();
        $minStake = (float) ($settings['minStake'] ?? 1);
        // Validate configured limits first; reserve is checked after idempotency replay inside the transaction.
        $maxStake = min((float) ($settings['maxStake'] ?? 100), 100.0);

        if (!(bool) ($settings['enabled'] ?? false)) {
            return response()->json(['ok' => false, 'error' => 'Keno is temporarily disabled by the administrator.'], 423);
        }
        if (!is_finite($stakeValue) || $stakeValue < $minStake || $stakeValue > $maxStake) {
            return response()->json(['ok' => false, 'error' => 'Stake is outside current limits or the house payout reserve is insufficient.'], 422);
        }
        if (!is_array($spots) || count($spots) < 1 || count($spots) > self::MAX_SPOTS) {
            return response()->json(['ok' => false, 'error' => 'Choose between 1 and 10 unique numbers.'], 422);
        }
        $normalizedSpots = array_map(static fn ($n) => filter_var($n, FILTER_VALIDATE_INT) !== false ? (int) $n : 0, $spots);
        if (count(array_unique($normalizedSpots)) !== count($normalizedSpots) || min($normalizedSpots) < 1 || max($normalizedSpots) > 80) {
            return response()->json(['ok' => false, 'error' => 'Keno spots must be unique numbers from 1 to 80.'], 422);
        }
        sort($normalizedSpots);
        if ($clientSeed === '' || strlen($clientSeed) > 128 ||
            !preg_match('/^[A-Za-z0-9_-]{8,100}$/', $key) ||
            !preg_match('/^[a-f0-9]{64}$/', $committedHash)) {
            return response()->json(['ok' => false, 'error' => 'Invalid Keno request. Refresh game settings and try again.'], 422);
        }
        $stake = round($stakeValue, 2);

        try {
            $outcome = DB::transaction(function () use ($userId, $stake, $normalizedSpots, $clientSeed, $key, $committedHash) {
                $settingsNow = $this->settings();
                if (!(bool) ($settingsNow['enabled'] ?? false)) throw new RuntimeException('Keno is temporarily disabled by the administrator.');
                if ($stake < (float) ($settingsNow['minStake'] ?? 1) || $stake > min((float) ($settingsNow['maxStake'] ?? 100), 100.0)) {
                    throw new RuntimeException('Stake is outside current limits or the house payout reserve is insufficient.');
                }

                $existing = DB::table('keno_rounds')->where('user_id', $userId)->where('idempotency_key', $key)->first();
                if ($existing) {
                    $sameRequest = abs((float) $existing->stake - $stake) < 0.000001
                        && hash_equals((string) $existing->client_seed, $clientSeed)
                        && hash_equals((string) $existing->server_seed_hash, $committedHash)
                        && $normalizedSpots === (json_decode($existing->spots, true) ?: []);
                    if (!$sameRequest) throw new RuntimeException('This request key was already used for a different Keno request.');
                    return json_decode($existing->result_json, true);
                }

                $user = DB::table('users')->where('id', $userId)->lockForUpdate()->first();
                if (!$user || (bool) ($user->is_bot ?? false)) throw new RuntimeException('Player account is unavailable.');
                $seedState = DB::table('keno_seed_states')->where('user_id', $userId)->lockForUpdate()->first();
                if (!$seedState || !hash_equals((string) $seedState->server_seed_hash, $committedHash)) {
                    throw new RuntimeException('Fairness commitment changed. Refresh Keno settings and try again.');
                }
                if ((float) $user->play_balance + 0.000001 < $stake) {
                    throw new RuntimeException('Insufficient Play Wallet balance. Move funds from your Main Wallet first.');
                }

                // Re-check the full maximum theoretical payout under lock; no round can overbook the reserve.
                $maxPayout = round($stake * self::MAX_MULTIPLIER, 2);
                if ($this->houseWallet->balance() + 0.000001 < $maxPayout) {
                    throw new RuntimeException('Keno is unavailable because the house payout reserve is too low for this stake.');
                }

                $nonce = (int) $seedState->next_nonce;
                $serverSeed = (string) $seedState->server_seed;
                $serverSeedHash = (string) $seedState->server_seed_hash;
                $drawn = $this->drawNumbers($serverSeed, $clientSeed, $nonce);
                $hits = array_values(array_intersect($normalizedSpots, $drawn));
                sort($hits);
                $hitCount = count($hits);
                $multiplier = (float) ($this->paytable()[count($normalizedSpots)][$hitCount] ?? 0);
                $payout = round($stake * $multiplier, 2);
                $profit = round($payout - $stake, 2);
                $afterStake = round((float) $user->play_balance - $stake, 2);
                $after = round($afterStake + $payout, 2);
                $roundId = (string) Str::uuid();
                $now = now();

                DB::table('users')->where('id', $userId)->update(['play_balance' => $after, 'updated_at' => $now]);
                DB::table('ledger')->insert([
                    'id' => (string) Str::uuid(), 'user_id' => $userId, 'type' => 'KENO_STAKE',
                    'wallet_type' => 'PLAY', 'amount' => -$stake, 'balance_after' => $afterStake,
                    'reference_id' => $roundId, 'description' => 'Keno stake',
                    'created_at' => $now, 'updated_at' => $now,
                ]);
                if ($payout > 0) {
                    DB::table('ledger')->insert([
                        'id' => (string) Str::uuid(), 'user_id' => $userId, 'type' => 'KENO_PAYOUT',
                        'wallet_type' => 'PLAY', 'amount' => $payout, 'balance_after' => $after,
                        'reference_id' => $roundId, 'description' => 'Keno payout (' . $hitCount . ' hits)',
                        'created_at' => $now, 'updated_at' => $now,
                    ]);
                }
                $this->houseWallet->post('KENO_STAKE', $stake, $roundId, 'Keno stake received');
                if ($payout > 0) $this->houseWallet->post('KENO_PAYOUT', -$payout, $roundId, 'Keno payout to player');

                $nextSeed = bin2hex(random_bytes(32));
                $nextHash = hash('sha256', $nextSeed);
                DB::table('keno_seed_states')->where('user_id', $userId)->update([
                    'server_seed' => $nextSeed, 'server_seed_hash' => $nextHash,
                    'next_nonce' => $nonce + 1, 'updated_at' => $now,
                ]);

                $result = [
                    'roundId' => $roundId, 'stake' => $stake, 'payout' => $payout,
                    'profit' => $profit, 'multiplier' => $multiplier, 'spots' => $normalizedSpots,
                    'drawnNumbers' => $drawn, 'hits' => $hits, 'hitCount' => $hitCount,
                    'balance' => $after, 'serverSeedHash' => $serverSeedHash,
                    'serverSeed' => $serverSeed, 'nextServerSeedHash' => $nextHash,
                    'clientSeed' => $clientSeed, 'nonce' => $nonce,
                ];
                DB::table('keno_rounds')->insert([
                    'id' => $roundId, 'user_id' => $userId, 'stake' => $stake,
                    'payout' => $payout, 'profit' => $profit,
                    'spots' => json_encode($normalizedSpots, JSON_THROW_ON_ERROR),
                    'drawn_numbers' => json_encode($drawn, JSON_THROW_ON_ERROR),
                    'hits' => json_encode($hits, JSON_THROW_ON_ERROR), 'multiplier' => $multiplier,
                    'client_seed' => $clientSeed, 'server_seed_hash' => $serverSeedHash,
                    'server_seed' => $serverSeed, 'nonce' => $nonce, 'idempotency_key' => $key,
                    'result_json' => json_encode($result, JSON_THROW_ON_ERROR), 'created_at' => $now,
                ]);
                return $result;
            }, 3);

            return response()->json(['ok' => true, 'round' => $outcome]);
        } catch (Throwable $e) {
            report($e);
            return response()->json([
                'ok' => false,
                'error' => $e instanceof RuntimeException ? $e->getMessage() : 'Keno could not be completed; no wallet change was committed.',
            ], 422);
        }
    }

    public function history(Request $request)
    {
        $userId = (string) $request->attributes->get('player_id');
        $rows = DB::table('keno_rounds')->where('user_id', $userId)->orderByDesc('created_at')->limit(20)->get();
        return response()->json(['ok' => true, 'rounds' => $rows->map(function ($r) {
            $result = json_decode($r->result_json, true) ?: [];
            return [
                'id' => $r->id, 'createdAt' => $r->created_at,
                'stake' => (float) $r->stake, 'payout' => (float) $r->payout,
                'multiplier' => (float) $r->multiplier,
                'spots' => json_decode($r->spots, true) ?: [],
                'drawnNumbers' => json_decode($r->drawn_numbers, true) ?: [],
                'hits' => json_decode($r->hits, true) ?: [],
                'serverSeedHash' => $r->server_seed_hash,
                'serverSeed' => $r->server_seed, 'clientSeed' => $r->client_seed,
                'nonce' => (int) $r->nonce,
            ];
        })->values()]);
    }
}
