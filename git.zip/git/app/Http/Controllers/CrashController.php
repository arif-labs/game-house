<?php

namespace App\Http\Controllers;

use App\Services\HouseWalletService;
use App\Services\GameControlService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;

class CrashController
{
    private const COUNTDOWN_SECONDS = 6;
    private const ROUND_PAUSE_SECONDS = 4;
    private const MAX_MULTIPLIER = 100.0;
    private const MIN_STAKE = 1.0;
    private const MAX_STAKE = 1000.0;
    private const GROWTH_RATE = 0.12;

    private GameControlService $controls;

    public function __construct(private HouseWalletService $houseWallet, ?GameControlService $controls = null)
    {
        $this->controls = $controls ?? new GameControlService();
    }

    private function crashPoint(string $seed, int $roundNumber): float
    {
        $digest = hash_hmac('sha256', 'ethio-crash-round:' . $roundNumber, $seed);
        $integer = hexdec(substr($digest, 0, 13));
        $random = $integer / 4503599627370495;
        $point = floor((0.97 / max(0.0000000001, 1 - $random)) * 100) / 100;
        return max(1.00, min(self::MAX_MULTIPLIER, $point));
    }

    private function multiplierAt($startedAt): float
    {
        if (!$startedAt) return 1.0;
        $elapsed = max(0, (now()->valueOf() - \Illuminate\Support\Carbon::parse($startedAt)->valueOf()) / 1000);
        // Use absolute timestamps rather than client animation to determine cash-out eligibility.
        return min(self::MAX_MULTIPLIER, floor(exp(max(0, $elapsed) * self::GROWTH_RATE) * 100) / 100);
    }

    /**
     * Settle configured automatic cash-outs from server time, never from browser animation.
     * Called while the round row is locked inside syncRound's transaction.
     */
    private function settleAutoCashouts(object $round, $startedAt, $crashAt, $now): void
    {
        $crashPoint = (float) $round->crash_point;
        $bets = DB::table('crash_bets')
            ->where('round_id', $round->id)
            ->where('status', 'ACTIVE')
            ->whereNotNull('auto_cashout')
            ->lockForUpdate()
            ->get();

        foreach ($bets as $bet) {
            $target = (float) $bet->auto_cashout;
            // A target at or beyond the crash point is not a successful cash-out.
            if ($target < 1.05 || $target >= $crashPoint || $target > self::MAX_MULTIPLIER) {
                continue;
            }

            $targetAt = $startedAt->copy()->addSeconds(log($target) / self::GROWTH_RATE);
            if ($now->lessThan($targetAt) || $targetAt->greaterThanOrEqualTo($crashAt)) {
                continue;
            }

            $user = DB::table('users')->where('id', $bet->user_id)->lockForUpdate()->first();
            if (!$user) {
                continue;
            }

            $payout = round((float) $bet->stake * $target, 2);
            $after = round((float) $user->play_balance + $payout, 2);
            $settledAt = $targetAt;

            DB::table('users')->where('id', $bet->user_id)->update([
                'play_balance' => $after,
                'updated_at' => $now,
            ]);
            DB::table('ledger')->insert([
                'id' => (string) Str::uuid(),
                'user_id' => $bet->user_id,
                'type' => 'CRASH_PAYOUT',
                'wallet_type' => 'PLAY',
                'amount' => $payout,
                'balance_after' => $after,
                'reference_id' => $bet->id,
                'description' => 'Crash automatic cash-out at ' . number_format($target, 2) . 'x',
                'created_at' => $settledAt,
                'updated_at' => $now,
            ]);
            $this->houseWallet->post('CRASH_PAYOUT', -$payout, $bet->id, 'Crash automatic payout at ' . number_format($target, 2) . 'x');
            DB::table('crash_bets')->where('id', $bet->id)->where('status', 'ACTIVE')->update([
                'status' => 'CASHED_OUT',
                'cashout_multiplier' => $target,
                'payout' => $payout,
                'cashed_out_at' => $settledAt,
                'updated_at' => $now,
            ]);
        }
    }

    public function tick(): void
    {
        // Called by the scheduler so round transitions and auto-cash-outs progress
        // even when no player is actively polling the game page.
        $this->syncRound();
    }

    private function syncRound(): object
    {
        return DB::transaction(function () {
            $round = DB::table('crash_rounds')->orderByDesc('round_number')->lockForUpdate()->first();
            $now = now();

            if (!$round) {
                return $this->createRound(1);
            }

            $created = \Illuminate\Support\Carbon::parse($round->created_at);
            $crashedAt = $round->crashed_at ? \Illuminate\Support\Carbon::parse($round->crashed_at) : null;
            if ($round->status === 'CRASHED' && $crashedAt && (($now->valueOf() - $crashedAt->valueOf()) / 1000) >= self::ROUND_PAUSE_SECONDS) {
                return $this->createRound(((int) $round->round_number) + 1);
            }

            if ($round->status === 'COUNTDOWN' && $now->greaterThanOrEqualTo($created->copy()->addSeconds(self::COUNTDOWN_SECONDS))) {
                $startedAt = $created->copy()->addSeconds(self::COUNTDOWN_SECONDS);
                $crashPoint = (float) $round->crash_point;
                $crashAt = $startedAt->copy()->addSeconds(log(max(1.0, $crashPoint)) / self::GROWTH_RATE);
                if ($now->greaterThanOrEqualTo($crashAt)) {
                    $this->settleAutoCashouts($round, $startedAt, $crashAt, $now);
                    DB::table('crash_rounds')->where('id', $round->id)->update([
                        'status' => 'CRASHED',
                        'started_at' => $startedAt,
                        'crashed_at' => $crashAt,
                        'server_seed' => $round->server_seed,
                        'updated_at' => $now,
                    ]);
                    DB::table('crash_bets')->where('round_id', $round->id)->where('status', 'ACTIVE')->update([
                        'status' => 'LOST',
                        'updated_at' => $now,
                    ]);
                    $round = DB::table('crash_rounds')->where('id', $round->id)->first();
                } else {
                    DB::table('crash_rounds')->where('id', $round->id)->update([
                        'status' => 'FLYING',
                        'started_at' => $startedAt,
                        'updated_at' => $now,
                    ]);
                    $round = DB::table('crash_rounds')->where('id', $round->id)->first();
                }
            } elseif ($round->status === 'FLYING') {
                $crashPoint = (float) $round->crash_point;
                $startedAt = \Illuminate\Support\Carbon::parse($round->started_at);
                $crashAt = $startedAt->copy()->addSeconds(log(max(1.0, $crashPoint)) / self::GROWTH_RATE);
                $this->settleAutoCashouts($round, $startedAt, $crashAt, $now);
                if ($now->greaterThanOrEqualTo($crashAt)) {
                    DB::table('crash_rounds')->where('id', $round->id)->update([
                        'status' => 'CRASHED',
                        'crashed_at' => $crashAt,
                        'server_seed' => $round->server_seed,
                        'updated_at' => $now,
                    ]);
                    DB::table('crash_bets')->where('round_id', $round->id)->where('status', 'ACTIVE')->update(['status' => 'LOST', 'updated_at' => $now]);
                    $round = DB::table('crash_rounds')->where('id', $round->id)->first();
                }
            }

            return $round;
        }, 3);
    }

    private function createRound(int $number): object
    {
        $seed = bin2hex(random_bytes(32));
        $hash = hash('sha256', $seed);
        $point = $this->crashPoint($seed, $number);
        $id = (string) Str::uuid();
        $now = now();
        DB::table('crash_rounds')->insert([
            'id' => $id,
            'round_number' => $number,
            'status' => 'COUNTDOWN',
            'server_seed_hash' => $hash,
            'server_seed' => $seed,
            'crash_point' => $point,
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        return DB::table('crash_rounds')->where('id', $id)->first();
    }

    public function state(Request $request)
    {
        $userId = (string) $request->attributes->get('player_id');
        $user = DB::table('users')->where('id', $userId)->where('is_bot', false)->first();
        if (!$user) return response()->json(['ok' => false, 'error' => 'Player account is unavailable.'], 401);

        $gameSettings = $this->controls->get('crash');
        $round = $this->syncRound();
        $created = \Illuminate\Support\Carbon::parse($round->created_at);
        $now = now();
        $elapsedCountdown = max(0, ($now->valueOf() - $created->valueOf()) / 1000);
        $countdown = max(0, self::COUNTDOWN_SECONDS - $elapsedCountdown);
        $multiplier = $round->status === 'FLYING' ? $this->multiplierAt($round->started_at) : 1.0;
        if ($round->status === 'CRASHED') $multiplier = (float) $round->crash_point;

        $userBet = DB::table('crash_bets')->where('round_id', $round->id)->where('user_id', $userId)->first();
        $bets = DB::table('crash_bets as b')
            ->join('users as u', 'u.id', '=', 'b.user_id')
            ->where('b.round_id', $round->id)
            ->orderByDesc('b.created_at')->limit(30)
            ->get(['b.user_id', 'u.username', 'b.stake', 'b.status', 'b.cashout_multiplier', 'b.payout'])
            ->map(fn ($b) => [
                'userId' => $b->user_id,
                'username' => $b->username,
                'amount' => (float) $b->stake,
                'status' => $b->status,
                'cashedOut' => $b->status === 'CASHED_OUT',
                'cashoutMultiplier' => $b->cashout_multiplier === null ? null : (float) $b->cashout_multiplier,
                'winAmount' => (float) $b->payout,
            ])->values();

        $history = DB::table('crash_rounds')->where('status', 'CRASHED')->whereNotNull('server_seed')
            ->orderByDesc('round_number')->limit(20)->get(['round_number', 'crash_point', 'server_seed_hash', 'server_seed'])
            ->map(fn ($r) => ['round' => (int) $r->round_number, 'multiplier' => (float) $r->crash_point, 'serverSeedHash' => $r->server_seed_hash, 'serverSeed' => $r->server_seed])
            ->values();

        return response()->json([
            'ok' => true,
            'round' => [
                'id' => $round->id,
                'number' => (int) $round->round_number,
                'status' => $round->status,
                'countdown' => (float) $countdown,
                'multiplier' => $multiplier,
                'crashPoint' => $round->status === 'CRASHED' ? (float) $round->crash_point : null,
                'serverSeedHash' => $round->server_seed_hash,
                'serverSeed' => $round->status === 'CRASHED' ? $round->server_seed : null,
                'createdAt' => $created->timestamp * 1000,
                'startedAt' => $round->started_at ? \Illuminate\Support\Carbon::parse($round->started_at)->timestamp * 1000 : null,
            ],
            'balance' => (float) $user->play_balance,
            'myBet' => $userBet ? [
                'id' => $userBet->id, 'stake' => (float) $userBet->stake,
                'status' => $userBet->status, 'autoCashout' => $userBet->auto_cashout === null ? null : (float) $userBet->auto_cashout,
                'cashoutMultiplier' => $userBet->cashout_multiplier === null ? null : (float) $userBet->cashout_multiplier,
                'payout' => (float) $userBet->payout,
            ] : null,
            'bets' => $bets,
            'history' => $history,
            'enabled' => (bool) ($gameSettings['enabled'] ?? true),
            'limits' => ['minStake' => (float) ($gameSettings['minStake'] ?? self::MIN_STAKE), 'maxStake' => min((float) ($gameSettings['maxStake'] ?? self::MAX_STAKE), floor(max(0, $this->houseWallet->balance()) / self::MAX_MULTIPLIER * 100) / 100), 'maxMultiplier' => self::MAX_MULTIPLIER],
            'serverTime' => $now->timestamp * 1000,
        ]);
    }

    public function bet(Request $request)
    {
        $rawStake = $request->input('stake');
        $stakeValue = is_numeric($rawStake) ? (float) $rawStake : NAN;
        $auto = $request->input('autoCashout');
        $autoValue = ($auto === null || $auto === '') ? null : (is_numeric($auto) ? (float) $auto : NAN);
        $key = trim((string) $request->input('idempotencyKey', ''));
        $userId = (string) $request->attributes->get('player_id');
        $gameSettings = $this->controls->get('crash');
        $minStake = (float) ($gameSettings['minStake'] ?? self::MIN_STAKE);
        $maxStake = min((float) ($gameSettings['maxStake'] ?? self::MAX_STAKE), self::MAX_STAKE);
        if (!(bool) ($gameSettings['enabled'] ?? true)) return response()->json(['ok' => false, 'error' => 'Crash is temporarily disabled by the administrator.'], 423);
        if (!is_finite($stakeValue) || $stakeValue < $minStake || $stakeValue > $maxStake ||
            ($autoValue !== null && (!is_finite($autoValue) || $autoValue < 1.05 || $autoValue > self::MAX_MULTIPLIER)) ||
            !preg_match('/^[A-Za-z0-9_-]{8,100}$/', $key)) {
            return response()->json(['ok' => false, 'error' => 'Check your stake and auto cash-out target.'], 422);
        }
        $stake = round($stakeValue, 2);
        try {
            $result = DB::transaction(function () use ($userId, $stake, $autoValue, $key) {
                $currentSettings = $this->controls->get('crash');
                if (!(bool) ($currentSettings['enabled'] ?? true)) throw new RuntimeException('Crash is temporarily disabled by the administrator.');
                if ($stake < (float) ($currentSettings['minStake'] ?? self::MIN_STAKE) || $stake > min((float) ($currentSettings['maxStake'] ?? self::MAX_STAKE), self::MAX_STAKE)) throw new RuntimeException('Stake is outside the current administrator-configured limits.');
                $round = DB::table('crash_rounds')->orderByDesc('round_number')->lockForUpdate()->first();
                if (!$round) throw new RuntimeException('Round is not ready. Refresh and try again.');
                $existing = DB::table('crash_bets')->where('user_id', $userId)->where('idempotency_key', $key)->first();
                if ($existing) {
                    // An idempotency key may only replay the exact original request. Reusing it
                    // with a different stake or auto-cash-out target must never silently return
                    // a successful response for a different bet request.
                    $sameStake = abs((float) $existing->stake - $stake) < 0.000001;
                    $existingAuto = $existing->auto_cashout === null ? null : (float) $existing->auto_cashout;
                    $sameAuto = ($existingAuto === null && $autoValue === null)
                        || ($existingAuto !== null && $autoValue !== null && abs($existingAuto - $autoValue) < 0.000001);
                    if (!$sameStake || !$sameAuto) {
                        throw new RuntimeException('This idempotency key was already used for a different bet. Refresh and submit a new request.');
                    }
                    return ['betId' => $existing->id, 'stake' => (float) $existing->stake, 'status' => $existing->status, 'replayed' => true];
                }
                $created = \Illuminate\Support\Carbon::parse($round->created_at);
                if ($round->status !== 'COUNTDOWN' || now()->greaterThanOrEqualTo($created->copy()->addSeconds(self::COUNTDOWN_SECONDS))) {
                    throw new RuntimeException('Betting is closed for this round. Wait for the next round.');
                }
                if (DB::table('crash_bets')->where('round_id', $round->id)->where('user_id', $userId)->exists()) {
                    throw new RuntimeException('You already have a bet in this round.');
                }
                $user = DB::table('users')->where('id', $userId)->lockForUpdate()->first();
                if (!$user || (bool) ($user->is_bot ?? false)) throw new RuntimeException('Player account is unavailable.');
                if ((float) $user->play_balance + 0.000001 < $stake) throw new RuntimeException('Insufficient Play Wallet balance.');
                $activeExposure = (float) DB::table('crash_bets')->where('status', 'ACTIVE')->sum('stake') * self::MAX_MULTIPLIER;
                if ($this->houseWallet->balance() + 0.000001 < ($activeExposure + $stake * self::MAX_MULTIPLIER)) {
                    throw new RuntimeException('Crash is temporarily unavailable because the house payout reserve is too low for this stake.');
                }
                $after = round((float) $user->play_balance - $stake, 2);
                $id = (string) Str::uuid();
                $now = now();
                DB::table('users')->where('id', $userId)->update(['play_balance' => $after, 'updated_at' => $now]);
                DB::table('ledger')->insert([
                    'id' => (string) Str::uuid(), 'user_id' => $userId, 'type' => 'CRASH_STAKE', 'wallet_type' => 'PLAY',
                    'amount' => -$stake, 'balance_after' => $after, 'reference_id' => $id,
                    'description' => 'Crash game stake, round #' . $round->round_number, 'created_at' => $now, 'updated_at' => $now,
                ]);
                $this->houseWallet->post('CRASH_STAKE', $stake, $id, 'Crash stake received');
                DB::table('crash_bets')->insert([
                    'id' => $id, 'round_id' => $round->id, 'user_id' => $userId, 'stake' => $stake,
                    'auto_cashout' => $autoValue, 'payout' => 0, 'status' => 'ACTIVE', 'idempotency_key' => $key,
                    'created_at' => $now, 'updated_at' => $now,
                ]);
                return ['betId' => $id, 'stake' => $stake, 'status' => 'ACTIVE', 'balance' => $after, 'replayed' => false];
            }, 3);
            return response()->json(['ok' => true, 'bet' => $result]);
        } catch (Throwable $e) {
            report($e);
            return response()->json(['ok' => false, 'error' => $e instanceof RuntimeException ? $e->getMessage() : 'Bet could not be accepted; no wallet change was committed.'], 422);
        }
    }

    public function cashout(Request $request)
    {
        $userId = (string) $request->attributes->get('player_id');
        try {
            $result = DB::transaction(function () use ($userId) {
                $round = DB::table('crash_rounds')->orderByDesc('round_number')->lockForUpdate()->first();
                if (!$round) throw new RuntimeException('No active round.');
                $bet = DB::table('crash_bets')->where('round_id', $round->id)->where('user_id', $userId)->lockForUpdate()->first();
                if (!$bet) throw new RuntimeException('You have no bet in this round.');
                if ($bet->status === 'CASHED_OUT') return ['payout' => (float) $bet->payout, 'multiplier' => (float) $bet->cashout_multiplier, 'replayed' => true];
                if ($bet->status !== 'ACTIVE' || $round->status !== 'FLYING' || !$round->started_at) throw new RuntimeException('Too late — the round has already crashed.');
                $startedAt = \Illuminate\Support\Carbon::parse($round->started_at);
                $elapsed = max(0, (now()->valueOf() - $startedAt->valueOf()) / 1000);
                $multiplier = min(self::MAX_MULTIPLIER, floor(exp($elapsed * self::GROWTH_RATE) * 100) / 100);
                $crashPoint = (float) $round->crash_point;
                $crashAt = $startedAt->copy()->addSeconds(log(max(1.0, $crashPoint)) / self::GROWTH_RATE);
                $this->settleAutoCashouts($round, $startedAt, $crashAt, now());
                $bet = DB::table('crash_bets')->where('round_id', $round->id)->where('user_id', $userId)->lockForUpdate()->first();
                if ($bet && $bet->status === 'CASHED_OUT') {
                    return ['payout' => (float) $bet->payout, 'multiplier' => (float) $bet->cashout_multiplier, 'replayed' => true];
                }
                if (!$bet || $bet->status !== 'ACTIVE') throw new RuntimeException('This bet is already settled.');
                if (now()->greaterThanOrEqualTo($crashAt) || $multiplier >= $crashPoint) {
                    DB::table('crash_rounds')->where('id', $round->id)->update(['status' => 'CRASHED', 'crashed_at' => $crashAt, 'updated_at' => now()]);
                    DB::table('crash_bets')->where('round_id', $round->id)->where('status', 'ACTIVE')->update(['status' => 'LOST', 'updated_at' => now()]);
                    return ['tooLate' => true];
                }
                if ($bet->auto_cashout !== null) $multiplier = min($multiplier, (float) $bet->auto_cashout);
                $payout = round((float) $bet->stake * $multiplier, 2);
                $user = DB::table('users')->where('id', $userId)->lockForUpdate()->first();
                $after = round((float) $user->play_balance + $payout, 2);
                DB::table('users')->where('id', $userId)->update(['play_balance' => $after, 'updated_at' => now()]);
                DB::table('ledger')->insert([
                    'id' => (string) Str::uuid(), 'user_id' => $userId, 'type' => 'CRASH_PAYOUT', 'wallet_type' => 'PLAY',
                    'amount' => $payout, 'balance_after' => $after, 'reference_id' => $bet->id,
                    'description' => 'Crash cash-out at ' . number_format($multiplier, 2) . 'x', 'created_at' => now(), 'updated_at' => now(),
                ]);
                $this->houseWallet->post('CRASH_PAYOUT', -$payout, $bet->id, 'Crash payout at ' . number_format($multiplier, 2) . 'x');
                DB::table('crash_bets')->where('id', $bet->id)->update([
                    'status' => 'CASHED_OUT', 'cashout_multiplier' => $multiplier, 'payout' => $payout,
                    'cashed_out_at' => now(), 'updated_at' => now(),
                ]);
                return ['payout' => $payout, 'multiplier' => $multiplier, 'balance' => $after, 'replayed' => false];
            }, 3);
            if (($result['tooLate'] ?? false) === true) {
                return response()->json(['ok' => false, 'error' => 'Too late — the round has already crashed.'], 422);
            }
            return response()->json(['ok' => true, 'result' => $result]);
        } catch (Throwable $e) {
            report($e);
            return response()->json(['ok' => false, 'error' => $e instanceof RuntimeException ? $e->getMessage() : 'Cash-out could not be completed.'], 422);
        }
    }
}
