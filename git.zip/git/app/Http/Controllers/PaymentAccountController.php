<?php

namespace App\Http\Controllers;

use App\Services\PaymentAccountService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class PaymentAccountController
{
    public function __construct(private PaymentAccountService $accounts)
    {
    }

    /** Admin: current numbers plus who changed them last. */
    public function adminShow()
    {
        return response()->json(['ok' => true] + $this->accounts->getFull());
    }

    /** Admin: change the deposit numbers (super_admin or finance only). */
    public function adminSave(Request $r)
    {
        $admin = $r->attributes->get('admin') ?? [];
        if (!in_array($admin['role'] ?? '', ['super_admin', 'finance'], true)) {
            return response()->json(['ok' => false, 'error' => 'Only super admins and finance managers can change payment numbers.'], 403);
        }

        $clean = [];
        foreach (PaymentAccountService::PROVIDERS as $id => $label) {
            $number = preg_replace('/[\s\-]/', '', (string) $r->input("accounts.$id.number", ''));
            if (!preg_match('/^\+?[0-9]{9,15}$/', $number)) {
                return response()->json(['ok' => false, 'error' => "Enter a valid $label number (9–15 digits, no letters)."], 422);
            }
            $name = trim((string) $r->input("accounts.$id.name", ''));
            if (mb_strlen($name) > 60) {
                return response()->json(['ok' => false, 'error' => "$label account name is too long (max 60 characters)."], 422);
            }
            $clean[$id] = ['number' => $number, 'name' => $name];
        }

        $before = $this->accounts->get();
        $email = (string) ($admin['email'] ?? 'unknown');
        $saved = $this->accounts->save($clean, $email);

        DB::table('admin_audit')->insert([
            'id' => (string) Str::uuid(),
            'timestamp' => now()->timestamp * 1000,
            'admin_email' => $email,
            'action' => 'PAYMENT_ACCOUNTS_UPDATE',
            'target' => 'payment-accounts',
            'details' => json_encode(['before' => $before, 'after' => $clean]),
            'created_at' => now(),
        ]);

        return response()->json(['ok' => true] + $saved);
    }

    /** Player: where to send deposit money (numbers and holder names only). */
    public function playerShow()
    {
        return response()->json(['ok' => true, 'accounts' => $this->accounts->get()]);
    }
}
