<?php

namespace App\Http\Controllers;

use App\Services\TelegramBotRegistry;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class TelegramBotsController
{
    public function __construct(private TelegramBotRegistry $registry) {}

    private function telegram(string $token, string $method, array $data = []): array
    {
        try {
            // Force IPv4: this Windows environment cannot reliably resolve/reach Telegram over IPv6.
            $client = Http::connectTimeout(10)->timeout(25)
                ->withOptions(['force_ip_resolve' => 'v4']);
            $caBundle = config('services.telegram.ca_bundle');
            if (is_string($caBundle) && $caBundle !== '') {
                $client = $client->withOptions(['verify' => $caBundle]);
            }
            $response = $client->post("https://api.telegram.org/bot{$token}/{$method}", $data);
            $json = $response->json();
            return is_array($json) ? $json : ['ok' => false, 'description' => 'Telegram returned an invalid response.'];
        } catch (\Throwable $e) {
            Log::warning('Multi-bot Telegram API request failed', ['method' => $method, 'error' => $e->getMessage()]);
            return ['ok' => false, 'description' => 'Could not connect to the Telegram API.'];
        }
    }

    private function requireAdminRole(Request $request)
    {
        $admin = $request->attributes->get('admin') ?? [];
        if (!in_array($admin['role'] ?? '', ['super_admin', 'game_operator'], true)) {
            return response()->json(['ok' => false, 'error' => 'Insufficient role'], 403);
        }
        return null;
    }

    private function isPublicHttps(string $url): bool
    {
        $parts = parse_url($url);
        return $parts
            && strtolower($parts['scheme'] ?? '') === 'https'
            && !empty($parts['host'])
            && !in_array(strtolower($parts['host']), ['localhost', '127.0.0.1', '::1'], true)
            && !isset($parts['user'])
            && !isset($parts['pass'])
            && (!isset($parts['path']) || $parts['path'] === '' || $parts['path'] === '/')
            && !isset($parts['query'])
            && !isset($parts['fragment']);
    }

    private function miniAppUrl(string $base, string $botKey): string
    {
        return rtrim($base, '/') . (str_contains($base, '?') ? '&' : '?') . 'bot=' . rawurlencode($botKey);
    }

    public function index(Request $request)
    {
        if ($denied = $this->requireAdminRole($request)) return $denied;
        return response()->json(['ok' => true, 'bots' => $this->registry->publicList()]);
    }

    /** Public username lookup used by the Mini App phone-registration handoff. */
    public function publicPhoneShareLink(string $botKey)
    {
        $bot = $this->registry->find($botKey);
        if (!$bot || empty($bot['enabled']) || empty($bot['username'])) {
            return response()->json(['ok' => false, 'error' => 'This Telegram bot is not available.'], 404);
        }

        return response()->json([
            'ok' => true,
            'url' => 'https://t.me/' . ltrim((string) $bot['username'], '@') . '?start=share_phone',
        ]);
    }

    public function save(Request $request)
    {
        if ($denied = $this->requireAdminRole($request)) return $denied;

        $data = $request->validate([
            'id' => 'nullable|string|alpha_dash|max:40',
            'name' => 'required|string|min:2|max:80',
            'botToken' => 'nullable|string|max:256',
            'appUrl' => 'required|url|max:500',
            'enabled' => 'required|boolean',
        ]);

        $id = (string) ($data['id'] ?? '');
        $existing = $id !== '' ? $this->registry->find($id) : null;
        if ($id !== '' && !$existing) {
            return response()->json(['ok' => false, 'error' => 'Bot configuration not found. Refresh the list and try again.'], 404);
        }

        $appUrl = rtrim(trim($data['appUrl']), '/');
        if (!$this->isPublicHttps($appUrl)) {
            return response()->json(['ok' => false, 'error' => 'Enter a public HTTPS Mini App URL. Localhost URLs are not accepted.'], 422);
        }

        $token = trim((string) ($data['botToken'] ?? ''));
        if ($token === '' && $existing) $token = (string) ($existing['botToken'] ?? '');
        if ($token === '' || strlen($token) > 256 || !preg_match('/^\d+:[A-Za-z0-9_-]+$/', $token)) {
            return response()->json(['ok' => false, 'error' => 'Enter a valid BotFather token.'], 422);
        }

        foreach ($this->registry->publicList() as $publicBot) {
            if ($publicBot['id'] === $id) continue;
            $other = $this->registry->find($publicBot['id']);
            if ($other && ($other['botToken'] ?? '') !== '' && hash_equals($other['botToken'], $token)) {
                return response()->json(['ok' => false, 'error' => 'This token is already assigned to another bot entry.'], 422);
            }
        }

        $me = $this->telegram($token, 'getMe');
        if (!($me['ok'] ?? false) || empty($me['result']['username'])) {
            return response()->json(['ok' => false, 'error' => $me['description'] ?? 'Telegram rejected this bot token.'], 422);
        }

        $savedId = $id !== '' ? $id : Str::lower(Str::random(16));
        $this->registry->upsert([
            'id' => $savedId,
            'name' => trim($data['name']),
            'username' => (string) $me['result']['username'],
            'appUrl' => $appUrl,
            'enabled' => (bool) $data['enabled'],
            'botToken' => $token,
        ]);

        $admin = $request->attributes->get('admin') ?? [];
        try {
            DB::table('admin_audit')->insert([
                'id' => (string) Str::uuid(),
                'timestamp' => now()->timestamp * 1000,
                'admin_email' => (string) ($admin['email'] ?? 'unknown'),
                'action' => 'TELEGRAM_BOT_ENTRY_SAVED',
                'target' => $savedId,
                'details' => json_encode(['username' => $me['result']['username'], 'enabled' => (bool) $data['enabled']]),
                'created_at' => now(),
            ]);
        } catch (\Throwable) {
            // Audit logging must not make an otherwise valid bot configuration fail.
        }

        return response()->json([
            'ok' => true,
            'bot' => collect($this->registry->publicList())->firstWhere('id', $savedId),
            'bots' => $this->registry->publicList(),
        ]);
    }

    public function test(Request $request, string $botKey)
    {
        if ($denied = $this->requireAdminRole($request)) return $denied;
        $bot = $this->registry->find($botKey);
        if (!$bot || empty($bot['botToken'])) {
            return response()->json(['ok' => false, 'error' => 'Bot entry or encrypted token is unavailable.'], 404);
        }
        $me = $this->telegram($bot['botToken'], 'getMe');
        $webhook = $this->telegram($bot['botToken'], 'getWebhookInfo');
        return response()->json([
            'ok' => (bool) ($me['ok'] ?? false),
            'bot' => $me['result'] ?? null,
            'webhook' => $webhook['result'] ?? null,
            'error' => ($me['ok'] ?? false) ? null : ($me['description'] ?? 'Token test failed.'),
        ], ($me['ok'] ?? false) ? 200 : 422);
    }

    public function registerWebhook(Request $request, string $botKey)
    {
        if ($denied = $this->requireAdminRole($request)) return $denied;
        $bot = $this->registry->find($botKey);
        if (!$bot || empty($bot['botToken'])) return response()->json(['ok' => false, 'error' => 'Bot entry or token unavailable.'], 404);
        if (empty($bot['enabled'])) return response()->json(['ok' => false, 'error' => 'Enable this bot before registering its webhook.'], 422);

        $appUrl = rtrim(trim((string) $request->input('appUrl', $bot['appUrl'] ?? '')), '/');
        if (!$this->isPublicHttps($appUrl)) {
            return response()->json(['ok' => false, 'error' => 'Enter a public HTTPS Mini App URL.'], 422);
        }

        $secret = (string) ($bot['webhookSecret'] ?? '');
        if ($secret === '') return response()->json(['ok' => false, 'error' => 'Webhook secret is unavailable. Save this bot again.'], 500);

        $webhookUrl = $appUrl . '/api/telegram/bots/' . rawurlencode($botKey) . '/webhook';
        $webhook = $this->telegram($bot['botToken'], 'setWebhook', [
            'url' => $webhookUrl,
            'secret_token' => $secret,
            'allowed_updates' => ['message'],
        ]);
        if (!($webhook['ok'] ?? false)) {
            return response()->json(['ok' => false, 'error' => $webhook['description'] ?? 'Webhook registration failed.'], 422);
        }

        $menu = $this->telegram($bot['botToken'], 'setChatMenuButton', [
            'menu_button' => [
                'type' => 'web_app',
                'text' => 'Play Game',
                'web_app' => ['url' => $this->miniAppUrl($appUrl, $botKey)],
            ],
        ]);

        $this->registry->updateFields($botKey, [
            'appUrl' => $appUrl,
            'webhookUrl' => $webhookUrl,
            'webhookRegisteredAt' => now()->toIso8601String(),
        ]);

        return response()->json([
            'ok' => true,
            'webhookUrl' => $webhookUrl,
            'menuButtonConfigured' => (bool) ($menu['ok'] ?? false),
            'menuButtonError' => ($menu['ok'] ?? false) ? null : ($menu['description'] ?? 'Menu button setup failed.'),
            'bot' => '@' . ($bot['username'] ?? ''),
        ]);
    }

    public function remove(Request $request, string $botKey)
    {
        if ($denied = $this->requireAdminRole($request)) return $denied;
        $bot = $this->registry->find($botKey);
        if (!$bot) return response()->json(['ok' => false, 'error' => 'Bot entry not found.'], 404);

        if (!empty($bot['botToken'])) {
            $deleted = $this->telegram($bot['botToken'], 'deleteWebhook', ['drop_pending_updates' => false]);
            if (!($deleted['ok'] ?? false)) {
                return response()->json(['ok' => false, 'error' => $deleted['description'] ?? 'Telegram could not remove this webhook.'], 422);
            }
        }
        $this->registry->remove($botKey);
        return response()->json(['ok' => true, 'bots' => $this->registry->publicList()]);
    }

    public function webhook(Request $request, string $botKey)
    {
        $bot = $this->registry->find($botKey);
        if (!$bot) return response()->json(['ok' => false], 404);
        if (empty($bot['enabled'])) return response()->json(['ok' => true, 'ignored' => true]);
        if (empty($bot['botToken']) || empty($bot['webhookSecret'])) {
            return response()->json(['ok' => false], 404);
        }

        $providedSecret = (string) $request->header('X-Telegram-Bot-Api-Secret-Token', '');
        if ($providedSecret === '' || !hash_equals((string) $bot['webhookSecret'], $providedSecret)) {
            return response()->json(['ok' => false], 403);
        }

        // Scope the selected bot to this request only, then restore config even on errors.
        $originalToken = config('services.telegram.bot_token');
        $originalAppUrl = config('app.url');
        config([
            'services.telegram.bot_token' => $bot['botToken'],
            'app.url' => $this->miniAppUrl((string) $bot['appUrl'], $botKey),
        ]);

        try {
            return app(TelegramController::class)->webhook($request);
        } finally {
            config([
                'services.telegram.bot_token' => $originalToken,
                'app.url' => $originalAppUrl,
            ]);
        }
    }
}
