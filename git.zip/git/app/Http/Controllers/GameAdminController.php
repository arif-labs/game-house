<?php

namespace App\Http\Controllers;

use App\Services\GameControlService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use RuntimeException;
use Throwable;

class GameAdminController
{
    public function __construct(private GameControlService $controls) {}

    private function audit(Request $request, string $game, string $action, array $details = []): void
    {
        DB::table('game_control_audits')->insert([
            'admin_email' => data_get($request->attributes->get('admin'), 'email'),
            'game_key' => $game,
            'action' => $action,
            'details' => json_encode($details),
            'ip_address' => $request->ip(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    public function overview()
    {
        $settings = $this->controls->all();
        $crashRound = DB::table('crash_rounds')->orderByDesc('round_number')->first();
        $crashToday = DB::table('crash_bets')->whereDate('created_at', today())
            ->selectRaw('COUNT(*) as bets, COALESCE(SUM(stake),0) as stakes, COALESCE(SUM(payout),0) as payouts')->first();
        $spinToday = DB::table('spin_rounds')->whereDate('created_at', today())
            ->selectRaw('COUNT(*) as plays, COALESCE(SUM(stake),0) as stakes, COALESCE(SUM(payout),0) as payouts')->first();
        $kenoToday = DB::table('keno_rounds')->whereDate('created_at', today())
            ->selectRaw('COUNT(*) as plays, COALESCE(SUM(stake),0) as stakes, COALESCE(SUM(payout),0) as payouts')->first();
        $rooms = DB::table('game_rooms')->orderBy('name')->get(['id', 'name', 'status', 'config'])
            ->map(fn ($room) => [
                'id' => $room->id,
                'name' => $room->name,
                'status' => $room->status,
                'config' => json_decode($room->config, true) ?: [],
            ])->values();
        return response()->json([
            'ok' => true,
            'settings' => $settings,
            'crash' => [
                'round' => $crashRound ? [
                    'number' => (int) $crashRound->round_number,
                    'status' => $crashRound->status,
                    'crashPoint' => $crashRound->status === 'CRASHED' ? (float) $crashRound->crash_point : null,
                    'createdAt' => $crashRound->created_at,
                ] : null,
                'today' => ['bets' => (int) $crashToday->bets, 'stakes' => (float) $crashToday->stakes, 'payouts' => (float) $crashToday->payouts, 'net' => round((float) $crashToday->stakes - (float) $crashToday->payouts, 2)],
            ],
            'spin' => ['today' => ['plays' => (int) $spinToday->plays, 'stakes' => (float) $spinToday->stakes, 'payouts' => (float) $spinToday->payouts, 'net' => round((float) $spinToday->stakes - (float) $spinToday->payouts, 2)]],
            'keno' => ['today' => ['plays' => (int) $kenoToday->plays, 'stakes' => (float) $kenoToday->stakes, 'payouts' => (float) $kenoToday->payouts, 'net' => round((float) $kenoToday->stakes - (float) $kenoToday->payouts, 2)]],
            'bingo' => ['rooms' => $rooms],
            'audit' => DB::table('game_control_audits')->orderByDesc('id')->limit(30)->get(),
        ]);
    }

    public function updateSettings(Request $request, string $game)
    {
        $role = (string) data_get($request->attributes->get('admin'), 'role', '');
        if (!in_array($role, ['super_admin', 'game_operator'], true)) return response()->json(['ok' => false, 'error' => 'Your admin role cannot change game controls.'], 403);
        if (!in_array($game, ['crash', 'spin', 'keno'], true)) {
            return response()->json(['ok' => false, 'error' => 'Unknown game.'], 404);
        }
        $hardMax = $game === 'crash' ? 1000 : 100;
        $validator = Validator::make($request->all(), [
            'enabled' => ['sometimes', 'boolean'],
            'minStake' => ['sometimes', 'numeric', 'min:0.01', 'max:' . $hardMax],
            'maxStake' => ['sometimes', 'numeric', 'min:0.01', 'max:' . $hardMax],
        ]);
        if ($validator->fails()) return response()->json(['ok' => false, 'error' => $validator->errors()->first()], 422);

        $current = $this->controls->get($game);
        $input = $validator->validated();
        $next = array_merge($current, $input);
        if ((float) $next['minStake'] > (float) $next['maxStake']) {
            return response()->json(['ok' => false, 'error' => 'Minimum stake cannot exceed maximum stake.'], 422);
        }
        try {
            DB::transaction(function () use ($request, $game, $input, $next) {
                $this->controls->save($game, $next);
                $this->audit($request, $game, 'settings_updated', ['changed' => $input, 'result' => $next]);
            });
            return response()->json(['ok' => true, 'settings' => $next]);
        } catch (Throwable $e) {
            report($e);
            return response()->json(['ok' => false, 'error' => 'Settings could not be saved.'], 500);
        }
    }

    public function setBingoRoomStatus(Request $request, string $id)
    {
        $role = (string) data_get($request->attributes->get('admin'), 'role', '');
        if (!in_array($role, ['super_admin', 'game_operator'], true)) return response()->json(['ok' => false, 'error' => 'Your admin role cannot change game controls.'], 403);
        $status = $request->input('status');
        if (!in_array($status, ['active', 'paused', 'maintenance'], true)) {
            return response()->json(['ok' => false, 'error' => 'Status must be active, paused, or maintenance.'], 422);
        }
        $room = DB::table('game_rooms')->where('id', $id)->first();
        if (!$room) return response()->json(['ok' => false, 'error' => 'Bingo room not found.'], 404);
        DB::transaction(function () use ($request, $id, $status) {
            DB::table('game_rooms')->where('id', $id)->update(['status' => $status, 'updated_at' => now()]);
            $this->audit($request, 'bingo', 'room_status_changed', ['roomId' => $id, 'status' => $status]);
        });
        return response()->json(['ok' => true, 'room' => ['id' => $id, 'status' => $status]]);
    }

    public function report(Request $request)
    {
        $game = (string) $request->query('game', 'all');
        $days = max(1, min(90, (int) $request->query('days', 7)));
        $since = now()->subDays($days)->startOfDay();
        $data = [];
        if ($game === 'all' || $game === 'crash') {
            $data['crash'] = DB::table('crash_bets')->where('created_at', '>=', $since)
                ->selectRaw('DATE(created_at) as day, COUNT(*) as rounds_bet, COALESCE(SUM(stake),0) as stakes, COALESCE(SUM(payout),0) as payouts')
                ->groupByRaw('DATE(created_at)')->orderBy('day')->get()
                ->map(fn ($r) => ['day' => $r->day, 'bets' => (int) $r->rounds_bet, 'stakes' => (float) $r->stakes, 'payouts' => (float) $r->payouts, 'net' => round((float) $r->stakes - (float) $r->payouts, 2)]);
        }
        if ($game === 'all' || $game === 'spin') {
            $data['spin'] = DB::table('spin_rounds')->where('created_at', '>=', $since)
                ->selectRaw('DATE(created_at) as day, COUNT(*) as plays, COALESCE(SUM(stake),0) as stakes, COALESCE(SUM(payout),0) as payouts')
                ->groupByRaw('DATE(created_at)')->orderBy('day')->get()
                ->map(fn ($r) => ['day' => $r->day, 'plays' => (int) $r->plays, 'stakes' => (float) $r->stakes, 'payouts' => (float) $r->payouts, 'net' => round((float) $r->stakes - (float) $r->payouts, 2)]);
        }
        if ($game === 'all' || $game === 'keno') {
            $data['keno'] = DB::table('keno_rounds')->where('created_at', '>=', $since)
                ->selectRaw('DATE(created_at) as day, COUNT(*) as plays, COALESCE(SUM(stake),0) as stakes, COALESCE(SUM(payout),0) as payouts')
                ->groupByRaw('DATE(created_at)')->orderBy('day')->get()
                ->map(fn ($r) => ['day' => $r->day, 'plays' => (int) $r->plays, 'stakes' => (float) $r->stakes, 'payouts' => (float) $r->payouts, 'net' => round((float) $r->stakes - (float) $r->payouts, 2)]);
        }
        if ($game === 'all' || $game === 'bingo') {
            $data['bingo'] = DB::table('game_rounds')->where('created_at', '>=', $since)
                ->selectRaw('DATE(created_at) as day, COUNT(*) as rounds')->groupByRaw('DATE(created_at)')->orderBy('day')->get();
        }
        return response()->json(['ok' => true, 'days' => $days, 'reports' => $data]);
    }
}
