<?php

namespace App\Http\Controllers;

use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

/**
 * Tiny, cheap endpoint the admin dashboard polls every few seconds so new deposit /
 * withdrawal requests show up without reloading the page.
 */
class FinanceAlertController
{
    public function show()
    {
        return response()->json([
            'ok' => true,
            'deposits' => $this->summary('deposits'),
            'withdrawals' => $this->summary('withdrawals'),
        ]);
    }

    private function summary(string $table): array
    {
        $pending = DB::table($table)->where('status', 'pending');
        $latest = (clone $pending)->max('created_at');

        return [
            'pending' => (clone $pending)->count(),
            // Milliseconds of the newest pending request (0 when none).
            'latest' => $latest ? Carbon::parse($latest)->timestamp * 1000 : 0,
        ];
    }
}
