<?php

namespace App\Http\Controllers;

use App\Services\HouseWalletService;
use App\Services\GameControlService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;

class SpinController
{
    private GameControlService $controls;

    public function __construct(private HouseWalletService $houseWallet, ?GameControlService $controls = null)
    {
        $this->controls = $controls ?? new GameControlService();
    }

    private function segments(): array
    {
        return [
            ['id' => 'seg-1', 'label' => '0x', 'sublabel' => 'Try Again', 'multiplier' => 0, 'type' => 'zero', 'color' => '#334155', 'textColor' => '#94A3B8', 'weight' => 36142],
            ['id' => 'seg-2', 'label' => '1.2x', 'sublabel' => 'Win', 'multiplier' => 1.2, 'type' => 'multiplier', 'color' => '#0D9488', 'textColor' => '#FFFFFF', 'weight' => 18530],
            ['id' => 'seg-3', 'label' => '0.5x', 'sublabel' => 'Half Back', 'multiplier' => 0.5, 'type' => 'multiplier', 'color' => '#475569', 'textColor' => '#E2E8F0', 'weight' => 20623],
            ['id' => 'seg-4', 'label' => '1.5x', 'sublabel' => 'Nice Win', 'multiplier' => 1.5, 'type' => 'multiplier', 'color' => '#2563EB', 'textColor' => '#FFFFFF', 'weight' => 10315],
            ['id' => 'seg-5', 'label' => '2x', 'sublabel' => 'Double', 'multiplier' => 2, 'type' => 'multiplier', 'color' => '#7C3AED', 'textColor' => '#FFFFFF', 'weight' => 6189],
            ['id' => 'seg-6', 'label' => '3x', 'sublabel' => 'Triple', 'multiplier' => 3, 'type' => 'multiplier', 'color' => '#D97706', 'textColor' => '#FFFFFF', 'weight' => 3610],
            ['id' => 'seg-7', 'label' => '5x', 'sublabel' => 'Mega', 'multiplier' => 5, 'type' => 'multiplier', 'color' => '#DC2626', 'textColor' => '#FFFFFF', 'weight' => 2579],
            ['id' => 'seg-8', 'label' => '1x', 'sublabel' => 'Return', 'multiplier' => 1, 'type' => 'multiplier', 'color' => '#059669', 'textColor' => '#FFFFFF', 'weight' => 1547],
            ['id' => 'seg-9', 'label' => '10x', 'sublabel' => 'Super Win', 'multiplier' => 10, 'type' => 'multiplier', 'color' => '#DB2777', 'textColor' => '#FFFFFF', 'weight' => 413],
            ['id' => 'seg-10', 'label' => '100x', 'sublabel' => 'JACKPOT', 'multiplier' => 100, 'type' => 'jackpot', 'color' => '#F59E0B', 'textColor' => '#1E1B4B', 'weight' => 52],
        ];
    }

    public function config(Request $request)
    {
        $userId = (string) $request->attributes->get('player_id');
        $user = DB::table('users')->where('id', $userId)->where('is_bot', false)->first();
        if (!$user) {
            return response()->json(['ok' => false, 'error' => 'Player account is unavailable.'], 401);
        }

        // Publish the hash before a spin; the matching seed remains server-side until used.
        $seed = bin2hex(random_bytes(32));
        DB::table('spin_seed_states')->insertOrIgnore([
            'user_id' => $userId,
            'server_seed' => $seed,
            'server_seed_hash' => hash('sha256', $seed),
            'next_nonce' => 1,
            'updated_at' => now(),
        ]);
        $seedState = DB::table('spin_seed_states')->where('user_id', $userId)->first();
        $settings = $this->controls->get('spin');
        $houseBalance = $this->houseWallet->balance();
        $maxBet = min((float) ($settings['maxStake'] ?? 100), floor(max(0, $houseBalance) / 99 * 100) / 100);

        return response()->json([
            'ok' => true,
            'currency' => 'ETB',
            'minBet' => (float) ($settings['minStake'] ?? 1),
            'maxBet' => $maxBet,
            'enabled' => (bool) ($settings['enabled'] ?? true),
            'canPlay' => (bool) ($settings['enabled'] ?? true) && $maxBet >= (float) ($settings['minStake'] ?? 1),
            'segments' => $this->segments(),
            'serverSeedHash' => $seedState->server_seed_hash,
            'nextNonce' => (int) $seedState->next_nonce,
        ]);
    }

    public function play(Request $request)
    {
        $rawStake = $request->input('stake');
        $stakeValue = is_numeric($rawStake) ? (float) $rawStake : NAN;
        $clientSeed = trim((string) $request->input('clientSeed', ''));
        $idempotencyKey = trim((string) $request->input('idempotencyKey', ''));
        $committedSeedHash = trim((string) $request->input('serverSeedHash', ''));
        $userId = (string) $request->attributes->get('player_id');

        // Validate against administrator-controlled limits before entering the wallet transaction.
        $settings = $this->controls->get('spin');
        $minStake = (float) ($settings['minStake'] ?? 1);
        $maxStake = min(100.0, (float) ($settings['maxStake'] ?? 100));
        if (!(bool) ($settings['enabled'] ?? true)) {
            return response()->json(['ok' => false, 'error' => 'Spin is temporarily disabled by the administrator.'], 423);
        }
        if (!is_finite($stakeValue) || $stakeValue < $minStake || $stakeValue > $maxStake) {
            return response()->json(['ok' => false, 'error' => 'Stake is outside the current administrator-configured limits.'], 422);
        }
        $stake = round($stakeValue, 2);
        if ($clientSeed === '' || strlen($clientSeed) > 128 || !preg_match('/^[A-Za-z0-9_-]{8,100}$/', $idempotencyKey) || !preg_match('/^[a-f0-9]{64}$/', $committedSeedHash)) {
            return response()->json(['ok' => false, 'error' => 'Invalid spin request. Please try again.'], 422);
        }

        try {
            $outcome = DB::transaction(function () use ($stake, $clientSeed, $idempotencyKey, $committedSeedHash, $userId) {
                $currentSettings = $this->controls->get('spin');
                if (!(bool) ($currentSettings['enabled'] ?? true)) throw new RuntimeException('Spin is temporarily disabled by the administrator.');
                if ($stake < (float) ($currentSettings['minStake'] ?? 1) || $stake > min(100.0, (float) ($currentSettings['maxStake'] ?? 100))) throw new RuntimeException('Stake is outside the current administrator-configured limits.');
                $user = DB::table('users')->where('id', $userId)->lockForUpdate()->first();
                if (!$user || (bool) ($user->is_bot ?? false)) {
                    throw new RuntimeException('Player account is unavailable.');
                }

                $existing = DB::table('spin_rounds')
                    ->where('user_id', $userId)
                    ->where('idempotency_key', $idempotencyKey)
                    ->first();
                if ($existing && $existing->result_json) {
                    if (abs((float) $existing->stake - $stake) > 0.000001 || !hash_equals((string) $existing->client_seed, $clientSeed) || !hash_equals((string) $existing->server_seed_hash, $committedSeedHash)) {
                        throw new RuntimeException('This spin request key was already used for a different request.');
                    }
                    return json_decode($existing->result_json, true);
                }

                $seedState = DB::table('spin_seed_states')->where('user_id', $userId)->lockForUpdate()->first();
                if (!$seedState || !hash_equals((string) $seedState->server_seed_hash, $committedSeedHash)) {
                    throw new RuntimeException('The fairness commitment changed. Refresh Spin settings and try again.');
                }

                if ((float) $user->play_balance + 0.000001 < $stake) {
                    throw new RuntimeException('Insufficient Play Wallet balance. Move funds from your Main Wallet first.');
                }
                if ($this->houseWallet->balance() + 0.000001 < ($stake * 99)) {
                    throw new RuntimeException('Spin is temporarily unavailable because the house payout reserve is too low for this stake.');
                }

                $segments = $this->segments();
                $totalWeight = array_sum(array_column($segments, 'weight'));
                $nonce = (int) $seedState->next_nonce;
                $serverSeed = (string) $seedState->server_seed;
                $serverSeedHash = (string) $seedState->server_seed_hash;
                $digest = hash_hmac('sha256', $clientSeed . ':' . $nonce, $serverSeed);
                $bucket = (int) (hexdec(substr($digest, 0, 8)) % $totalWeight);
                $cumulative = 0;
                $winningIndex = 0;
                foreach ($segments as $index => $segment) {
                    $cumulative += (int) $segment['weight'];
                    if ($bucket < $cumulative) {
                        $winningIndex = $index;
                        break;
                    }
                }

                $segment = $segments[$winningIndex];
                $payout = round($stake * (float) $segment['multiplier'], 2);
                $profit = round($payout - $stake, 2);
                $playAfterStake = round((float) $user->play_balance - $stake, 2);
                $playAfter = round($playAfterStake + $payout, 2);
                $spinId = (string) Str::uuid();
                $now = now();

                DB::table('users')->where('id', $userId)->update([
                    'play_balance' => $playAfter,
                    'updated_at' => $now,
                ]);

                DB::table('ledger')->insert([
                    'id' => (string) Str::uuid(),
                    'user_id' => $userId,
                    'type' => 'SPIN_STAKE',
                    'wallet_type' => 'PLAY',
                    'amount' => -$stake,
                    'balance_after' => $playAfterStake,
                    'reference_id' => $spinId,
                    'description' => 'Spin game stake',
                    'created_at' => $now,
                    'updated_at' => $now,
                ]);

                if ($payout > 0) {
                    DB::table('ledger')->insert([
                        'id' => (string) Str::uuid(),
                        'user_id' => $userId,
                        'type' => 'SPIN_PAYOUT',
                        'wallet_type' => 'PLAY',
                        'amount' => $payout,
                        'balance_after' => $playAfter,
                        'reference_id' => $spinId,
                        'description' => 'Spin game payout (' . $segment['label'] . ')',
                        'created_at' => $now,
                        'updated_at' => $now,
                    ]);
                }

                // Keep house movements in the same database transaction as the player ledger.
                $this->houseWallet->post('SPIN_STAKE', $stake, $spinId, 'Spin stake received');
                if ($payout > 0) {
                    $this->houseWallet->post('SPIN_PAYOUT', -$payout, $spinId, 'Spin payout to player');
                }

                $result = [
                    'spinId' => $spinId,
                    'winningIndex' => $winningIndex,
                    'segment' => $segment,
                    'stake' => $stake,
                    'payout' => $payout,
                    'profit' => $profit,
                    'playBalance' => $playAfter,
                    'serverSeedHash' => $serverSeedHash,
                    'serverSeed' => $serverSeed,
                    'clientSeed' => $clientSeed,
                    'nonce' => $nonce,
                ];

                $nextServerSeed = bin2hex(random_bytes(32));
                $nextServerSeedHash = hash('sha256', $nextServerSeed);
                $result['nextServerSeedHash'] = $nextServerSeedHash;
                DB::table('spin_seed_states')->where('user_id', $userId)->update([
                    'server_seed' => $nextServerSeed,
                    'server_seed_hash' => $nextServerSeedHash,
                    'next_nonce' => $nonce + 1,
                    'updated_at' => $now,
                ]);

                DB::table('spin_rounds')->insert([
                    'id' => $spinId,
                    'user_id' => $userId,
                    'stake' => $stake,
                    'payout' => $payout,
                    'profit' => $profit,
                    'segment_id' => $segment['id'],
                    'segment_label' => $segment['label'],
                    'multiplier' => $segment['multiplier'],
                    'client_seed' => $clientSeed,
                    'server_seed_hash' => $serverSeedHash,
                    'server_seed' => $serverSeed,
                    'nonce' => $nonce,
                    'idempotency_key' => $idempotencyKey,
                    'result_json' => json_encode($result, JSON_THROW_ON_ERROR),
                    'created_at' => $now,
                ]);

                return $result;
            }, 3);

            return response()->json(['ok' => true, 'outcome' => $outcome]);
        } catch (Throwable $e) {
            report($e);
            $message = $e instanceof RuntimeException
                ? $e->getMessage()
                : 'Spin could not be completed. No wallet change was committed.';
            return response()->json(['ok' => false, 'error' => $message], 422);
        }
    }
}
