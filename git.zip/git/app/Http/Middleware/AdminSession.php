<?php
namespace App\Http\Middleware;
use Closure;
use Illuminate\Http\Request;
class AdminSession {
 public function handle(Request $request,Closure $next){
  if(!session()->has('admin'))return response()->json(['ok'=>false,'error'=>'Admin authentication required'],401);
  $admin=session('admin');
  if(($admin['exp']??0)<now()->timestamp){session()->forget('admin');return response()->json(['ok'=>false,'error'=>'Admin session expired'],401);}
  $request->attributes->set('admin',$admin);return $next($request);
 }
}