<?php
namespace App\Http\Middleware;
use Closure;
use Illuminate\Http\Request;
class PlayerSession {
 public function handle(Request $request,Closure $next){
  if(!session()->has('player_id'))return response()->json(['ok'=>false,'error'=>'Player authentication required'],401);
  $request->attributes->set('player_id',session('player_id'));return $next($request);
 }
}