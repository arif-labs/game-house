<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;

/**
 * Single source of truth for the Telebirr / CBE Birr numbers players pay deposits to.
 * Stored in system_state under "payment_accounts" so admins can change them from the
 * dashboard (Finance & Queues). Falls back to .env values until an admin saves.
 * Used by the Mini App wallet (via the API) and the Telegram bot deposit flow.
 */
class PaymentAccountService
{
    public const KEY = 'payment_accounts';
    public const PROVIDERS = ['telebirr' => 'Telebirr', 'cbe' => 'CBE Birr'];

    public function defaults(): array
    {
        return [
            'telebirr' => ['number' => (string) env('TELEGRAM_DEPOSIT_TELEBIRR_NUMBER', '0902695384'), 'name' => ''],
            'cbe' => ['number' => (string) env('TELEGRAM_DEPOSIT_CBE_NUMBER', '0902695384'), 'name' => ''],
        ];
    }

    /** Full record including audit metadata (admin view). */
    public function getFull(): array
    {
        $raw = DB::table('system_state')->where('key', self::KEY)->value('value');
        $saved = is_string($raw) ? json_decode($raw, true) : null;
        $out = $this->defaults();
        $meta = ['updatedAt' => null, 'updatedBy' => null, 'isDefault' => true];

        if (is_array($saved)) {
            foreach (array_keys(self::PROVIDERS) as $id) {
                $number = $saved[$id]['number'] ?? null;
                if (is_string($number) && $number !== '') {
                    $out[$id]['number'] = $number;
                    $meta['isDefault'] = false;
                }
                $name = $saved[$id]['name'] ?? null;
                if (is_string($name)) {
                    $out[$id]['name'] = $name;
                }
            }
            $meta['updatedAt'] = $saved['updatedAt'] ?? null;
            $meta['updatedBy'] = $saved['updatedBy'] ?? null;
        }

        return ['accounts' => $out] + $meta;
    }

    /** Player-safe view: numbers and holder names only. */
    public function get(): array
    {
        return $this->getFull()['accounts'];
    }

    public function numberFor(string $provider): string
    {
        $id = $provider === 'Telebirr' ? 'telebirr' : 'cbe';
        return (string) ($this->get()[$id]['number'] ?? '');
    }

    public function nameFor(string $provider): string
    {
        $id = $provider === 'Telebirr' ? 'telebirr' : 'cbe';
        return (string) ($this->get()[$id]['name'] ?? '');
    }

    /** Persist already-validated accounts. */
    public function save(array $accounts, string $adminEmail): array
    {
        $payload = [];
        foreach (array_keys(self::PROVIDERS) as $id) {
            $payload[$id] = [
                'number' => (string) $accounts[$id]['number'],
                'name' => (string) ($accounts[$id]['name'] ?? ''),
            ];
        }
        $payload['updatedAt'] = now()->timestamp * 1000;
        $payload['updatedBy'] = $adminEmail;

        DB::table('system_state')->updateOrInsert(
            ['key' => self::KEY],
            ['value' => json_encode($payload), 'updated_at' => now()]
        );

        return $this->getFull();
    }
}
