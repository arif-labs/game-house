<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use RuntimeException;

class HouseWalletService
{
    public function balance(): float
    {
        return (float) DB::table('house_wallet')->where('id', 'main')->value('balance');
    }

    public function post(string $type, float $amount, string $referenceId, string $description): float
    {
        // Serialize postings on the wallet row before checking the idempotency key.
        // Checking first allows two concurrent requests to both see no ledger row;
        // the unique index would reject one only after its transaction has done work.
        return DB::transaction(function () use ($type, $amount, $referenceId, $description): float {
            $wallet = DB::table('house_wallet')->where('id', 'main')->lockForUpdate()->first();
            if (!$wallet) {
                throw new RuntimeException('House wallet is not initialized');
            }

            $existing = DB::table('house_ledger')
                ->where(['type' => $type, 'reference_id' => $referenceId])
                ->first();

            if ($existing) {
                return (float) $existing->balance_after;
            }

            $after = round((float) $wallet->balance + $amount, 2);
            if ($after < 0) {
                throw new RuntimeException('House wallet has insufficient funds for this operation');
            }

            DB::table('house_wallet')->where('id', 'main')->update([
                'balance' => $after,
                'updated_at' => now(),
            ]);

            DB::table('house_ledger')->insert([
                'id' => (string) Str::uuid(),
                'type' => $type,
                'amount' => round($amount, 2),
                'balance_after' => $after,
                'reference_id' => $referenceId,
                'description' => $description,
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            return $after;
        });
    }

    public function profitLoss(): float
    {
        return (float) DB::table('house_ledger')
            ->whereIn('type', ['RAKE_FEE', 'BOT_WIN', 'BOT_STAKE', 'BOT_STAKE_REFUND', 'SPIN_STAKE', 'SPIN_PAYOUT', 'CRASH_STAKE', 'CRASH_PAYOUT', 'KENO_STAKE', 'KENO_PAYOUT'])
            ->sum('amount');
    }

    public function recentLedger(int $limit = 100): array
    {
        return DB::table('house_ledger')
            ->orderByDesc('created_at')
            ->limit($limit)
            ->get()
            ->map(fn ($row) => [
                'id' => $row->id,
                'timestamp' => $row->created_at ? strtotime($row->created_at) * 1000 : 0,
                'type' => $row->type,
                'amount' => (float) $row->amount,
                'balanceAfter' => (float) $row->balance_after,
                'referenceId' => $row->reference_id,
                'description' => $row->description ?? '',
            ])->all();
    }
}
