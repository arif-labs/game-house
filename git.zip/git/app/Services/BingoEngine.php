<?php
namespace App\Services;
class BingoEngine {
 public const PATTERNS=['any_row','any_col','any_diagonal','four_corners','full_house'];
 private function multiply32(int $a, int $b): int
 {
  // Compute the low 32 bits using 16-bit limbs. Native PHP multiplication can
  // overflow to float on 64-bit builds, which both emits deprecations and changes
  // the deterministic sequence compared with JavaScript Math.imul.
  $a &= 0xffffffff;
  $b &= 0xffffffff;
  $aLow = $a & 0xffff;
  $aHigh = ($a >> 16) & 0xffff;
  $bLow = $b & 0xffff;
  $bHigh = ($b >> 16) & 0xffff;
  $low = $aLow * $bLow;
  $middle = (($aLow * $bHigh) + ($aHigh * $bLow)) & 0xffff;
  return ($low + ($middle << 16)) & 0xffffffff;
 }
 private function prng(int $seed):\Closure{return function()use(&$seed){$seed=($seed+0x6d2b79f5)&0xffffffff;$t=$seed;$t=$this->multiply32($t^($t>>15),$t|1);$t^=($t+$this->multiply32($t^($t>>7),$t|61))&0xffffffff;return (($t^($t>>14))&0xffffffff)/4294967296;};}
 private function pick(int $min,int $max,\Closure $r):array{$p=range($min,$max);for($i=count($p)-1;$i>0;$i--){$j=(int)floor($r()*($i+1));[$p[$i],$p[$j]]=[$p[$j],$p[$i]];}return array_slice($p,0,5);}
 public function cartela(int $id):array{$r=$this->prng($id*1847+9327);$b=$this->pick(1,15,$r);$i=$this->pick(16,30,$r);$n=$this->pick(31,45,$r);$g=$this->pick(46,60,$r);$o=$this->pick(61,75,$r);$n[2]=0;$m=[];for($row=0;$row<5;$row++)$m[]=[ $b[$row],$i[$row],$n[$row],$g[$row],$o[$row] ];return ['id'=>$id,'matrix'=>$m];}
 public function check(array $matrix,array $called,array $patterns):array{$set=array_fill_keys($called,true);$marked=fn($n)=>$n===0||isset($set[$n]);$w=[];
  if(in_array('any_row',$patterns,true))for($r=0;$r<5;$r++){ $ok=true;for($c=0;$c<5;$c++)if(!$marked($matrix[$r][$c])){$ok=false;break;}if($ok){$w[]='any_row';break;}}
  if(in_array('any_col',$patterns,true))for($c=0;$c<5;$c++){ $ok=true;for($r=0;$r<5;$r++)if(!$marked($matrix[$r][$c])){$ok=false;break;}if($ok){$w[]='any_col';break;}}
  if(in_array('any_diagonal',$patterns,true)){ $a=$b=true;for($i=0;$i<5;$i++){if(!$marked($matrix[$i][$i]))$a=false;if(!$marked($matrix[$i][4-$i]))$b=false;}if($a||$b)$w[]='any_diagonal';}
  if(in_array('four_corners',$patterns,true)&&$marked($matrix[0][0])&&$marked($matrix[0][4])&&$marked($matrix[4][0])&&$marked($matrix[4][4]))$w[]='four_corners';
  if(in_array('full_house',$patterns,true)){ $ok=true;for($r=0;$r<5;$r++)for($c=0;$c<5;$c++)if(!$marked($matrix[$r][$c])){$ok=false;break 2;}if($ok)$w[]='full_house';}
  return ['hasWon'=>count($w)>0,'winningPatterns'=>$w];
 }
 public function drawSequence(string $seed):array{$balls=range(1,75);$digest=hash('sha256',$seed,true);$counter=0;for($i=74;$i>0;$i--){$raw=hash('sha256',$digest.pack('N',$counter++),true);$n=unpack('N',substr($raw,0,4))[1];$j=(int)floor(($n/4294967296)*($i+1));[$balls[$i],$balls[$j]]=[$balls[$j],$balls[$i]];}return $balls;}
 public function prizePool(int $players,float $stake,float $rake):array{$total=round($players*$stake,2);$r=round($total*$rake/100,2);return ['totalPool'=>$total,'rakeEarned'=>$r,'derashPrize'=>round($total-$r,2)];}
}