<?php
namespace App\Services;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use RuntimeException;

class GameService {
 public function __construct(private BingoEngine $engine, private HouseWalletService $houseWallet){}

 public function defaults():array{return ['stake'=>(float)env('GAME_DEFAULT_STAKE',10),'rakePercent'=>(float)env('GAME_DEFAULT_RAKE_PERCENT',10),'minPlayers'=>(int)env('GAME_DEFAULT_MIN_PLAYERS',2),'maxPlayers'=>200,'selectionSeconds'=>(int)env('GAME_DEFAULT_SELECTION_SECONDS',60),'drawInterval'=>(int)env('GAME_DEFAULT_DRAW_INTERVAL',3),'maxCartelasPerPlayer'=>5,'enabledPatterns'=>BingoEngine::PATTERNS,'automatedPlayersEnabled'=>false,'automatedPlayerCount'=>0,'automatedPlayersTriggerBelow'=>10,'automatedPlayersTarget'=>10,'automatedPlayersRiskControlEnabled'=>true,'automatedPlayersMaxStakeBudget'=>50,'automatedPlayersMaxHouseExposure'=>100,'automatedPlayersStrategy'=>'balanced','automatedPlayersManualOverrideEnabled'=>true,'automatedPlayersBotsPerRealCartela'=>2,'automatedPlayersMinCardsPerPlayer'=>2];}



 public function rooms(): array
 {
     return DB::table('game_rooms')
         ->orderByRaw('CAST(JSON_UNQUOTE(JSON_EXTRACT(config, "$.stake")) AS DECIMAL(10,2)) ASC')
         ->get()
         ->map(function ($x) {
             $config = array_merge($this->defaults(), json_decode($x->config, true) ?: []);
             // Keep the API compatible with the player UI's RoomConfig shape.
             $config['selectionDuration'] = (int) ($config['selectionSeconds'] ?? 60);
             $config['maxCartelasPerPlayer'] = (int) ($config['maxCartelasPerPlayer'] ?? 1);

             return array_merge(
                 [
                     'id' => $x->id,
                     'name' => $x->name,
                     'status' => $x->status,
                 ],
                 $config
             );
         })
         ->all();
 }

 public function saveRoom(array $data): array
 {
     $id = $data['id'] ?? ('room-' . Str::uuid());

     $existing = DB::table('game_rooms')->where('id', $id)->first();
     $prevCfg = $existing ? (json_decode($existing->config, true) ?: []) : [];

     $config = array_merge(
         $this->defaults(),
         $existing ? (json_decode($existing->config, true) ?: []) : [],
         [
             'stake' => (float) ($data['stake'] ?? 5),
             'rakePercent' => (float) ($data['rakePercent'] ?? 10),
             'minPlayers' => (int) ($data['minPlayers'] ?? 2),
             'maxPlayers' => (int) ($data['maxPlayers'] ?? 200),
             'selectionSeconds' => (int) ($data['selectionSeconds'] ?? 40),
             'drawInterval' => (int) ($data['drawInterval'] ?? 3),
             'maxCartelasPerPlayer' => max(1, min(200, (int) ($data['maxCartelasPerPlayer'] ?? (($existingConfig = json_decode($existing->config ?? '{}', true))['maxCartelasPerPlayer'] ?? 1)))),
             'automatedPlayersEnabled' => (bool) ($data['automatedPlayersEnabled'] ?? $prevCfg['automatedPlayersEnabled'] ?? false),
             'automatedPlayerCount' => (int) ($data['automatedPlayerCount'] ?? $prevCfg['automatedPlayerCount'] ?? 0),
             'automatedPlayersTriggerBelow' => (int) ($data['automatedPlayersTriggerBelow'] ?? $prevCfg['automatedPlayersTriggerBelow'] ?? 10),
             'automatedPlayersTarget' => (int) ($data['automatedPlayersTarget'] ?? $prevCfg['automatedPlayersTarget'] ?? 10),
             'automatedPlayersRiskControlEnabled' => (bool) ($data['automatedPlayersRiskControlEnabled'] ?? $prevCfg['automatedPlayersRiskControlEnabled'] ?? true),
             'automatedPlayersMaxStakeBudget' => max(0, (float) ($data['automatedPlayersMaxStakeBudget'] ?? $prevCfg['automatedPlayersMaxStakeBudget'] ?? 50)),
             'automatedPlayersMaxHouseExposure' => max(0, (float) ($data['automatedPlayersMaxHouseExposure'] ?? $prevCfg['automatedPlayersMaxHouseExposure'] ?? 100)),
             'automatedPlayersStrategy' => in_array(($data['automatedPlayersStrategy'] ?? $prevCfg['automatedPlayersStrategy'] ?? 'balanced'), ['conservative', 'balanced', 'aggressive'], true) ? $data['automatedPlayersStrategy'] ?? $prevCfg['automatedPlayersStrategy'] ?? 'balanced' : 'balanced',
             'automatedPlayersManualOverrideEnabled' => (bool) ($data['automatedPlayersManualOverrideEnabled'] ?? $prevCfg['automatedPlayersManualOverrideEnabled'] ?? true),
             'automatedPlayersBotsPerRealCartela' => (int) ($data['automatedPlayersBotsPerRealCartela'] ?? $prevCfg['automatedPlayersBotsPerRealCartela'] ?? 2),
             'enabledPatterns' => $data['enabledPatterns'] ?? BingoEngine::PATTERNS,
             'isVip' => (bool) ($data['isVip'] ?? false),
             
             'inviteCode' => $data['inviteCode'] ?? null,
             'amharicName' => trim((string) (
                 $data['amharicName']
                 ?? ($existing ? (
                     (json_decode($existing->config, true)['amharicName'] ?? null)
                     ?? $existing->name
                 ) : ($data['name'] ?? ''))
             )),
         ]
     );

     if (
         $config['stake'] < 1 ||
         $config['rakePercent'] < 0 ||
         $config['rakePercent'] >= 100 ||
         $config['minPlayers'] < 1 ||
         $config['maxPlayers'] < $config['minPlayers'] ||
         $config['automatedPlayerCount'] < 0 || $config['automatedPlayerCount'] > 200 ||
         $config['automatedPlayersTriggerBelow'] < 1 || $config['automatedPlayersTriggerBelow'] > 200 ||
         $config['automatedPlayersMaxStakeBudget'] < 0 || $config['automatedPlayersMaxHouseExposure'] < 0 || !in_array($config['automatedPlayersStrategy'], ['conservative', 'balanced', 'aggressive'], true) || $config['automatedPlayersBotsPerRealCartela'] < 1 || $config['automatedPlayersBotsPerRealCartela'] > 20 ||
         $config['automatedPlayersTarget'] < 1 || ($config['automatedPlayersEnabled'] && $config['automatedPlayersTarget'] > $config['maxPlayers']) ||
         $config['selectionSeconds'] < 5 ||
         $config['drawInterval'] < 1
     ) {
         throw new RuntimeException('Invalid room configuration');
     }

     $room = [
         'id' => $id,
         'name' => trim((string) ($data['name'] ?? '')),
         'status' => $existing->status ?? 'active',
         'config' => json_encode($config),
         'updated_at' => now(),
     ];

     if ($room['name'] === '') {
         throw new RuntimeException('Room name is required');
     }

     if ($existing) {
         DB::table('game_rooms')->where('id', $id)->update($room);
     } else {
         $room['created_at'] = now();
         DB::table('game_rooms')->insert($room);
     }

     return $this->room($id);
 }

 public function setRoomStatus(string $id, string $status): array
 {
     if (!in_array($status, ['active', 'paused', 'maintenance'], true)) {
         throw new RuntimeException('Invalid room status');
     }

     $room = DB::table('game_rooms')->where('id', $id)->first();

     if (!$room) {
         throw new RuntimeException('Room not found');
     }

     DB::table('game_rooms')->where('id', $id)->update([
         'status' => $status,
         'updated_at' => now(),
     ]);

     return $this->room($id);
 }

 public function settings():array{
  $room=DB::table('game_rooms')->where('id','room-1')->first();
  return $room?array_merge($this->defaults(),json_decode($room->config,true)?:[]):$this->defaults();
 }

 public function room(string $id='room-1'):array{
  $defaults=$this->defaults();$x=DB::table('game_rooms')->where('id',$id)->first();
  if(!$x) throw new RuntimeException('Room not found');
  return array_merge(['id'=>$x->id,'name'=>$x->name,'status'=>$x->status],json_decode($x->config,true)?:$defaults);
 }

 public function updateSettings(array $settings, ?string $roomId = null):array{
  // "selectionDuration" is only a UI alias of selectionSeconds; never persist it.
  unset($settings['selectionDuration']);
  $query=DB::table('game_rooms');
  if($roomId!==null&&$roomId!=='')$query->where('id',$roomId);
  $rooms=$query->get();
  if($rooms->isEmpty())throw new RuntimeException('Room not found');
  $defaults=$this->defaults();
  $updates=[];
  foreach($rooms as $row){
   $next=array_merge($defaults,json_decode($row->config,true)?:[],$settings);
   unset($next['selectionDuration']);
   $next['maxCartelasPerPlayer']=max(1,min(200,(int)($next['maxCartelasPerPlayer']??1)));
   if(isset($next['enabledPatterns'])){
    $next['enabledPatterns']=is_array($next['enabledPatterns'])?array_values(array_intersect($next['enabledPatterns'],BingoEngine::PATTERNS)):[];
    if(count($next['enabledPatterns'])<1)throw new RuntimeException('Enable at least one winning pattern');
   }
   if($next['stake']<=0||$next['rakePercent']<0||$next['rakePercent']>=100||$next['minPlayers']<1||$next['selectionSeconds']<5||$next['drawInterval']<1)throw new RuntimeException('Invalid game settings');
   $updates[$row->id]=$next;
  }
  DB::transaction(function()use($updates){
   foreach($updates as $id=>$config)DB::table('game_rooms')->where('id',$id)->update(['config'=>json_encode($config),'updated_at'=>now()]);
  });
  return reset($updates);
 }

 public function round(string $roomId='room-1'):object{
  $q=DB::table('game_rounds')->where('room_id',$roomId)->latest('created_at')->first();
  if(!$q)return $this->createRound($roomId);
  return $q;
 }

 public function createRound(string $roomId):object{
  $s=$this->room($roomId);$id=(string)Str::uuid();$snapshot=$s;$seed=bin2hex(random_bytes(32));$code='BB-'.strtoupper(Str::random(8));
  DB::table('game_rounds')->insert(['id'=>$id,'room_id'=>$roomId,'round_code'=>$code,'phase'=>'SELECTION','started_at'=>null,'config'=>json_encode($snapshot),'timer_seconds'=>$s['selectionSeconds'],'seed_hash'=>hash('sha256',$seed),'seed'=>$seed,'balls_drawn'=>json_encode([]),'winners'=>json_encode([]),'created_at'=>now(),'updated_at'=>now()]);
  return DB::table('game_rounds')->where('id',$id)->first();
 }

 
public function playerState(string $uid): array
{
    $u = DB::table('users')->where('id', $uid)->first();

    if (!$u) {
        throw new RuntimeException('Player not found');
    }

    $rooms = array_values(array_filter(
        $this->rooms(),
        fn ($room) => ($room['status'] ?? 'active') === 'active'
    ));

    $roundStates = [];
    $cartelaReservations = [];

    foreach ($rooms as $room) {
        $q = $this->round($room['id']);

        $cfg = array_merge(
            $room,
            json_decode($q->config, true) ?: []
        );

        $reservations = DB::table('cartela_reservations')
            ->leftJoin('users', 'users.id', '=', 'cartela_reservations.user_id')
            ->where('cartela_reservations.round_id', $q->id)
            ->select('cartela_reservations.*', 'users.is_bot')
            ->get();
        $confirmedReservations = $reservations->where('status', 'confirmed');

        $prize = $this->engine->prizePool(
            $confirmedReservations->count(),
            (float) $cfg['stake'],
            (float) $cfg['rakePercent']
        );

        $balls = json_decode($q->balls_drawn, true) ?: [];
        $winners = json_decode($q->winners, true) ?: [];

        $roundStates[$room['id']] = [
            'roundId' => $q->id,
            'id' => $q->id,
            'roomId' => $q->room_id,
            'roundCode' => $q->round_code,
            'phase' => $q->phase,
            'timerSeconds' => (int) $q->timer_seconds,
            'ballsDrawn' => $balls,
            'currentBall' => $balls ? end($balls) : null,
            'previousBalls' => array_reverse(array_slice($balls, -10, 9)),
            'playersCount' => $confirmedReservations->pluck('user_id')->unique()->count(),
            'totalPool' => $prize['totalPool'],
            'derashPrize' => $prize['derashPrize'],
            'rakeEarned' => $prize['rakeEarned'],
            'seedCommitment' => $q->seed_hash,
            'revealedSeed' => in_array($q->phase, ['FINISHED', 'PAYOUT'], true)
                ? $q->seed
                : null,
            'winners' => $winners,
            'startedAt' => $q->started_at
                ? strtotime($q->started_at) * 1000
                : null,
            'finishedAt' => $q->finished_at
                ? strtotime($q->finished_at) * 1000
                : null,
        ];

        // The player UI consumes reservations as an array of CartelaReservation
        // objects. Returning an object keyed by cartela_id makes .find()/.map()
        // throw at render time immediately after a successful confirmation.
        $cartelaReservations[$room['id']] = $reservations
            ->map(fn ($x) => [
                'cartelaId' => (int) $x->cartela_id,
                'userId' => $x->user_id,
                'username' => $x->username,
                'isBot' => (bool) ($x->is_bot ?? false),
                'status' => $x->status,
                'walletType' => $x->wallet_type,
                'reservedAt' => strtotime($x->reserved_at) * 1000,
            ])
            ->values()
            ->all();
    }

    return [
        'player' => [
            'id' => $u->id,
            'username' => $u->username,
            'fullName' => $u->full_name,
            'phone' => $u->phone,
            'phoneVerifiedAt' => $u->phone_verified_at,
            'telegramId' => 'ID:' . $u->telegram_id,
            'mainWalletBalance' => (float) $u->main_balance,
            'playWalletBalance' => (float) $u->play_balance,
            'totalDeposited' => (float) $u->total_deposited,
            'totalWithdrawn' => (float) $u->total_withdrawn,
            'roundsPlayed' => (int) $u->rounds_played,
            'roundsWon' => (int) $u->rounds_won,
            // These controls are not implemented in the database yet; do not invent values.
            'isBanned' => null,
            'riskScore' => null,
            'kycStatus' => (!empty($u->full_name) && !empty($u->phone) && !empty($u->phone_verified_at)) ? 'verified' : 'unverified',
            'selfExclusionUntil' => null,
            'dailyDepositLimit' => null,
        ],
        'rooms' => $rooms,
        'roundStates' => $roundStates,
        'cartelaReservations' => $cartelaReservations,
        'todayPayouts' => (float) DB::table('ledger')
            ->where('type', 'WIN_PAYOUT')
            ->where('created_at', '>=', now()->startOfDay())
            ->sum('amount'),
    ];
}

 private function ledger(object $u,string $type,string $wallet,float $amount,float $after,string $ref,string $desc):void{DB::table('ledger')->insert(['id'=>(string)Str::uuid(),'user_id'=>$u->id,'type'=>$type,'wallet_type'=>$wallet,'amount'=>$amount,'balance_after'=>$after,'reference_id'=>$ref,'description'=>$desc,'created_at'=>now(),'updated_at'=>now()]);}

 private function killSwitch():bool{return (string)DB::table('system_state')->where('key','killSwitch')->value('value')==='1';}

 private function awardReferralBonus(string $newPlayerId): void
 {
  $configValue = DB::table('system_state')->where('key', 'telegram_bot_config')->value('value');
  $config = is_string($configValue) ? (json_decode($configValue, true) ?: []) : [];
  if (array_key_exists('referralBonusEnabled', $config) && !$config['referralBonusEnabled']) return;
  $bonus = round((float) ($config['referralBonusAmount'] ?? 10), 2);
  if ($bonus <= 0) return;

  $newPlayer = DB::table('users')->where('id', $newPlayerId)->lockForUpdate()->first();
  if (!$newPlayer || empty($newPlayer->referred_by) || $newPlayer->referral_bonus_awarded_at) return;
  $referrer = DB::table('users')->where('id', $newPlayer->referred_by)->lockForUpdate()->first();
  if (!$referrer || $referrer->id === $newPlayer->id) return;

  $newBalance = round((float) $newPlayer->play_balance + $bonus, 2);
  $referrerBalance = round((float) $referrer->play_balance + $bonus, 2);
  DB::table('users')->where('id', $newPlayer->id)->update([
   'play_balance' => $newBalance, 'referral_bonus_awarded_at' => now(), 'updated_at' => now(),
  ]);
  DB::table('users')->where('id', $referrer->id)->update([
   'play_balance' => $referrerBalance, 'updated_at' => now(),
  ]);
  $this->ledger($newPlayer, 'REFERRAL_BONUS', 'PLAY', $bonus, $newBalance, 'REFERRAL:'.$newPlayer->id.':NEW', 'Referral reward after first game participation');
  $this->ledger($referrer, 'REFERRAL_BONUS', 'PLAY', $bonus, $referrerBalance, 'REFERRAL:'.$newPlayer->id.':INVITER', 'Referral reward for inviting '.$newPlayer->username);
 }

 public function select(string $uid,string $roomId,int $card):array{return DB::transaction(function()use($uid,$roomId,$card){
  if($this->killSwitch())throw new RuntimeException('System is in maintenance mode');
  $room=$this->room($roomId);$q=$this->round($roomId);$roundConfig=json_decode($q->config,true)?:[];$cfg=array_merge($room,$roundConfig);$cfg['maxCartelasPerPlayer']=(int)($room['maxCartelasPerPlayer']??$roundConfig['maxCartelasPerPlayer']??1);if($q->phase!=='SELECTION'||$room['status']!=='active')throw new RuntimeException('Cartela selection is closed');if($card<1||$card>9999)throw new RuntimeException('Invalid cartela');
  $taken=DB::table('cartela_reservations')->where(['round_id'=>$q->id,'cartela_id'=>$card])->first();if($taken&&$taken->user_id!==$uid)throw new RuntimeException('Cartela is already taken');
  $u=DB::table('users')->where('id',$uid)->lockForUpdate()->first();if(!$u)throw new RuntimeException('Player account not found');if(empty($u->phone)||empty($u->phone_verified_at))throw new RuntimeException('Please share and verify your Telegram phone number before playing');
  $old=DB::table('cartela_reservations')->where(['round_id'=>$q->id,'user_id'=>$uid,'cartela_id'=>$card])->lockForUpdate()->first();if($old)return ['ok'=>true,'success'=>true,'message'=>'Already selected'];
  $playerCartelaCount=DB::table('cartela_reservations')->where(['round_id'=>$q->id,'user_id'=>$uid,'status'=>'confirmed'])->count();
  $playerLimit=max(1,min(200,(int)($cfg['maxCartelasPerPlayer']??1)));
  if($playerCartelaCount >= $playerLimit)throw new RuntimeException('You have reached the maximum of '.$playerLimit.' cartelas for this room.');
  $confirmedCount=DB::table('cartela_reservations')->where(['round_id'=>$q->id,'status'=>'confirmed'])->count();if($confirmedCount >= (int)($cfg['maxPlayers']??200))throw new RuntimeException('Room has reached its maximum participant count');
  $wallet='play_balance';if((float)$u->play_balance<(float)$cfg['stake'])throw new RuntimeException('Insufficient Play Wallet balance. Move money from Main Wallet to Play Wallet before selecting a cartela.');
  if($old){$ow=$old->wallet_type==='PLAY'?'play_balance':'main_balance';$refund=round((float)$u->{$ow}+(float)$cfg['stake'],2);DB::table('users')->where('id',$uid)->update([$ow=>$refund,'updated_at'=>now()]);$this->ledger($u,'STAKE_REFUNDED',$old->wallet_type,(float)$cfg['stake'],$refund,'REFUND-'.$q->round_code.':'.$old->id,'Previous cartela stake refunded');DB::table('cartela_reservations')->where('id',$old->id)->delete();}
  $reservationId=(string)Str::uuid();$after=round((float)$u->{$wallet}-(float)$cfg['stake'],2);$data=[$wallet=>$after,'updated_at'=>now()];DB::table('users')->where('id',$uid)->update($data);$this->ledger($u,'STAKE_RESERVED',$wallet==='play_balance'?'PLAY':'MAIN',-(float)$cfg['stake'],$after,'STAKE-'.$q->round_code.':'.$reservationId,'Stake reserved for Cartela #'.$card);
  try {
   DB::table('cartela_reservations')->insert(['id'=>$reservationId,'round_id'=>$q->id,'cartela_id'=>$card,'user_id'=>$uid,'username'=>$u->username,'status'=>'confirmed','reserved_at'=>now(),'wallet_type'=>$wallet==='play_balance'?'PLAY':'MAIN']);
  } catch (\Throwable $e) {
   Log::error('Cartela reservation insert failed', ['round_id' => $q->id, 'cartela_id' => $card, 'user_id' => $uid, 'exception' => $e->getMessage()]);
   $message = strtolower($e->getMessage());
   if (str_contains($message, 'cartela_reservations_round_id_cartela_id_unique') || str_contains($message, 'duplicate entry') && str_contains($message, (string) $card)) {
    throw new RuntimeException('Cartela is already taken');
   }
   if (str_contains($message, 'cartela_reservations_round_id_user_id_unique')) {
    throw new RuntimeException('The server database still has the old one-cartela-per-player restriction. Run php artisan migrate on the hosted server.');
   }
   throw new RuntimeException('Could not reserve this cartela because of a server database error. Please try again.');
  }
  return ['ok'=>true,'success'=>true,'message'=>"Cartela #$card confirmed!"];
 });}

 public function release(string $uid,string $roomId,int $card):array{return DB::transaction(function()use($uid,$roomId,$card){
  $room=$this->room($roomId);$q=$this->round($roomId);$cfg=array_merge($room,json_decode($q->config,true)?:[]);$x=DB::table('cartela_reservations')->where(['round_id'=>$q->id,'cartela_id'=>$card,'user_id'=>$uid])->lockForUpdate()->first();if(!$x||$q->phase!=='SELECTION')throw new RuntimeException('Cartela not reserved');$u=DB::table('users')->where('id',$uid)->lockForUpdate()->first();if(!$u)throw new RuntimeException('Player account not found');$w=$x->wallet_type==='PLAY'?'play_balance':'main_balance';$after=round((float)$u->{$w}+(float)$cfg['stake'],2);DB::table('cartela_reservations')->where('id',$x->id)->delete();DB::table('users')->where('id',$uid)->update([$w=>$after,'updated_at'=>now()]);$this->ledger($u,'STAKE_REFUNDED',$x->wallet_type,(float)$cfg['stake'],$after,'REFUND-'.$q->round_code.':'.$x->id,'Stake refunded');return ['ok'=>true,'success'=>true,'message'=>'Cartela released and stake refunded','balanceAfter'=>$after];
 });}

 /**
  * Winners are detected automatically after every drawn ball (see advance()), so a manual
  * claim is never needed. Kept only so older cached clients get a harmless answer.
  */
 public function claim(string $uid,string $roomId):array{
  return ['ok'=>true,'success'=>true,'message'=>'Bingo is detected automatically after every ball. No claim is needed.'];
 }

 private function recordWinner(object $q,array $room,object $x,string $uid,array $chk):array{
  $cfg=array_merge($room,json_decode($q->config,true)?:[]);$claims=DB::table('claims')->where('round_id',$q->id)->count();$count=DB::table('cartela_reservations')->where(['round_id'=>$q->id,'status'=>'confirmed'])->count();$pool=$this->engine->prizePool($count,(float)$cfg['stake'],(float)$cfg['rakePercent'])['derashPrize'];$winnerCount=$claims+1;$prize=round($pool/$winnerCount,2);
  $u=DB::table('users')->where('id',$uid)->lockForUpdate()->first();if(!$u)throw new RuntimeException('Player account not found');$after=round((float)$u->main_balance+$prize,2);DB::table('claims')->insert(['id'=>(string)Str::uuid(),'round_id'=>$q->id,'user_id'=>$uid,'claimed_at'=>now()]);$winners=json_decode($q->winners,true)?:[];$called = json_decode($q->balls_drawn, true) ?: [];
  $lastBall = $called ? end($called) : null;
  $winners[]=['userId'=>$uid,'username'=>$u->username,'isBot'=>false,'cartelaId'=>(int)$x->cartela_id,'cartela'=>$this->engine->cartela((int)$x->cartela_id)['matrix'],'pattern'=>$chk['winningPatterns'][0],'winningBall'=>is_array($lastBall) ? (int)($lastBall['number'] ?? 0) : (int)($lastBall ?? 0),'prizeAmount'=>$prize];DB::table('users')->where('id',$uid)->update(['main_balance'=>$after,'rounds_won'=>(int)$u->rounds_won+1,'updated_at'=>now()]);$this->ledger($u,'WIN_PAYOUT','MAIN',$prize,$after,$q->id.':'.$uid,'Derash payout');DB::table('game_rounds')->where('id',$q->id)->update(['phase'=>'FINISHED','timer_seconds'=>5,'finished_at'=>now(),'winners'=>json_encode($winners),'updated_at'=>now()]);return ['ok'=>true,'success'=>true,'message'=>'BINGO CLAIM VERIFIED!','balanceAfter'=>$after,'prize'=>$prize];
 }

 public function advance(string $roomId='room-1'):void{
  DB::transaction(function()use($roomId){
   if($this->killSwitch())return;$room=$this->room($roomId);if($room['status']!=='active')return;
   $q=DB::table('game_rounds')->where('id',$this->round($roomId)->id)->lockForUpdate()->first();if(!$q)return;
   // Selection time begins only after the first cartela has been reserved. A room with no players waits indefinitely.
   if ($q->phase === 'SELECTION') {
    $hasSelection = DB::table('cartela_reservations')->where(['round_id' => $q->id, 'status' => 'confirmed'])->exists();
    if (!$hasSelection) return;
    // Activate bots near countdown end whenever the number of distinct real players is below the configured threshold. Cartelas do not count as people.
    if ((int) $q->timer_seconds <= 7) {
     $roundCfg = json_decode($q->config, true) ?: [];
     $automationKeys = ['automatedPlayersEnabled', 'automatedPlayerCount', 'automatedPlayersTriggerBelow', 'automatedPlayersTarget', 'automatedPlayersRiskControlEnabled', 'automatedPlayersMaxStakeBudget', 'automatedPlayersMaxHouseExposure', 'automatedPlayersStrategy', 'automatedPlayersManualOverrideEnabled', 'automatedPlayersBotsPerRealCartela', 'automatedPlayersMinCardsPerPlayer', 'maxPlayers'];
     $automationCfg = array_merge($roundCfg, array_intersect_key($room, array_flip($automationKeys)));
     if (!empty($automationCfg['automatedPlayersEnabled'])) {
      $realCount = DB::table('cartela_reservations')->join('users', 'users.id', '=', 'cartela_reservations.user_id')->where('cartela_reservations.round_id', $q->id)->where('cartela_reservations.status', 'confirmed')->where('users.is_bot', false)->distinct()->count('users.id');
      // Player-count AND cards-per-player thresholds are evaluated inside botPlan().
      if ($realCount > 0) $this->seatBotsSafely($q, $room, array_merge($roundCfg, $automationCfg));
     }
    }
   }
   if((int)$q->timer_seconds>1){DB::table('game_rounds')->where('id',$q->id)->decrement('timer_seconds');return;}
   $balls=json_decode($q->balls_drawn,true)?:[];$winners=json_decode($q->winners,true)?:[];
   if($q->phase==='SELECTION'){
    $roundCfg = json_decode($q->config, true) ?: [];
    $cfg = array_merge($room, $roundCfg);
    // Apply live participation thresholds while preserving the round's financial/gameplay snapshot.
    $cfg['minPlayers'] = (int) ($room['minPlayers'] ?? $roundCfg['minPlayers'] ?? 2);
    $cfg['maxPlayers'] = (int) ($room['maxPlayers'] ?? $roundCfg['maxPlayers'] ?? 200);
    // Room automation controls are live admin settings. A round's config is a
    // snapshot created before the admin may have enabled bots, so use the latest
    // room values for these controls while preserving the round's stake/rules.
    $automationKeys = ['automatedPlayersEnabled', 'automatedPlayerCount', 'automatedPlayersTriggerBelow', 'automatedPlayersTarget', 'automatedPlayersRiskControlEnabled', 'automatedPlayersMaxStakeBudget', 'automatedPlayersMaxHouseExposure', 'automatedPlayersStrategy', 'automatedPlayersManualOverrideEnabled', 'automatedPlayersBotsPerRealCartela', 'automatedPlayersMinCardsPerPlayer', 'maxPlayers'];
    $automationCfg = array_merge($roundCfg, array_intersect_key($room, array_flip($automationKeys)));
    // Retry bot activation at expiry so a missed/late scheduler tick does not skip it.
    if (!empty($automationCfg['automatedPlayersEnabled'])) {
     $this->seatBotsSafely($q, $room, array_merge($roundCfg, $automationCfg));
    }
    // Minimum participation is measured in distinct people, never number of cartelas.
    $count=DB::table('cartela_reservations')->where(['round_id'=>$q->id,'status'=>'confirmed'])->distinct()->count('user_id');
    if($count<(int)$cfg['minPlayers']){DB::table('game_rounds')->where('id',$q->id)->update(['timer_seconds'=>10,'updated_at'=>now()]);return;}
    $participants=DB::table('cartela_reservations')->join('users','users.id','=','cartela_reservations.user_id')->where('cartela_reservations.round_id',$q->id)->where('cartela_reservations.status','confirmed')->where('users.is_bot',false)->distinct()->pluck('users.id');
    // Count a round once per real person, not once per cartela. This transition is
    // protected by the round row lock and committed with the phase change.
    if ($participants->isNotEmpty()) {
     DB::table('users')->whereIn('id', $participants)->increment('rounds_played', 1, ['updated_at' => now()]);
    }
    foreach($participants as $participantId)$this->awardReferralBonus((string)$participantId);
    DB::table('game_rounds')->where('id',$q->id)->update(['phase'=>'DRAWING','started_at'=>now(),'timer_seconds'=>$cfg['drawInterval'],'updated_at'=>now()]);return;
   }
   if($q->phase==='DRAWING'){
    $cfg=array_merge($room,json_decode($q->config,true)?:[]);$seq=$this->engine->drawSequence($q->seed);$n=$seq[count($balls)]??null;if($n===null){DB::table('game_rounds')->where('id',$q->id)->update(['phase'=>'FINISHED','timer_seconds'=>1,'finished_at'=>now(),'updated_at'=>now()]);return;}
    $balls[]=['number'=>$n,'letter'=>$this->letter($n),'seq'=>count($balls)+1,'timestamp'=>now()->timestamp*1000];
    $xs=DB::table('cartela_reservations')->join('users','users.id','=','cartela_reservations.user_id')->where('cartela_reservations.round_id',$q->id)->where('cartela_reservations.status','confirmed')->select('cartela_reservations.*','users.is_bot')->lockForUpdate()->get();$wins=[];
    foreach($xs as $x){$chk=$this->engine->check($this->engine->cartela((int)$x->cartela_id)['matrix'],array_map(fn($b)=>$b['number'],$balls),$cfg['enabledPatterns']);if($chk['hasWon'])$wins[]=['userId'=>$x->user_id,'username'=>$x->username,'isBot'=>(bool)($x->is_bot??false),'cartelaId'=>(int)$x->cartela_id,'cartela'=>$this->engine->cartela((int)$x->cartela_id)['matrix'],'pattern'=>$chk['winningPatterns'][0],'winningBall'=>$n,'prizeAmount'=>0];}
    if($wins){$wins=array_values(array_reduce($wins,function($c,$w){if(!isset($c[$w['userId']]))$c[$w['userId']]=$w;return $c;},[]));$pool=$this->engine->prizePool($xs->count(),(float)$cfg['stake'],(float)$cfg['rakePercent'])['derashPrize'];$prize=floor(($pool/count($wins))*100)/100;$wins=array_map(fn($w)=>array_merge($w,['prizeAmount'=>$prize]),$wins);$winners=$wins;DB::table('game_rounds')->where('id',$q->id)->update(['phase'=>'FINISHED','timer_seconds'=>5,'balls_drawn'=>json_encode($balls),'winners'=>json_encode($winners),'finished_at'=>now(),'updated_at'=>now()]);$this->payoutWinners($q->id,$winners);return;}
    DB::table('game_rounds')->where('id',$q->id)->update(['balls_drawn'=>json_encode($balls),'timer_seconds'=>$cfg['drawInterval'],'updated_at'=>now()]);return;
   }
   if($q->phase==='FINISHED'){$winners=$winners?:[];$this->payoutWinners($q->id,$winners);DB::table('game_rounds')->where('id',$q->id)->update(['phase'=>'PAYOUT','timer_seconds'=>2,'updated_at'=>now()]);return;}
   if($q->phase==='PAYOUT'){$this->createRound($roomId);return;}
  });
 }

 private function payoutWinners(string $roundId,array $winners):void{
  $round=DB::table('game_rounds')->where('id',$roundId)->first();
  foreach($winners as $w){$ref=$roundId.':'.$w['userId'];$u=DB::table('users')->where('id',$w['userId'])->lockForUpdate()->first();if(!$u)throw new RuntimeException('Winner account not found');if((bool)($u->is_bot??false)){$this->houseWallet->post('BOT_WIN',(float)$w['prizeAmount'],$ref,'House-controlled automated participant won round '.$roundId);continue;}$already=DB::table('ledger')->where(['reference_id'=>$ref,'type'=>'WIN_PAYOUT'])->exists();if($already)continue;$after=round((float)$u->main_balance+(float)$w['prizeAmount'],2);DB::table('users')->where('id',$u->id)->update(['main_balance'=>$after,'rounds_won'=>DB::raw('rounds_won+1'),'updated_at'=>now()]);$this->ledger($u,'WIN_PAYOUT','MAIN',(float)$w['prizeAmount'],$after,$ref,'Derash payout');}
  if($round){$cfg=json_decode($round->config,true)?:[];$count=DB::table('cartela_reservations')->where(['round_id'=>$roundId,'status'=>'confirmed'])->count();$pool=$this->engine->prizePool($count,(float)($cfg['stake']??0),(float)($cfg['rakePercent']??0));if($pool['rakeEarned']>0)$this->houseWallet->post('RAKE_FEE',(float)$pool['rakeEarned'],$roundId,'House rake for round '.$roundId);}
 }

 /**
  * Seat automated players without ever being able to stall the room. Any failure while creating bots
  * (database constraint, wallet error, ...) is rolled back on its own savepoint, logged, and shown on the
  * admin dashboard, while the round itself keeps running instead of retrying the same failing tick forever.
  */
 private function seatBotsSafely(object $round,array $room,array $cfg):void{
  try{
   DB::transaction(fn()=>$this->ensureAutomatedPlayers($round,$room,$cfg));
  }catch(\Throwable $e){
   Log::error('Automated participants could not be seated in '.($round->room_id??'?').': '.$e->getMessage());
   $this->noteBotStatus((string)($round->room_id??''),'blocked',['Bot seating failed: '.$e->getMessage()]);
  }
 }

 private function ensureAutomatedPlayers(object $round,array $room,array $cfg):bool{
  $realCount=DB::table('cartela_reservations')->join('users','users.id','=','cartela_reservations.user_id')->where('cartela_reservations.round_id',$round->id)->where('cartela_reservations.status','confirmed')->where('users.is_bot',false)->distinct()->count('users.id');
  $realCartelaCount=DB::table('cartela_reservations')->join('users','users.id','=','cartela_reservations.user_id')->where('cartela_reservations.round_id',$round->id)->where('cartela_reservations.status','confirmed')->where('users.is_bot',false)->count();
  $existingBotRows=DB::table('cartela_reservations')->join('users','users.id','=','cartela_reservations.user_id')->where('cartela_reservations.round_id',$round->id)->where('cartela_reservations.status','confirmed')->where('users.is_bot',true)->select('cartela_reservations.*')->orderByDesc('cartela_reservations.reserved_at')->get();
  $plan=$this->botPlan($cfg,$realCount,$realCartelaCount);
  $desired=$plan['desired'];
  // Record WHY no bots will join so the admin dashboard can show it (previously this failed silently).
  if($desired===0)$this->noteBotStatus((string)($round->room_id??''),'blocked',$plan['blockers']);
  $existingBots=$existingBotRows->count();
  if($existingBots>$desired){
   foreach($existingBotRows->take($existingBots-$desired) as $bot){
    $this->houseWallet->post('BOT_STAKE_REFUND',(float)$cfg['stake'],'BOT-REFUND-'.$bot->id,'Automated participant removed before round start '.$round->round_code);
    DB::table('cartela_reservations')->where('id',$bot->id)->delete();
   }
   $existingBots=$desired;
  }
  $toAdd=max(0,$desired-$existingBots);
  if($toAdd===0){
   if($desired>0)$this->noteBotStatus((string)($round->room_id??''),'ok',[$existingBots.' automated participant(s) already in the round.']);
   return $existingBots >= $desired;
  }
  $walletShort=false;
  $used=DB::table('cartela_reservations')->where('round_id',$round->id)->pluck('cartela_id')->map(fn($n)=>(int)$n)->all();$free=array_values(array_diff(range(1,200),$used));shuffle($free);$names=['Abebe','Hana','Dawit','Mimi','Yonas','Sara','Mekdes','Samuel','Liya','Nati','Selam','Bereket','Rahel','Daniel','Eden','Nahom','Tigist','Robel','Meron','Henok'];
  for($i=0;$i<$toAdd&&isset($free[$i]);$i++){
   if($this->houseWallet->balance()<(float)$cfg['stake']){$walletShort=true;break;}
   $id='bot-'.Str::uuid();$username=$names[array_rand($names)].'_'.strtoupper(Str::random(4));$now=now();
   DB::table('users')->insert(['id'=>$id,'telegram_id'=>null,'username'=>$username,'is_bot'=>true,'full_name'=>'House-controlled automated participant','main_balance'=>0,'play_balance'=>0,'rounds_played'=>0,'rounds_won'=>0,'total_deposited'=>0,'total_withdrawn'=>0,'created_at'=>$now,'updated_at'=>$now]);
   $reservationId=(string)Str::uuid();$card=(int)$free[$i];
   $this->houseWallet->post('BOT_STAKE',-(float)$cfg['stake'],$reservationId,'Automated participant stake for round '.$round->round_code);
   DB::table('cartela_reservations')->insert(['id'=>$reservationId,'round_id'=>$round->id,'cartela_id'=>$card,'user_id'=>$id,'username'=>$username,'status'=>'confirmed','reserved_at'=>$now,'wallet_type'=>'HOUSE']);
  }
  $finalBots=DB::table('cartela_reservations')->join('users','users.id','=','cartela_reservations.user_id')->where('cartela_reservations.round_id',$round->id)->where('cartela_reservations.status','confirmed')->where('users.is_bot',true)->count();
  $roomKey=(string)($round->room_id??'');
  if($walletShort){
   $this->noteBotStatus($roomKey,'blocked',['House wallet balance ('.number_format($this->houseWallet->balance(),2).') is below the room stake ('.number_format((float)$cfg['stake'],2).'). Fund the house wallet so automated participants can join.']);
  }elseif($finalBots<$desired){
   $this->noteBotStatus($roomKey,'blocked',['Only '.$finalBots.' of '.$desired.' automated participants could be seated (no free cartelas in 1-200).']);
  }elseif($desired>0){
   $this->noteBotStatus($roomKey,'ok',[$finalBots.' automated participant(s) seated.']);
  }
  return $finalBots >= $desired;
 }

 /**
  * Single source of truth for how many automated participants a room may seat.
  * Used by the live game and by the admin dashboard so both always agree.
  */
 public function botPlan(array $cfg,int $realCount,int $realCartelaCount):array{
  $enabled=!empty($cfg['automatedPlayersEnabled']);
  $count=(int)($cfg['automatedPlayerCount']??0);                          // maximum bots
  $below=max(1,(int)($cfg['automatedPlayersTriggerBelow']??10));          // real-players threshold
  $minCards=max(1,(int)($cfg['automatedPlayersMinCardsPerPlayer']??2));   // cards-per-player threshold
  $target=(int)($cfg['automatedPlayersTarget']??10);
  $maxPlayers=(int)($cfg['maxPlayers']??200);
  $stake=max(0.0,(float)($cfg['stake']??0));
  $riskOn=!array_key_exists('automatedPlayersRiskControlEnabled',$cfg)||!empty($cfg['automatedPlayersRiskControlEnabled']);
  $unlimited=100000;
  $blockers=[];

  // STEP 1 - cards first: how many cards does each real player hold on average?
  $cardsPerPlayer=$realCount>0?$realCartelaCount/$realCount:0.0;
  // STEP 2 - then the number of real players.
  $playersEnough=$realCount>=$below;
  $cardsEnough=$realCount>0&&$cardsPerPlayer>=$minCards;
  // Bots stay out ONLY when BOTH conditions are true. If either one fails, bots join.
  $selfSufficient=$playersEnough&&$cardsEnough;

  if(!$enabled)$blockers[]='Automated participants are disabled for this room.';
  if($enabled&&$count<=0)$blockers[]='Bot count is 0. Set "Maximum automated players" above 0.';
  if($enabled&&$realCount<=0)$blockers[]='Waiting for the first real player (bots only join after a real player).';
  if($enabled&&$realCount>0&&$selfSufficient)$blockers[]=sprintf('Real players (%d) reach the threshold (%d) AND cards per player (%.1f) reach %d, so bots stay out. Bots join as soon as either one is lower.',$realCount,$below,$cardsPerPlayer,$minCards);
  if($enabled&&$realCount>0&&$maxPlayers-$realCartelaCount<=0)$blockers[]='The room is already full of real cartelas (maxPlayers '.$maxPlayers.').';

  // Bots per real CARD (strategy default, or the admin override).
  $strategyCap=match(($cfg['automatedPlayersStrategy']??'balanced')){'conservative'=>1,'aggressive'=>5,default=>2};
  $perCardRatio=!empty($cfg['automatedPlayersManualOverrideEnabled'])?max(1,(int)($cfg['automatedPlayersBotsPerRealCartela']??$strategyCap)):$strategyCap;

  // Risk limits. Untouched legacy defaults (budget 50 / exposure 100) are scaled to the room stake so
  // higher-stake rooms are not silently blocked; custom values are respected; risk control OFF = no cap.
  $budgetRaw=(float)($cfg['automatedPlayersMaxStakeBudget']??50);
  $exposureRaw=(float)($cfg['automatedPlayersMaxHouseExposure']??100);
  $botExposure=$stake*max(0.0,1-((float)($cfg['rakePercent']??0)/100));
  $untouched=abs($budgetRaw-50.0)<0.001&&abs($exposureRaw-100.0)<0.001;
  if($riskOn){
   $budget=$untouched?$stake*max(1,$count):$budgetRaw;
   $maxExposure=$untouched?$botExposure*max(1,$count):$exposureRaw;
   $budgetCap=$stake>0?(int)floor(($budget+0.000001)/$stake):0;
   $exposureCap=$botExposure>0?(int)floor(($maxExposure+0.000001)/$botExposure):0;
   if($enabled&&$count>0&&$budgetCap<1)$blockers[]='Max stake budget ('.number_format($budget,2).') is below one stake ('.number_format($stake,2).'). Raise the budget or turn risk control off.';
   if($enabled&&$count>0&&$exposureCap<1)$blockers[]='Max house exposure ('.number_format($maxExposure,2).') is below one bot\'s exposure ('.number_format($botExposure,2).'). Raise the exposure limit or turn risk control off.';
  }else{$budgetCap=$unlimited;$exposureCap=$unlimited;}

  $shouldActivate=$realCount>0&&$enabled&&$count>0&&!$selfSufficient;
  // The number of bots follows the number of real CARDS (1 card and 5 cards never get the same bots),
  // then is clamped by the room limits (max bots, target participants, room capacity, wallet risk caps).
  $cardsBased=$realCartelaCount*$perCardRatio;
  // The bot count is driven by the number of cards. It is clamped only by the admin's maximum bots and by
  // the room capacity (real cards + bots may not exceed maxPlayers). The old "target participants" clamp is
  // gone: it counted people, so it made 1-card and 5-card players get the same bots, or none at all.
  $base=$shouldActivate?min($count,$cardsBased,max(0,$maxPlayers-$realCartelaCount)):0;
  $desired=$base>0?min($base,$budgetCap,$exposureCap):0;
  return ['desired'=>max(0,(int)$desired),'blockers'=>$blockers,'cardsBased'=>$cardsBased,'cardsPerPlayer'=>round($cardsPerPlayer,2),'selfSufficient'=>$selfSufficient,'caps'=>['perCartela'=>$perCardRatio,'budget'=>$budgetCap,'exposure'=>$exposureCap,'strategy'=>$strategyCap]];
 }

 /** Persist the latest bot outcome per room (only when it changes) for the admin dashboard. */
 private function noteBotStatus(string $roomId,string $status,array $messages):void{
  if($roomId==='')return;
  try{
   $key='bot_status:'.$roomId;$prev=DB::table('system_state')->where('key',$key)->value('value');$prev=is_string($prev)?(json_decode($prev,true)?:[]):[];
   if(($prev['status']??null)===$status&&($prev['messages']??null)===$messages)return;
   $value=json_encode(['status'=>$status,'messages'=>array_values($messages),'at'=>now()->toIso8601String()]);
   $exists=DB::table('system_state')->where('key',$key)->exists();
   if($exists)DB::table('system_state')->where('key',$key)->update(['value'=>$value,'updated_at'=>now()]);
   else DB::table('system_state')->insert(['key'=>$key,'value'=>$value,'created_at'=>now(),'updated_at'=>now()]);
   if($status==='blocked')\Illuminate\Support\Facades\Log::warning('Automated participants not joining in '.$roomId.': '.implode(' | ',$messages));
  }catch(\Throwable $e){/* diagnostics must never break the game loop */}
 }

 /** Admin dashboard data: wallet, per-room bot readiness, live bot seats and the last recorded outcome. */
 public function botDiagnostics():array{
  $balance=$this->houseWallet->balance();
  $rooms=[];
  foreach($this->rooms() as $room){
   $stake=(float)($room['stake']??0);
   $round=DB::table('game_rounds')->where('room_id',$room['id'])->orderByDesc('created_at')->first();
   $real=0;$realCartelas=0;$bots=0;$botNames=[];
   if($round){
    $rows=DB::table('cartela_reservations')->join('users','users.id','=','cartela_reservations.user_id')->where('cartela_reservations.round_id',$round->id)->where('cartela_reservations.status','confirmed')->select('cartela_reservations.user_id','cartela_reservations.username','cartela_reservations.cartela_id','users.is_bot')->get();
    $realRows=$rows->filter(fn($r)=>!(bool)$r->is_bot);$botRows=$rows->filter(fn($r)=>(bool)$r->is_bot);
    $real=$realRows->pluck('user_id')->unique()->count();$realCartelas=$realRows->count();$bots=$botRows->count();
    $botNames=$botRows->map(fn($r)=>$r->username.' #'.$r->cartela_id)->values()->all();
   }
   $live=$this->botPlan($room,$real,$realCartelas);
   $cap=$this->botPlan($room,1,1); // what a single real cartela would unlock
   $blockers=array_values(array_filter($cap['blockers'],fn($m)=>!str_contains($m,'Waiting for the first real player')&&!str_contains($m,'bots stay out')));
   if(!empty($room['automatedPlayersEnabled'])&&$stake>0&&$balance<$stake)$blockers[]='House wallet ('.number_format($balance,2).') is below the room stake ('.number_format($stake,2).'). Fund the house wallet.';
   if(($room['status']??'active')!=='active')$blockers[]='Room is '.($room['status']??'inactive').'.';
   $last=DB::table('system_state')->where('key','bot_status:'.$room['id'])->value('value');
   $rooms[]=[
    'id'=>$room['id'],'name'=>$room['name'],'status'=>$room['status']??'active','stake'=>$stake,
    'settings'=>array_intersect_key($room,array_flip(['automatedPlayersEnabled','automatedPlayerCount','automatedPlayersTriggerBelow','automatedPlayersTarget','automatedPlayersRiskControlEnabled','automatedPlayersMaxStakeBudget','automatedPlayersMaxHouseExposure','automatedPlayersStrategy','automatedPlayersManualOverrideEnabled','automatedPlayersBotsPerRealCartela','automatedPlayersMinCardsPerPlayer'])),
    'ready'=>empty($blockers),'blockers'=>$blockers,
    'capacityForOneRealCartela'=>$cap['desired'],'caps'=>$cap['caps'],
    'walletBotsAffordable'=>$stake>0?(int)floor(($balance+0.000001)/$stake):0,
    'round'=>['phase'=>$round->phase??null,'timerSeconds'=>(int)($round->timer_seconds??0),'realPlayers'=>$real,'realCartelas'=>$realCartelas,'bots'=>$bots,'botSeats'=>$botNames,'wantedBots'=>$live['desired']],
    'lastOutcome'=>is_string($last)?(json_decode($last,true)?:null):null,
   ];
  }
  $tick=null;try{$tick=\Illuminate\Support\Facades\Cache::get('beteseb:tick:last');}catch(\Throwable $e){}
  $botLedger=array_values(array_filter($this->houseWallet->recentLedger(300),fn($r)=>in_array($r['type'],['FUNDING','BOT_STAKE','BOT_STAKE_REFUND','BOT_WIN'],true)));
  return ['wallet'=>['balance'=>$balance,'profitLoss'=>$this->houseWallet->profitLoss()],'schedulerLastTick'=>$tick?(int)$tick:null,'serverTime'=>now()->timestamp,'killSwitch'=>$this->killSwitch(),'rooms'=>$rooms,'ledger'=>array_slice($botLedger,0,25)];
 }

 /** Update ONLY the bot controls of one room, leaving every other room setting untouched. */
 public function updateBotSettings(string $roomId,array $data):array{
  $room=DB::table('game_rooms')->where('id',$roomId)->first();
  if(!$room)throw new RuntimeException('Room not found');
  $cfg=array_merge($this->defaults(),json_decode($room->config,true)?:[]);
  $map=['automatedPlayersEnabled'=>'bool','automatedPlayerCount'=>'int','automatedPlayersTriggerBelow'=>'int','automatedPlayersTarget'=>'int','automatedPlayersRiskControlEnabled'=>'bool','automatedPlayersMaxStakeBudget'=>'float','automatedPlayersMaxHouseExposure'=>'float','automatedPlayersStrategy'=>'string','automatedPlayersManualOverrideEnabled'=>'bool','automatedPlayersBotsPerRealCartela'=>'int','automatedPlayersMinCardsPerPlayer'=>'int'];
  foreach($map as $k=>$t){
   if(!array_key_exists($k,$data))continue;
   $cfg[$k]=match($t){'bool'=>(bool)$data[$k],'int'=>(int)$data[$k],'float'=>round((float)$data[$k],2),default=>(string)$data[$k]};
  }
  if($cfg['automatedPlayerCount']<0||$cfg['automatedPlayerCount']>200
   ||$cfg['automatedPlayersTriggerBelow']<1||$cfg['automatedPlayersTriggerBelow']>200
   ||$cfg['automatedPlayersTarget']<1||$cfg['automatedPlayersTarget']>(int)($cfg['maxPlayers']??200)
   ||$cfg['automatedPlayersMaxStakeBudget']<0||$cfg['automatedPlayersMaxHouseExposure']<0
   ||!in_array($cfg['automatedPlayersStrategy'],['conservative','balanced','aggressive'],true)
   ||$cfg['automatedPlayersBotsPerRealCartela']<1||$cfg['automatedPlayersBotsPerRealCartela']>20||$cfg['automatedPlayersMinCardsPerPlayer']<1||$cfg['automatedPlayersMinCardsPerPlayer']>200)
   throw new RuntimeException('Invalid automated-player settings');
  DB::table('game_rooms')->where('id',$roomId)->update(['config'=>json_encode($cfg,JSON_UNESCAPED_UNICODE),'updated_at'=>now()]);
  return $this->room($roomId);
 }

 private function letter(int $n):string{return $n<=15?'B':($n<=30?'I':($n<=45?'N':($n<=60?'G':'O')));}
}