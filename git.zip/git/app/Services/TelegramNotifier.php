<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * Sends a plain text message to a player through the Telegram bot.
 * It never throws: a failed notification must never undo or block a wallet operation.
 */
class TelegramNotifier
{
    /** @param string|null $telegramId the player's Telegram id (also the private chat id). */
    public function send(?string $telegramId, string $text): bool
    {
        $telegramId = trim((string) $telegramId);
        $token = trim((string) config('services.telegram.bot_token', ''));
        if ($telegramId === '' || $token === '' || strlen($token) > 256) {
            return false;
        }

        try {
            $options = ['verify' => config('services.telegram.ca_bundle') ?: true];
            $response = Http::withOptions($options)
                ->timeout(8)
                ->connectTimeout(5)
                ->post('https://api.telegram.org/bot' . $token . '/sendMessage', [
                    'chat_id' => $telegramId,
                    'text' => $text,
                ]);
            if (!$response->ok() || !($response->json('ok') ?? false)) {
                Log::warning('Telegram notification was not delivered', [
                    'status' => $response->status(),
                    'description' => $response->json('description'),
                ]);
                return false;
            }
            return true;
        } catch (\Throwable $e) {
            Log::warning('Telegram notification failed: ' . $e->getMessage());
            return false;
        }
    }

    /** Convenience: notify a player by user id. Bots and players without Telegram are skipped. */
    public function sendToUser(string $userId, string $text): bool
    {
        $telegramId = DB::table('users')->where('id', $userId)->where('is_bot', false)->value('telegram_id');
        return $this->send(is_string($telegramId) ? $telegramId : null, $text);
    }
}
