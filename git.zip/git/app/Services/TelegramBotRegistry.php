<?php

namespace App\Services;

use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Throwable;

class TelegramBotRegistry
{
    private const STATE_KEY = 'telegram_bot_registry';

    private function raw(): array
    {
        $value = DB::table('system_state')->where('key', self::STATE_KEY)->value('value');
        $decoded = is_string($value) ? json_decode($value, true) : null;
        return is_array($decoded) ? array_values(array_filter($decoded, 'is_array')) : [];
    }

    private function persist(array $items): void
    {
        $payload = json_encode(array_values($items), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
        $exists = DB::table('system_state')->where('key', self::STATE_KEY)->exists();
        if ($exists) {
            DB::table('system_state')->where('key', self::STATE_KEY)->update([
                'value' => $payload,
                'updated_at' => now(),
            ]);
            return;
        }
        DB::table('system_state')->insert([
            'key' => self::STATE_KEY,
            'value' => $payload,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }
    private function decrypt(?string $value): string
    {
        if (!$value) return '';
        try {
            return Crypt::decryptString($value);
        } catch (Throwable) {
            return '';
        }
    }

    public function find(string $id): ?array
    {
        foreach ($this->raw() as $item) {
            if (($item['id'] ?? '') !== $id) continue;
            $item['botToken'] = $this->decrypt($item['tokenEncrypted'] ?? null);
            $item['webhookSecret'] = $this->decrypt($item['webhookSecretEncrypted'] ?? null);
            return $item;
        }
        return null;
    }

    public function publicList(): array
    {
        return array_map(function (array $item): array {
            $token = $this->decrypt($item['tokenEncrypted'] ?? null);
            return [
                'id' => (string) ($item['id'] ?? ''),
                'name' => (string) ($item['name'] ?? ''),
                'username' => (string) ($item['username'] ?? ''),
                'appUrl' => (string) ($item['appUrl'] ?? ''),
                'maskedToken' => $token === '' ? 'Unavailable — re-enter token' : substr($token, 0, 5) . '••••••',
                'enabled' => (bool) ($item['enabled'] ?? true),
                'webhookUrl' => (string) ($item['webhookUrl'] ?? ''),
                'webhookRegisteredAt' => $item['webhookRegisteredAt'] ?? null,
                'createdAt' => $item['createdAt'] ?? null,
            ];
        }, $this->raw());
    }

    public function upsert(array $data): array
    {
        $items = $this->raw();
        $found = false;
        foreach ($items as &$item) {
            if (($item['id'] ?? '') !== $data['id']) continue;
            $found = true;
            $item['name'] = $data['name'];
            $item['username'] = $data['username'];
            $item['appUrl'] = $data['appUrl'];
            $item['enabled'] = $data['enabled'];
            if (!empty($data['botToken'])) $item['tokenEncrypted'] = Crypt::encryptString($data['botToken']);
            if (empty($item['webhookSecretEncrypted'])) {
                $item['webhookSecretEncrypted'] = Crypt::encryptString(Str::random(40));
            }
            break;
        }
        unset($item);

        if (!$found) {
            $items[] = [
                'id' => $data['id'],
                'name' => $data['name'],
                'username' => $data['username'],
                'appUrl' => $data['appUrl'],
                'enabled' => $data['enabled'],
                'tokenEncrypted' => Crypt::encryptString($data['botToken']),
                'webhookSecretEncrypted' => Crypt::encryptString(Str::random(40)),
                'webhookUrl' => '',
                'webhookRegisteredAt' => null,
                'createdAt' => now()->toIso8601String(),
            ];
        }

        $this->persist($items);
        return $this->find($data['id']) ?? [];
    }

    public function updateFields(string $id, array $fields): bool
    {
        $items = $this->raw();
        $found = false;
        foreach ($items as &$item) {
            if (($item['id'] ?? '') !== $id) continue;
            foreach ($fields as $key => $value) $item[$key] = $value;
            $found = true;
            break;
        }
        unset($item);
        if ($found) $this->persist($items);
        return $found;
    }

    public function remove(string $id): bool
    {
        $items = $this->raw();
        $filtered = array_values(array_filter($items, fn (array $item) => ($item['id'] ?? '') !== $id));
        if (count($filtered) === count($items)) return false;
        $this->persist($filtered);
        return true;
    }
}
