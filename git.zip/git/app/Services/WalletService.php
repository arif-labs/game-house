<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use RuntimeException;

/**
 * Single place that moves player money, so every path obeys the same wallet rules:
 *
 *   - Deposits are credited to the PLAYING wallet (users.play_balance).
 *   - Game winnings are credited to the MAIN wallet (users.main_balance) by GameService.
 *   - Money can go Main -> Playing, but NEVER Playing -> Main (no way to turn deposits into
 *     withdrawable money without playing, so the house profit cannot be bypassed).
 *   - A transfer to another player always lands in the RECIPIENT'S PLAYING wallet. The sender may
 *     pay from either their Main or their Playing wallet.
 *   - Withdrawals are paid from the Main wallet only.
 *
 * Every successful operation sends the affected player a Telegram bot message.
 */
class WalletService
{
    private static ?bool $verificationColumns = null;

    public function __construct(
        private HouseWalletService $houseWallet,
        private TelegramNotifier $notifier,
    ) {
    }

    public static function hasVerificationColumns(): bool
    {
        if (self::$verificationColumns === null) {
            try {
                self::$verificationColumns = Schema::hasColumn('deposits', 'reference_key')
                    && Schema::hasColumn('deposits', 'verification_status');
            } catch (\Throwable $e) {
                self::$verificationColumns = false;
            }
        }
        return self::$verificationColumns;
    }

    public static function money(float $value): string
    {
        return number_format($value, 2);
    }

    // ------------------------------------------------------------------------------------------
    // Deposits
    // ------------------------------------------------------------------------------------------

    /**
     * Credit a pending deposit to the player's PLAYING wallet. Used by the admin "approve" action and by
     * the automatic verifier. $opts: amount (verified amount to credit), note, notify (default true).
     *
     * @return array{depositId:string,userId:string,username:string,amount:float,reference:string,playBalance:float,mainBalance:float,message:string}
     */
    public function creditDeposit(string $depositId, string $reviewer, array $opts = []): array
    {
        $result = DB::transaction(function () use ($depositId, $reviewer, $opts) {
            $d = DB::table('deposits')->where(['id' => $depositId, 'status' => 'pending'])->lockForUpdate()->first();
            if (!$d) {
                throw new RuntimeException('Deposit is not pending');
            }
            $u = DB::table('users')->where('id', $d->user_id)->lockForUpdate()->first();
            if (!$u) {
                throw new RuntimeException('Player account not found');
            }

            $amount = round((float) ($opts['amount'] ?? $d->amount), 2);
            if ($amount <= 0 || $amount > 100000) {
                throw new RuntimeException('Invalid deposit amount');
            }

            $playAfter = round((float) $u->play_balance + $amount, 2);
            DB::table('users')->where('id', $u->id)->update([
                'play_balance' => $playAfter,
                'total_deposited' => (float) $u->total_deposited + $amount,
                'updated_at' => now(),
            ]);

            $update = [
                'status' => 'approved',
                'amount' => $amount,
                'reviewed_by' => $reviewer,
                'reviewed_at' => now(),
            ];
            if (self::hasVerificationColumns()) {
                $auto = (bool) ($opts['auto'] ?? false);
                $update['verification_status'] = $auto ? 'verified' : 'manual';
                if ($auto) {
                    $update['verified_amount'] = $amount;
                    $update['verified_at'] = now();
                }
                if (!empty($opts['note'])) {
                    $update['verification_note'] = (string) $opts['note'];
                }
            }
            DB::table('deposits')->where('id', $d->id)->update($update);

            // The external payment and the credit to the player are separate house-ledger movements
            // that net to zero, so a deposit is never counted as house profit.
            $this->houseWallet->post('DEPOSIT_RECEIVED', $amount, $d->id, 'External deposit received for ' . $u->username);
            $this->houseWallet->post('DEPOSIT_TRANSFER', -$amount, $d->id, 'Deposit credited to Playing wallet of ' . $u->username);

            DB::table('ledger')->insert([
                'id' => (string) Str::uuid(),
                'user_id' => $u->id,
                'type' => 'DEPOSIT',
                'wallet_type' => 'PLAY',
                'amount' => $amount,
                'balance_after' => $playAfter,
                'reference_id' => $d->id,
                'description' => 'Approved deposit (' . ($d->provider ?? 'payment provider') . ') to Playing wallet',
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            $info = [
                'depositId' => $d->id,
                'userId' => $u->id,
                'username' => $u->username,
                'telegramId' => $u->telegram_id,
                'amount' => $amount,
                'reference' => (string) $d->reference_no,
                'playBalance' => $playAfter,
                'mainBalance' => round((float) $u->main_balance, 2),
            ];
            $info['message'] = $this->depositMessage($info);
            return $info;
        });

        if ($opts['notify'] ?? true) {
            $this->notifier->send($result['telegramId'] ?? null, $result['message']);
        }
        unset($result['telegramId']);
        return $result;
    }

    public function depositMessage(array $i): string
    {
        $amt = self::money($i['amount']);
        return "✅ ገቢዎ ተረጋግጧል!\n"
            . "መጠን: {$amt} ETB ወደ Playing wallet ገብቷል።\n"
            . "ግብይት: {$i['reference']}\n"
            . "Playing wallet: " . self::money($i['playBalance']) . " ETB\n"
            . "Main wallet: " . self::money($i['mainBalance']) . " ETB\n\n"
            . "✅ Deposit confirmed!\n"
            . "{$amt} ETB was added to your Playing wallet.\n"
            . "Reference: {$i['reference']}\n"
            . "Playing wallet: " . self::money($i['playBalance']) . " ETB · Main wallet: " . self::money($i['mainBalance']) . " ETB";
    }

    // ------------------------------------------------------------------------------------------
    // Main -> Playing (the only direction between a player's own wallets)
    // ------------------------------------------------------------------------------------------

    public function moveMainToPlay(string $userId, float $amount): array
    {
        $amount = round($amount, 2);
        if ($amount < 1 || $amount > 100000) {
            throw new RuntimeException('Enter an amount between 1 and 100,000 ETB.');
        }

        $result = DB::transaction(function () use ($userId, $amount) {
            $u = DB::table('users')->where('id', $userId)->where('is_bot', false)->lockForUpdate()->first();
            if (!$u) {
                throw new RuntimeException('Player account not found');
            }
            if ((float) $u->main_balance + 0.000001 < $amount) {
                throw new RuntimeException('Insufficient Main wallet balance');
            }

            $mainAfter = round((float) $u->main_balance - $amount, 2);
            $playAfter = round((float) $u->play_balance + $amount, 2);
            DB::table('users')->where('id', $u->id)->update([
                'main_balance' => $mainAfter,
                'play_balance' => $playAfter,
                'updated_at' => now(),
            ]);

            $ref = 'MOVE:' . Str::uuid();
            foreach ([
                ['WALLET_MOVE_OUT', 'MAIN', -$amount, $mainAfter, 'Moved to Playing wallet'],
                ['WALLET_MOVE_IN', 'PLAY', $amount, $playAfter, 'Moved from Main wallet'],
            ] as [$type, $wallet, $value, $after, $description]) {
                DB::table('ledger')->insert([
                    'id' => (string) Str::uuid(), 'user_id' => $u->id, 'type' => $type, 'wallet_type' => $wallet,
                    'amount' => $value, 'balance_after' => $after, 'reference_id' => $ref,
                    'description' => $description, 'created_at' => now(), 'updated_at' => now(),
                ]);
            }

            return ['telegramId' => $u->telegram_id, 'amount' => $amount, 'mainBalance' => $mainAfter, 'playBalance' => $playAfter];
        });

        $message = "✅ {$this->fmt($amount)} ETB ከMain wallet ወደ Playing wallet ተዛውሯል።\n"
            . "Main wallet: " . self::money($result['mainBalance']) . " ETB\n"
            . "Playing wallet: " . self::money($result['playBalance']) . " ETB\n\n"
            . "✅ {$this->fmt($amount)} ETB moved from your Main wallet to your Playing wallet.\n"
            . "Main wallet: " . self::money($result['mainBalance']) . " ETB · Playing wallet: " . self::money($result['playBalance']) . " ETB";
        $this->notifier->send($result['telegramId'] ?? null, $message);

        return [
            'amount' => $amount,
            'mainBalance' => $result['mainBalance'],
            'playBalance' => $result['playBalance'],
            'message' => $message,
        ];
    }

    // ------------------------------------------------------------------------------------------
    // Player -> player transfer
    // ------------------------------------------------------------------------------------------

    /**
     * @param string $sourceWallet 'main' or 'play': which of the SENDER's wallets pays.
     * The recipient is always credited to their PLAYING wallet.
     * $opts['notifySender'] (default false): the Telegram bot reply already confirms to the sender, so the
     * sender is only messaged separately when the transfer was started somewhere other than the bot chat.
     */
    public function transferToPlayer(string $senderId, string $recipientId, float $amount, string $sourceWallet, array $opts = []): array
    {
        $amount = round($amount, 2);
        if (!in_array($sourceWallet, ['main', 'play'], true)) {
            throw new RuntimeException('Choose Main wallet or Playing wallet to send from.');
        }
        if ($amount <= 0) {
            throw new RuntimeException('Invalid transfer amount');
        }
        if ($senderId === $recipientId) {
            throw new RuntimeException('You cannot transfer to yourself.');
        }

        $result = DB::transaction(function () use ($senderId, $recipientId, $amount, $sourceWallet) {
            // Lock in a fixed order so two opposite transfers can never deadlock each other.
            $ids = [$senderId, $recipientId];
            sort($ids);
            $locked = [];
            foreach ($ids as $id) {
                $locked[$id] = DB::table('users')->where('id', $id)->lockForUpdate()->first();
            }
            $sender = $locked[$senderId] ?? null;
            $recipient = $locked[$recipientId] ?? null;
            if (!$sender || !$recipient || (bool) ($sender->is_bot ?? false) || (bool) ($recipient->is_bot ?? false)) {
                throw new RuntimeException('Sender or recipient account is unavailable.');
            }

            $column = $sourceWallet === 'play' ? 'play_balance' : 'main_balance';
            $walletLabel = $sourceWallet === 'play' ? 'PLAY' : 'MAIN';
            if ((float) $sender->{$column} + 0.000001 < $amount) {
                throw new RuntimeException('Insufficient ' . ($sourceWallet === 'play' ? 'Playing' : 'Main') . ' wallet balance. No transfer was made.');
            }

            $senderUpdate = [$column => round((float) $sender->{$column} - $amount, 2), 'updated_at' => now()];
            $recipientPlayAfter = round((float) $recipient->play_balance + $amount, 2);
            DB::table('users')->where('id', $sender->id)->update($senderUpdate);
            DB::table('users')->where('id', $recipient->id)->update(['play_balance' => $recipientPlayAfter, 'updated_at' => now()]);

            $reference = 'TRANSFER:' . Str::uuid();
            foreach ([
                [$sender, 'TRANSFER_OUT', $walletLabel, -$amount, $senderUpdate[$column], 'Transfer to @' . $recipient->username . ' (their Playing wallet)'],
                [$recipient, 'TRANSFER_IN', 'PLAY', $amount, $recipientPlayAfter, 'Received from @' . $sender->username],
            ] as [$user, $type, $wallet, $value, $after, $description]) {
                DB::table('ledger')->insert([
                    'id' => (string) Str::uuid(), 'user_id' => $user->id, 'type' => $type, 'wallet_type' => $wallet,
                    'amount' => $value, 'balance_after' => $after, 'reference_id' => $reference,
                    'description' => $description, 'created_at' => now(), 'updated_at' => now(),
                ]);
            }

            $senderMain = $sourceWallet === 'main' ? $senderUpdate['main_balance'] : round((float) $sender->main_balance, 2);
            $senderPlay = $sourceWallet === 'play' ? $senderUpdate['play_balance'] : round((float) $sender->play_balance, 2);

            return [
                'amount' => $amount,
                'source' => $sourceWallet,
                'senderUsername' => $sender->username,
                'senderTelegramId' => $sender->telegram_id,
                'senderMain' => $senderMain,
                'senderPlay' => $senderPlay,
                'recipientUsername' => $recipient->username,
                'recipientTelegramId' => $recipient->telegram_id,
                'recipientPlay' => $recipientPlayAfter,
            ];
        });

        $amt = self::money($result['amount']);
        $sourceLabel = $result['source'] === 'play' ? 'Playing wallet' : 'Main wallet';

        $senderMessage = "✅ ማስተላለፍ ተሳክቷል!\n"
            . "{$amt} ETB ከ{$sourceLabel} ወደ @{$result['recipientUsername']} Playing wallet ተልኳል።\n"
            . "Main wallet: " . self::money($result['senderMain']) . " ETB\n"
            . "Playing wallet: " . self::money($result['senderPlay']) . " ETB\n\n"
            . "✅ Transfer successful!\n"
            . "{$amt} ETB was sent from your {$sourceLabel} to @{$result['recipientUsername']}'s Playing wallet.\n"
            . "Main wallet: " . self::money($result['senderMain']) . " ETB · Playing wallet: " . self::money($result['senderPlay']) . " ETB";

        $receiverMessage = "💸 ገንዘብ ተቀብለዋል!\n"
            . "@{$result['senderUsername']} {$amt} ETB ልከውልዎታል። ወደ Playing wallet ገብቷል።\n"
            . "Playing wallet: " . self::money($result['recipientPlay']) . " ETB\n\n"
            . "💸 You received money!\n"
            . "@{$result['senderUsername']} sent you {$amt} ETB. It was added to your Playing wallet.\n"
            . "Playing wallet: " . self::money($result['recipientPlay']) . " ETB";

        $this->notifier->send($result['recipientTelegramId'] ?? null, $receiverMessage);
        if ($opts['notifySender'] ?? false) {
            $this->notifier->send($result['senderTelegramId'] ?? null, $senderMessage);
        }

        return [
            'amount' => $result['amount'],
            'recipient' => $result['recipientUsername'],
            'source' => $result['source'],
            'message' => $senderMessage,
        ];
    }

    private function fmt(float $value): string
    {
        return self::money($value);
    }
}
