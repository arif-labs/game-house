<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;

class GameControlService
{
    public const DEFAULTS = [
        'crash' => ['enabled' => true, 'minStake' => 1, 'maxStake' => 1000],
        'spin' => ['enabled' => true, 'minStake' => 1, 'maxStake' => 100],
        'keno' => ['enabled' => false, 'minStake' => 1, 'maxStake' => 100],
    ];

    public function get(string $game): array
    {
        $defaults = self::DEFAULTS[$game] ?? [];
        if (!$defaults) return [];
        if (!DB::getSchemaBuilder()->hasTable('game_control_settings')) return $defaults;
        $row = DB::table('game_control_settings')->where('game_key', $game)->first();
        return array_merge($defaults, $row ? (json_decode($row->settings, true) ?: []) : []);
    }

    public function all(): array
    {
        return ['crash' => $this->get('crash'), 'spin' => $this->get('spin'), 'keno' => $this->get('keno')];
    }

    public function save(string $game, array $settings): array
    {
        $merged = array_merge($this->get($game), $settings);
        DB::table('game_control_settings')->updateOrInsert(
            ['game_key' => $game],
            ['settings' => json_encode($merged, JSON_THROW_ON_ERROR), 'updated_at' => now(), 'created_at' => now()]
        );
        return $merged;
    }
}
