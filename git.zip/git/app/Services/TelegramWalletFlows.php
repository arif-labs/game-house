<?php

namespace App\Services;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

/**
 * In-chat Deposit and Withdraw conversations for the Telegram bot.
 *
 * Used by App\Http\Controllers\TelegramController::commandReply(). The money rules
 * mirror ApiController::deposit() / ApiController::withdrawal() so a request made in
 * the bot is identical to one made in the Mini App (pending, admin-approved).
 *
 * Conversation state lives in the Laravel cache for 15 minutes (no migration needed).
 */
trait TelegramWalletFlows
{
    private function walletFlowKey(string $telegramId): string
    {
        return 'tg_wallet_flow:' . $telegramId;
    }

    private function walletFlowSave(string $telegramId, array $flow): void
    {
        Cache::put($this->walletFlowKey($telegramId), $flow, now()->addMinutes(15));
    }

    private function walletFlowReply(int $chatId, string $text, array $menu, ?array $rows = null): array
    {
        if ($rows !== null) {
            $menu['keyboard'] = $rows;
        }
        return ['chat_id' => $chatId, 'text' => $text, 'reply_markup' => $menu];
    }

    private function walletFlowProviderRows(): array
    {
        return [[['text' => 'Telebirr'], ['text' => 'CBE Birr']], [['text' => 'Cancel']]];
    }

    private function walletFlowCancelRows(): array
    {
        return [[['text' => 'Cancel']]];
    }

    private function walletFlowMoney(float $value): string
    {
        return number_format($value, 2);
    }

    private function walletFlowAmount(string $raw): ?float
    {
        $clean = str_ireplace([',', ' ', 'ETB', 'ብር'], '', trim($raw));
        if (!preg_match('/^[0-9]+(?:\.[0-9]{1,2})?$/', $clean)) {
            return null;
        }
        return round((float) $clean, 2);
    }

    private function walletFlowProvider(string $lower): ?string
    {
        if (in_array($lower, ['telebirr', 'tele birr', 'ቴሌብር'], true)) {
            return 'Telebirr';
        }
        if (in_array($lower, ['cbe birr', 'cbebirr', 'cbe', 'ሲቢኢ ብር', 'ሲቢኢ'], true)) {
            return 'CBE Birr';
        }
        return null;
    }

    private function walletFlowDepositNumber(string $provider): string
    {
        return app(PaymentAccountService::class)->numberFor($provider);
    }

    /**
     * Entry point. Returns a reply array when this message belongs to the Deposit /
     * Withdraw conversation, or null so the caller continues with normal handling.
     */
    private function handleWalletFlow(string $raw, string $lower, object $user, int $chatId, array $menu, ?string $optionId, string $slashCommand): ?array
    {
        $telegramId = (string) $chatId;
        $key = $this->walletFlowKey($telegramId);

        $startType = null;
        if ($optionId === 'deposit' || $slashCommand === '/deposit') {
            $startType = 'deposit';
        } elseif ($optionId === 'withdraw' || $slashCommand === '/withdraw') {
            $startType = 'withdraw';
        }
        if ($startType !== null) {
            Cache::forget($key);
            return $this->startWalletFlow($startType, $user, $chatId, $menu);
        }

        $flow = Cache::get($key);
        if (!is_array($flow) || empty($flow['type']) || empty($flow['step'])) {
            return null;
        }

        if (in_array($lower, ['cancel', '/cancel', 'ሰርዝ'], true)) {
            Cache::forget($key);
            return $this->walletFlowReply($chatId, "ተሰርዟል። ምንም ገንዘብ አልተንቀሳቀሰም።\nCancelled. No money was moved.", $menu);
        }

        // Any other menu button or command abandons the conversation and is handled normally.
        $isCommand = $slashCommand !== '' && $slashCommand[0] === '/';
        if ($optionId !== null || $isCommand || in_array($lower, ['menu', 'play'], true)) {
            Cache::forget($key);
            return null;
        }

        $fresh = DB::table('users')->where('id', $user->id)->first();
        if (!$fresh) {
            Cache::forget($key);
            return null;
        }

        return $flow['type'] === 'deposit'
            ? $this->depositFlowStep($flow, $raw, $lower, $fresh, $chatId, $menu)
            : $this->withdrawFlowStep($flow, $raw, $lower, $fresh, $chatId, $menu);
    }

    private function startWalletFlow(string $type, object $user, int $chatId, array $menu): array
    {
        $telegramId = (string) $chatId;

        if ($type === 'withdraw') {
            if (empty($user->phone) || empty($user->phone_verified_at)) {
                return $this->walletFlowReply($chatId, "ገንዘብ ለማውጣት መጀመሪያ ስልክ ቁጥርዎን ያረጋግጡ። Register ይምረጡና «ስልክ ቁጥር አጋራ» ይጫኑ።\nVerify your phone number first: choose Register and share your phone number.", $menu);
            }
            $min = (float) env('TELEGRAM_WITHDRAW_MIN', 10);
            if ((float) $user->main_balance < $min) {
                return $this->walletFlowReply($chatId, "ለማውጣት በቂ Main Balance የለዎትም። ቀሪ ሂሳብ: " . $this->walletFlowMoney((float) $user->main_balance) . " ETB (ዝቅተኛ " . $this->walletFlowMoney($min) . " ETB)።\nNot enough Main Balance to withdraw. Balance: " . $this->walletFlowMoney((float) $user->main_balance) . " ETB (minimum " . $this->walletFlowMoney($min) . " ETB).", $menu);
            }
        } else {
            $pending = DB::table('deposits')->where('user_id', $user->id)->where('status', 'pending')->count();
            if ($pending >= 5) {
                return $this->walletFlowReply($chatId, "ብዙ ያልተረጋገጡ የገቢ ጥያቄዎች አሉዎት። እባክዎ እስኪረጋገጡ ይጠብቁ ወይም ድጋፍ ያነጋግሩ።\nYou have several deposits awaiting review. Please wait for them to be approved or contact support.", $menu);
            }
        }

        $this->walletFlowSave($telegramId, ['type' => $type, 'step' => 'provider']);
        $label = $type === 'deposit' ? 'ገንዘብ ለማስገባት / To deposit' : 'ገንዘብ ለማውጣት / To withdraw';
        return $this->walletFlowReply($chatId, $label . ":\nየክፍያ አይነት ይምረጡ።\nChoose a payment method. (Type CANCEL to stop.)", $menu, $this->walletFlowProviderRows());
    }

    private function depositFlowStep(array $flow, string $raw, string $lower, object $user, int $chatId, array $menu): array
    {
        $telegramId = (string) $chatId;
        $min = (float) env('TELEGRAM_DEPOSIT_MIN', 10);
        $max = 100000.0;

        if ($flow['step'] === 'provider') {
            $provider = $this->walletFlowProvider($lower);
            if (!$provider) {
                return $this->walletFlowReply($chatId, 'Telebirr ወይም CBE Birr ይምረጡ።\nPlease tap Telebirr or CBE Birr.', $menu, $this->walletFlowProviderRows());
            }
            $flow['provider'] = $provider;
            $flow['step'] = 'amount';
            $this->walletFlowSave($telegramId, $flow);
            return $this->walletFlowReply($chatId, "ምን ያህል ብር ማስገባት ይፈልጋሉ? (ዝቅተኛ " . $this->walletFlowMoney($min) . " ETB)\nHow much do you want to deposit? (minimum " . $this->walletFlowMoney($min) . " ETB)", $menu, $this->walletFlowCancelRows());
        }

        if ($flow['step'] === 'amount') {
            $amount = $this->walletFlowAmount($raw);
            if ($amount === null || $amount < $min || $amount > $max) {
                return $this->walletFlowReply($chatId, "እባክዎ ትክክለኛ መጠን ያስገቡ (" . $this->walletFlowMoney($min) . " – " . $this->walletFlowMoney($max) . " ETB)።\nEnter a valid amount between " . $this->walletFlowMoney($min) . " and " . $this->walletFlowMoney($max) . " ETB.", $menu, $this->walletFlowCancelRows());
            }
            $flow['amount'] = $amount;
            $flow['step'] = 'reference';
            $this->walletFlowSave($telegramId, $flow);
            $number = $this->walletFlowDepositNumber($flow['provider']);
            $holder = app(PaymentAccountService::class)->nameFor($flow['provider']);
            $holder = $holder !== '' ? " ({$holder})" : '';
            return $this->walletFlowReply(
                $chatId,
                "1️⃣ ወደ {$flow['provider']} ቁጥር {$number}{$holder} " . $this->walletFlowMoney($amount) . " ETB ይላኩ።\n2️⃣ ከዚያ የደረሰዎትን የግብይት ቁጥር (Transaction ID) እዚህ ይላኩ።\n\nSend " . $this->walletFlowMoney($amount) . " ETB to {$flow['provider']} number {$number}{$holder}, then reply here with the transaction reference ID.",
                $menu,
                $this->walletFlowCancelRows()
            );
        }

        if ($flow['step'] === 'reference') {
            $ref = trim($raw);
            if (!preg_match('/^[A-Za-z0-9_-]{4,64}$/', $ref)) {
                return $this->walletFlowReply($chatId, "የግብይት ቁጥሩ ትክክል አይመስልም (ፊደል/ቁጥር ብቻ፣ 4–64 ቁምፊ)። እንደገና ይላኩ።\nThat reference looks invalid (letters/numbers only, 4–64 characters). Please send it again.", $menu, $this->walletFlowCancelRows());
            }
            if (DB::table('deposits')->whereRaw('LOWER(reference_no) = ?', [strtolower($ref)])->exists() || (WalletService::hasVerificationColumns() && DB::table('deposits')->where('reference_key', DepositVerificationService::referenceKey($ref))->exists())) {
                return $this->walletFlowReply($chatId, "ይህ የግብይት ቁጥር ቀድሞ ገብቷል። ትክክለኛውን ቁጥር ይላኩ ወይም ድጋፍ ያነጋግሩ።\nThis reference was already submitted. Send the correct one or contact support.", $menu, $this->walletFlowCancelRows());
            }
            try {
                DB::table('deposits')->insert([
                    'id' => $depositId = (string) Str::uuid(),
                    'user_id' => $user->id,
                    'username' => $user->username,
                    'amount' => (float) $flow['amount'],
                    'provider' => $flow['provider'],
                    'reference_no' => $ref,
                    ...(WalletService::hasVerificationColumns() ? ['reference_key' => DepositVerificationService::referenceKey($ref)] : []),
                    'status' => 'pending',
                    'created_at' => now(),
                ]);
            } catch (\Throwable $e) {
                return $this->walletFlowReply($chatId, "ጥያቄውን ማስገባት አልተቻለም። እባክዎ ቆይተው ይሞክሩ።\nCould not record your deposit. Please try again shortly.", $menu, $this->walletFlowCancelRows());
            }
            // Check the payment automatically. A verified payment is credited to the Playing wallet right away.
            $outcome = app(DepositVerificationService::class)->attempt($depositId, false);
            Cache::forget($this->walletFlowKey($telegramId));
            if (($outcome['state'] ?? '') === 'verified') {
                return $this->walletFlowReply($chatId, (string) ($outcome['message'] ?? ''), $menu);
            }
            return $this->walletFlowReply(
                $chatId,
                "✅ የገቢ ጥያቄዎ ተቀብሏል።\nመጠን: " . $this->walletFlowMoney((float) $flow['amount']) . " ETB\nአይነት: {$flow['provider']}\nግብይት: {$ref}\nአስተዳዳሪ ካረጋገጠ በኋላ ሂሳብዎ ይጨምራል።\n\nDeposit request received. Your balance is credited after an admin verifies the payment.",
                $menu
            );
        }

        Cache::forget($this->walletFlowKey($telegramId));
        return $this->walletFlowReply($chatId, "ክፍለ ጊዜው አብቅቷል። Deposit እንደገና ይምረጡ።\nSession expired. Choose Deposit again.", $menu);
    }

    private function withdrawFlowStep(array $flow, string $raw, string $lower, object $user, int $chatId, array $menu): array
    {
        $telegramId = (string) $chatId;
        $key = $this->walletFlowKey($telegramId);
        $min = (float) env('TELEGRAM_WITHDRAW_MIN', 10);
        $balance = (float) $user->main_balance;

        if ($flow['step'] === 'provider') {
            $provider = $this->walletFlowProvider($lower);
            if (!$provider) {
                return $this->walletFlowReply($chatId, 'Telebirr ወይም CBE Birr ይምረጡ።\nPlease tap Telebirr or CBE Birr.', $menu, $this->walletFlowProviderRows());
            }
            $flow['provider'] = $provider;
            $flow['step'] = 'account';
            $this->walletFlowSave($telegramId, $flow);
            $what = $provider === 'Telebirr' ? 'የቴሌብር ስልክ ቁጥር / Telebirr phone number' : 'የሲቢኢ ብር ቁጥር / CBE Birr number';
            return $this->walletFlowReply($chatId, "ገንዘቡ የሚላክበትን {$what} ይላኩ።\nSend the account to receive the money.", $menu, $this->walletFlowCancelRows());
        }

        if ($flow['step'] === 'account') {
            $account = preg_replace('/[\s\-]/', '', ltrim(trim($raw), '+'));
            if (!preg_match('/^[0-9]{8,16}$/', (string) $account)) {
                return $this->walletFlowReply($chatId, "ቁጥሩ ትክክል አይመስልም (8–16 አሃዝ)። እንደገና ይላኩ።\nThat number looks invalid (8–16 digits). Please send it again.", $menu, $this->walletFlowCancelRows());
            }
            $flow['account'] = $account;
            $flow['step'] = 'name';
            $this->walletFlowSave($telegramId, $flow);
            return $this->walletFlowReply($chatId, "በሂሳቡ ላይ የተመዘገበውን ስም ይላኩ።\nSend the account holder's full name.", $menu, $this->walletFlowCancelRows());
        }

        if ($flow['step'] === 'name') {
            $name = trim(preg_replace('/\s+/u', ' ', $raw));
            if (!preg_match('/^[\p{L}\p{M}\s.\'-]{2,60}$/u', $name)) {
                return $this->walletFlowReply($chatId, "ስሙ ትክክል አይመስልም። እንደገና ይላኩ።\nThat name looks invalid. Please send it again.", $menu, $this->walletFlowCancelRows());
            }
            $flow['name'] = $name;
            $flow['step'] = 'amount';
            $this->walletFlowSave($telegramId, $flow);
            return $this->walletFlowReply($chatId, "ምን ያህል ማውጣት ይፈልጋሉ? ቀሪ Main Balance: " . $this->walletFlowMoney($balance) . " ETB (ዝቅተኛ " . $this->walletFlowMoney($min) . ")\nHow much do you want to withdraw? Main Balance: " . $this->walletFlowMoney($balance) . " ETB (minimum " . $this->walletFlowMoney($min) . ")", $menu, $this->walletFlowCancelRows());
        }

        if ($flow['step'] === 'amount') {
            $amount = $this->walletFlowAmount($raw);
            $max = min($balance, 100000.0);
            if ($amount === null || $amount < $min || $amount > $max) {
                return $this->walletFlowReply($chatId, "እባክዎ ከ" . $this->walletFlowMoney($min) . " እስከ " . $this->walletFlowMoney($max) . " ETB ያስገቡ።\nEnter an amount between " . $this->walletFlowMoney($min) . " and " . $this->walletFlowMoney($max) . " ETB.", $menu, $this->walletFlowCancelRows());
            }
            $flow['amount'] = $amount;
            $flow['step'] = 'confirm';
            $this->walletFlowSave($telegramId, $flow);
            return $this->walletFlowReply(
                $chatId,
                "እባክዎ ያረጋግጡ / Please confirm:\nመጠን / Amount: " . $this->walletFlowMoney($amount) . " ETB\nአይነት / Method: {$flow['provider']}\nቁጥር / Account: {$flow['account']}\nስም / Name: {$flow['name']}\n\nገንዘቡ አሁን ከ Main Balance ይቀነሳል፤ አስተዳዳሪ ጥያቄውን ይገመግማል።\nThe amount is deducted from your Main Balance now and reviewed by an admin.\n\nCONFIRM ወይም CANCEL ይላኩ።",
                $menu,
                [[['text' => 'CONFIRM']], [['text' => 'Cancel']]]
            );
        }

        if ($flow['step'] === 'confirm') {
            if (!in_array($lower, ['confirm', 'yes', 'አዎ'], true)) {
                return $this->walletFlowReply($chatId, "ምንም ገንዘብ አልወጣም። CONFIRM ወይም CANCEL ይላኩ።\nNo money has moved yet. Send CONFIRM or CANCEL.", $menu, [[['text' => 'CONFIRM']], [['text' => 'Cancel']]]);
            }
            // pull() removes the session first so a double-tap on CONFIRM cannot submit twice.
            $flow = Cache::pull($key);
            if (!is_array($flow) || ($flow['step'] ?? '') !== 'confirm') {
                return $this->walletFlowReply($chatId, "ክፍለ ጊዜው አብቅቷል ወይም ጥያቄው ቀድሞ ተልኳል። Withdraw እንደገና ይምረጡ።\nSession expired or already submitted. Choose Withdraw again.", $menu);
            }
            try {
                $result = DB::transaction(function () use ($telegramId, $flow, $min) {
                    $u = DB::table('users')->where('telegram_id', $telegramId)->lockForUpdate()->first();
                    $amount = round((float) $flow['amount'], 2);
                    if (!$u || empty($u->phone) || empty($u->phone_verified_at)) {
                        throw new \RuntimeException('Please verify your phone number before withdrawing.');
                    }
                    if ($amount < $min || $amount > 100000 || (float) $u->main_balance < $amount) {
                        throw new \RuntimeException('Insufficient Main Wallet balance. No withdrawal was made.');
                    }

                    $after = round((float) $u->main_balance - $amount, 2);
                    $id = (string) Str::uuid();

                    DB::table('users')->where('id', $u->id)->update([
                        'main_balance' => $after,
                        'total_withdrawn' => (float) $u->total_withdrawn + $amount,
                        'updated_at' => now(),
                    ]);

                    DB::table('withdrawals')->insert([
                        'id' => $id,
                        'user_id' => $u->id,
                        'username' => $u->username,
                        'amount' => $amount,
                        'provider' => $flow['provider'],
                        'account_number' => $flow['account'],
                        'account_name' => $flow['name'],
                        'status' => 'pending',
                        'created_at' => now(),
                    ]);

                    app(HouseWalletService::class)->post('WITHDRAWAL_REQUEST', $amount, $id, 'Player withdrawal requested by ' . $u->username);

                    DB::table('ledger')->insert([
                        'id' => (string) Str::uuid(),
                        'user_id' => $u->id,
                        'type' => 'WITHDRAWAL',
                        'wallet_type' => 'MAIN',
                        'amount' => -$amount,
                        'balance_after' => $after,
                        'reference_id' => $id,
                        'description' => 'Withdrawal request (Telegram bot)',
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);

                    return ['amount' => $amount, 'balance' => $after];
                });
            } catch (\Throwable $e) {
                return $this->walletFlowReply($chatId, "የገንዘብ ማውጫ ጥያቄው አልተሳካም: " . $e->getMessage() . "\nWithdrawal failed: " . $e->getMessage(), $menu);
            }
            return $this->walletFlowReply(
                $chatId,
                "✅ የገንዘብ ማውጫ ጥያቄዎ ለግምገማ ተልኳል።\nመጠን: " . $this->walletFlowMoney($result['amount']) . " ETB\nአዲስ Main Balance: " . $this->walletFlowMoney($result['balance']) . " ETB\n\nWithdrawal request submitted for review. New Main Balance: " . $this->walletFlowMoney($result['balance']) . " ETB.",
                $menu
            );
        }

        Cache::forget($key);
        return $this->walletFlowReply($chatId, "ክፍለ ጊዜው አብቅቷል። Withdraw እንደገና ይምረጡ።\nSession expired. Choose Withdraw again.", $menu);
    }
}
